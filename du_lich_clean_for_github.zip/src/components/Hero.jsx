export default function Hero() {
  return (
    <section className="bg-[url('/images/hero.jpg')] bg-cover bg-center">
      <div className="backdrop-brightness-75">
        <div className="max-w-7xl mx-auto px-4 py-20 text-white">
          <h1 className="text-4xl sm:text-5xl font-extrabold">Khám phá Việt Nam — Tour trọn gói giá tốt</h1>
          <p className="mt-4 text-lg max-w-2xl">Tìm tour, đặt chỗ và thanh toán nhanh chóng.</p>
        </div>
      </div>
    </section>
  );
}
