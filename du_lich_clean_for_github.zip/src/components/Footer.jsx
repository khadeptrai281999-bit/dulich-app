export default function Footer() {
  return (
    <footer className="bg-emerald-800 text-white py-6 mt-10">
      <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
        <p>© {new Date().getFullYear()} Website Du Lịch. All rights reserved.</p>
        <p>
          Thiết kế bởi{" "}
          <a href="https://cmsnt.vn" target="_blank" className="text-yellow-300 hover:underline">
            CMSNT.VN
          </a>
        </p>
      </div>
    </footer>
  );
}
