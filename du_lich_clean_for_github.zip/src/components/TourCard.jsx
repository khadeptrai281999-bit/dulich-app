"use client";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function TourCard({ tour }) {
  const router = useRouter();

  const handleView = () => router.push(`/tour-tron-goi/trong-nuoc/${tour.id}`);
  const handleBook = () => router.push(`/tour-tron-goi/trong-nuoc/${tour.id}`);

  return (
    <article
      className="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden cursor-pointer"
      onClick={handleView}
    >
      <div className="relative h-44 w-full">
        <Image
          src={tour.image}
          alt={tour.title}
          fill
          className="object-cover"
          unoptimized
          priority
        />
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg">{tour.title}</h3>
        <p className="text-sm text-slate-500 mt-2">{tour.desc}</p>

        <div className="mt-4 flex items-center justify-between">
          <div className="text-lg font-bold text-green-700">
            {formatVND(tour.price)}
          </div>

          <div className="flex gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleView();
              }}
              className="px-3 py-1 border rounded-md text-sm hover:bg-gray-100"
            >
              Xem
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleBook();
              }}
              className="px-3 py-1 rounded-md bg-purple-600 text-white text-sm hover:bg-purple-700"
            >
              Đặt ngay
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

function formatVND(n) {
  return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "₫";
}
