"use client";
import { useState } from "react";

export default function BookingForm({ tourId }) {
  const [form, setForm] = useState({ name: "", phone: "", email: "", note: "" });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch("/api/booking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tourId, ...form }),
      });
      const data = await res.json();

      if (data.ok) {
        setMessage("✅ Đặt tour thành công!");
        setForm({ name: "", phone: "", email: "", note: "" });
      } else {
        setMessage("❌ Lỗi: " + (data.error || "Không thể đặt tour"));
      }
    } catch (err) {
      setMessage("❌ Lỗi kết nối server");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl shadow mt-8">
      <h2 className="text-lg font-bold">Đặt tour ngay</h2>

      <input
        type="text"
        placeholder="Họ và tên"
        className="w-full border p-2 rounded"
        value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })}
        required
      />
      <input
        type="tel"
        placeholder="Số điện thoại"
        className="w-full border p-2 rounded"
        value={form.phone}
        onChange={e => setForm({ ...form, phone: e.target.value })}
        required
      />
      <input
        type="email"
        placeholder="Email (không bắt buộc)"
        className="w-full border p-2 rounded"
        value={form.email}
        onChange={e => setForm({ ...form, email: e.target.value })}
      />
      <textarea
        placeholder="Ghi chú"
        className="w-full border p-2 rounded"
        rows={3}
        value={form.note}
        onChange={e => setForm({ ...form, note: e.target.value })}
      />

      <button
        type="submit"
        disabled={loading}
        className="px-4 py-2 bg-indigo-600 text-white rounded-md disabled:bg-indigo-300"
      >
        {loading ? "Đang xử lý..." : "Đặt tour"}
      </button>

      {message && <p className="mt-2 text-sm">{message}</p>}
    </form>
  );
}
