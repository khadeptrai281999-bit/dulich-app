"use client";
export default function Modal({ children, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-lg w-full">
        {children}
        <div className="mt-4 text-right">
          <button onClick={onClose} className="px-3 py-1 border rounded-md">Đóng</button>
        </div>
      </div>
    </div>
  );
}
