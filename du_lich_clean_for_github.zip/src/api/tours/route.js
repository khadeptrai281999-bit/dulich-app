let bookings = []; // mock database trong RAM

export async function POST(req) {
  const body = await req.json();
  const { tourId, name, phone, email, note } = body;

  if (!tourId || !name || !phone) {
    return new Response(JSON.stringify({ ok: false, error: "Thiếu thông tin" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const newBooking = {
    id: bookings.length + 1,
    tourId,
    name,
    phone,
    email,
    note,
    createdAt: new Date(),
  };

  bookings.push(newBooking);

  return new Response(JSON.stringify({ ok: true, booking: newBooking }), {
    headers: { "Content-Type": "application/json" },
  });
}
