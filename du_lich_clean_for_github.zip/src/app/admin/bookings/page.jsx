"use client";
import { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import "jspdf-autotable";

export default function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  async function fetchData() {
    try {
      const res = await fetch("/api/booking");
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      console.error("❌ Lỗi fetch booking:", err);
    }
  }

  useEffect(() => {
    fetchData();
  }, []);

  async function handleDelete(id) {
    if (!confirm("Bạn có chắc muốn xóa booking này?")) return;
    await fetch("/api/booking", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    fetchData();
  }

  async function handleConfirm(id) {
    await fetch("/api/booking", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: "confirmed" }),
    });
    fetchData();
  }

  /// Xuất Excel với header tiếng Việt
function exportToExcel(filteredBookings) {
  const data = filteredBookings.map((b) => ({
    ID: b.id,
    Tour: b.tourId,
    Name: b.name,
    Phone: b.phone,
    Email: b.email || "",
    Note: b.note || "",
    Date: new Date(b.createdAt).toLocaleString(),
    Status: b.status,
  }));

  // Map sang tiếng Việt để hiển thị
  const headerMap = {
    ID: "Mã booking",
    Tour: "Tour",
    Name: "Họ tên",
    Phone: "SĐT",
    Email: "Email",
    Note: "Ghi chú",
    Date: "Ngày đặt",
    Status: "Trạng thái",
  };

  const worksheet = XLSX.utils.json_to_sheet(data);

  // Đổi header tiếng Anh -> tiếng Việt
  const range = XLSX.utils.decode_range(worksheet["!ref"]);
  for (let C = range.s.c; C <= range.e.c; ++C) {
    const cellAddress = XLSX.utils.encode_cell({ r: 0, c: C });
    const header = worksheet[cellAddress].v;
    worksheet[cellAddress].v = headerMap[header] || header;
  }

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Bookings");

  const excelBuffer = XLSX.write(workbook, {
    bookType: "xlsx",
    type: "array",
  });

  const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
  saveAs(blob, "bookings.xlsx");
}



  // Xuất PDF với tiếng Việt
function exportToPDF(booking) {
  const doc = new jsPDF();

  doc.setFontSize(16);
  doc.text("Phiếu Đặt Tour", 14, 20);

  doc.setFontSize(12);
  doc.text(`Mã booking: ${booking.id}`, 14, 35);
  doc.text(`Tour: ${booking.tourId}`, 14, 45);
  doc.text(`Khách hàng: ${booking.name}`, 14, 55);
  doc.text(`SĐT: ${booking.phone}`, 14, 65);
  doc.text(`Email: ${booking.email || "-"}`, 14, 75);
  doc.text(`Ghi chú: ${booking.note || "-"}`, 14, 85);
  doc.text(`Ngày đặt: ${new Date(booking.createdAt).toLocaleString()}`, 14, 95);
  doc.text(`Trạng thái: ${booking.status}`, 14, 105);

  doc.save(`booking_${booking.id}.pdf`);
}


  // Lọc bookings
  const filteredBookings = bookings.filter((b) => {
    const keyword = search.toLowerCase();
    const matchSearch =
      b.name.toLowerCase().includes(keyword) ||
      b.phone.includes(keyword) ||
      (b.email && b.email.toLowerCase().includes(keyword));

    const matchStatus =
      statusFilter === "all" ? true : b.status === statusFilter;

    return matchSearch && matchStatus;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold mb-6">📋 Danh sách Booking</h1>

      {/* Bộ lọc & tìm kiếm */}
      <div className="flex gap-4 mb-6">
        <input
          type="text"
          placeholder="Tìm theo tên, SĐT, email..."
          className="border rounded px-3 py-2 flex-1"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="border rounded px-3 py-2"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">Tất cả</option>
          <option value="pending">Chờ duyệt</option>
          <option value="confirmed">Đã xác nhận</option>
        </select>

        {/* Nút Export Excel */}
        <button
          onClick={() => exportToExcel(filteredBookings)}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          ⬇️ Xuất Excel
        </button>
      </div>

      {filteredBookings.length === 0 ? (
        <p>Không tìm thấy booking phù hợp.</p>
      ) : (
        <table className="w-full border-collapse border text-sm">
          <thead className="bg-slate-100">
            <tr>
              <th className="border px-3 py-2">ID</th>
              <th className="border px-3 py-2">Tour</th>
              <th className="border px-3 py-2">Họ tên</th>
              <th className="border px-3 py-2">SĐT</th>
              <th className="border px-3 py-2">Email</th>
              <th className="border px-3 py-2">Ngày đặt</th>
              <th className="border px-3 py-2">Trạng thái</th>
              <th className="border px-3 py-2">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {filteredBookings.map((b) => (
              <tr key={b.id} className="hover:bg-slate-50">
                <td className="border px-3 py-2 text-center">{b.id}</td>
                <td className="border px-3 py-2">{b.tourId}</td>
                <td className="border px-3 py-2">{b.name}</td>
                <td className="border px-3 py-2">{b.phone}</td>
                <td className="border px-3 py-2">{b.email || "-"}</td>
                <td className="border px-3 py-2">
                  {new Date(b.createdAt).toLocaleString()}
                </td>
                <td className="border px-3 py-2">
                  <span
                    className={`px-2 py-1 rounded text-xs ${
                      b.status === "confirmed"
                        ? "bg-green-100 text-green-700"
                        : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {b.status}
                  </span>
                </td>
                <td className="border px-3 py-2 flex gap-2">
                  {b.status === "pending" && (
                    <button
                      onClick={() => handleConfirm(b.id)}
                      className="px-2 py-1 bg-green-600 text-white rounded text-xs"
                    >
                      Xác nhận
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(b.id)}
                    className="px-2 py-1 bg-red-600 text-white rounded text-xs"
                  >
                    Xóa
                  </button>
                  <button
                    onClick={() => exportToPDF(b)}
                    className="px-2 py-1 bg-purple-600 text-white rounded text-xs"
                  >
                    PDF
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
