"use client";
import { useEffect } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

export default function XacNhan() {
  const params = useSearchParams();
  const orderId = params.get("id") || "000000";
  const hotel = params.get("hotel") || "Không xác định";
  const price = params.get("price") || "0";
  const name = params.get("name") || "Chưa có";
  const phone = params.get("phone") || "Chưa có";
  const email = params.get("email") || "Không cung cấp";
  const method = params.get("method") || "Không rõ";
  const checkin = params.get("checkin") || "";
  const checkout = params.get("checkout") || "";
  const rooms = params.get("rooms") || "1";

  // ✅ Lưu đơn hàng vào localStorage
  useEffect(() => {
    const newOrder = {
      id: orderId,
      hotel,
      price,
      name,
      phone,
      email,
      method,
      checkin,
      checkout,
      rooms,
      date: new Date().toLocaleString("vi-VN"),
    };
    const existing = JSON.parse(localStorage.getItem("orders") || "[]");
    existing.push(newOrder);
    localStorage.setItem("orders", JSON.stringify(existing));

    // ✅ Giả lập gửi email xác nhận
    console.log("📧 Gửi email xác nhận tới:", email);
    console.log("🧾 Nội dung:", newOrder);
  }, []);

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 text-center">
      <h1 className="text-3xl font-bold text-green-800 mb-6">
        🎉 Đặt phòng thành công!
      </h1>

      <div className="bg-white p-6 rounded-2xl shadow-md text-left">
        <p className="text-lg mb-2">
          <strong>Mã đơn hàng:</strong>{" "}
          <span className="text-green-700 font-semibold">#{orderId}</span>
        </p>
        <p className="text-lg mb-2">
          <strong>Khách sạn:</strong> {hotel}
        </p>
        <p className="text-lg mb-2">
          <strong>Ngày nhận phòng:</strong>{" "}
          {checkin ? checkin : "Chưa chọn"}
        </p>
        <p className="text-lg mb-2">
          <strong>Ngày trả phòng:</strong>{" "}
          {checkout ? checkout : "Chưa chọn"}
        </p>
        <p className="text-lg mb-2">
          <strong>Số phòng:</strong> {rooms}
        </p>
        <p className="text-lg mb-2">
          <strong>Tổng tiền:</strong>{" "}
          <span className="text-green-700 font-semibold">{price}đ</span>
        </p>
        <hr className="my-4" />
        <p className="text-lg mb-2">
          <strong>Khách hàng:</strong> {name}
        </p>
        <p className="text-lg mb-2">
          <strong>Số điện thoại:</strong> {phone}
        </p>
        <p className="text-lg mb-2">
          <strong>Email:</strong> {email}
        </p>
        <p className="text-lg mb-4">
          <strong>Phương thức thanh toán:</strong> {method}
        </p>

        <div className="text-center mt-8">
          <p className="text-gray-600 mb-6">
            Cảm ơn bạn đã đặt phòng cùng chúng tôi!  
            Thông tin chi tiết đơn hàng đã được lưu và gửi qua email (giả lập).
          </p>

          <div className="flex flex-col md:flex-row justify-center gap-4">
            <Link
              href="/khach-san/ha-noi"
              className="bg-green-700 text-white px-6 py-3 rounded-lg hover:bg-green-800"
            >
              Tiếp tục đặt phòng
            </Link>
            <Link
              href="/lich-su"
              className="bg-gray-700 text-white px-6 py-3 rounded-lg hover:bg-gray-800"
            >
              Xem lịch sử đặt phòng
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
