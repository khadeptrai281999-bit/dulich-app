"use client";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname, useRouter } from "next/navigation";
import Image from "next/image";

export default function TourTrongNuoc() {
  const pathname = usePathname();
  const router = useRouter();

  const tours = [
    {
      id: "ha-long-yen-tu",
      name: "Hạ Long - Yên Tử",
      description: "Khám phá Vịnh Hạ Long và Yên Tử linh thiêng",
      price: "2.500.000đ",
      image: "https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg",
    },
    {
      id: "sapa-lao-cai",
      name: "Sapa - Lào Cai",
      description: "Trải nghiệm cảnh sắc vùng núi phía Bắc",
      price: "3.000.000đ",
      image: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg",
    },
    {
      id: "hue",
      name: "Huế",
      description: "Hành trình cố đô Huế mộng mơ",
      price: "2.200.000đ",
      image: "https://www.vietnamairlines.com/~/media/Images/Discovery/Vietnam/HUE/canh%20dep/1920x1080/Hue_canhdep_cung_dinh_hue_1920x1080.jpg",
    },
    {
      id: "quang-binh",
      name: "Quảng Bình",
      description: "Khám phá động Phong Nha – Kẻ Bàng",
      price: "2.700.000đ",
      image: "https://bestbooking.vn/wp-content/uploads/2025/01/BestBooking-travel-tour-quang-binh-khoi-hanh-tu-hue-13-scaled.jpeg",
    },
    {
      id: "da-lat",
      name: "Đà Lạt",
      description: "Thành phố ngàn hoa lãng mạn",
      price: "2.100.000đ",
      image: "https://peacetour.com.vn/Upload/TourInformation/401cc353-f67e-4f26-855c-f34ff0519ffd/du-lich-hoa-binh-tour-da-lat-xu-so-ngan-hoa-4-ngay-3-dem-quang-truong-lam-vien-2203.jpg",
    },
    {
      id: "da-nang",
      name: "Đà Nẵng",
      description: "Khám phá thành phố biển miền Trung",
      price: "2.400.000đ",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
    },
    {
      id: "hoi-an",
      name: "Hội An",
      description: "Thành phố cổ yên bình và thơ mộng",
      price: "2.000.000đ",
      image: "https://viptrip.vn/public/upload/news/pho-co-hoi-an_31-12-2023_613395856.jpg",
    },
    {
      id: "mui-ne-ke-ga",
      name: "Mũi Né - Kê Gà",
      description: "Khám phá đồi cát vàng và biển xanh Bình Thuận",
      price: "2.300.000đ",
      image: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg",
    },
    {
      id: "nha-trang",
      name: "Nha Trang",
      description: "Khám phá thiên đường biển đảo miền Trung",
      price: "2.600.000đ",
      image: "https://images.pexels.com/photos/248797/pexels-photo-248797.jpeg",
    },
    {
      id: "quy-nhon",
      name: "Quy Nhơn",
      description: "Thành phố biển yên bình với cảnh sắc hoang sơ",
      price: "2.500.000đ",
      image: "https://th.bing.com/th/id/R.d514e05919e5f298b61576f6535bb48b?rik=qn9y%2bGFxfRKWwQ&pid=ImgRaw&r=0",
    },
    {
      id: "phu-quoc",
      name: "Phú Quốc",
      description: "Đảo ngọc xinh đẹp giữa biển khơi",
      price: "3.200.000đ",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
    },
    {
      id: "vung-tau-ho-tram",
      name: "Vũng Tàu - Hồ Tràm",
      description: "Tận hưởng không gian biển gần Sài Gòn",
      price: "2.100.000đ",
      image: "https://image.vietgoing.com/editor/image_zqu1639033152.jpg",
    },
  ];

  return (
    <AnimatePresence mode="wait">
      <motion.main
        key={pathname}
        initial={{ opacity: 0, y: 25 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -25 }}
        transition={{ duration: 0.6 }}
      >
        {/* 🏞 Banner */}
        <section className="relative w-full h-[400px] overflow-hidden">
          <Image
            src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
            alt="Banner Du lịch Việt Nam"
            fill
            className="object-cover brightness-75"
            priority
            unoptimized
          />
          <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white">
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-4xl font-bold mb-3 drop-shadow-md"
            >
              Du lịch trong nước
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="text-lg max-w-2xl"
            >
              Trải nghiệm hành trình khám phá vẻ đẹp Việt Nam từ Bắc chí Nam —
              những điểm đến bạn không thể bỏ lỡ.
            </motion.p>
          </div>
        </section>

        {/* 🌿 Giới thiệu */}
        <section className="text-center py-12 bg-gray-50 px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl font-bold text-green-700 mb-3"
          >
            🌿 Điểm đến nổi bật
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-gray-600 max-w-3xl mx-auto"
          >
            Cùng chúng tôi khám phá những địa danh nổi tiếng, thiên nhiên hùng vĩ
            và văn hóa đặc sắc trải dài khắp Việt Nam.
          </motion.p>
        </section>

        {/* 🧭 Danh sách tour */}
        <section className="max-w-6xl mx-auto px-6 pb-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {tours.map((tour, i) => (
              <motion.div
                key={tour.id}
                initial={{ opacity: 0, scale: 0.95, y: 30 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden"
              >
                <Image
                  src={tour.image}
                  alt={tour.name}
                  width={400}
                  height={250}
                  className="w-full h-52 object-cover"
                  unoptimized
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold">{tour.name}</h3>
                  <p className="text-gray-600 text-sm mt-1">
                    {tour.description}
                  </p>
                  <p className="text-green-700 font-semibold mt-2">
                    {tour.price}
                  </p>
                  <div className="flex justify-between mt-3">
                    <button
                      onClick={() =>
                        router.push(`/tour-tron-goi/trong-nuoc/${tour.id}`)
                      }
                      className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300 transition"
                    >
                      Xem
                    </button>
                    <button
                      onClick={() =>
                        router.push(
                          `/tour-tron-goi/trong-nuoc/${tour.id}?book=true`
                        )
                      }
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
                    >
                      Đặt ngay
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 🦶 Footer */}
        <footer className="bg-green-700 text-white py-6 text-center">
          <p>© 2025 VietTravel. Tất cả bản quyền được bảo lưu.</p>
        </footer>
      </motion.main>
    </AnimatePresence>
  );
}
