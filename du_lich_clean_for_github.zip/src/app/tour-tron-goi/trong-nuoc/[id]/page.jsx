"use client";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";
import { useState } from "react";

export default function TourDetail() {
  const { id } = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);

  const tours = {
    "ha-long-yen-tu": {
      name: "Hạ Long - Yên Tử",
      price: "2.500.000đ",
      image: "https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg",
      description:
        "Khám phá Vịnh Hạ Long và Yên Tử linh thiêng, nơi giao hòa giữa biển trời và núi non hùng vĩ.",
    },
    "sapa-lao-cai": {
      name: "Sapa - Lào Cai",
      price: "3.000.000đ",
      image: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg",
      description:
        "Trải nghiệm không khí se lạnh vùng cao, săn mây và khám phá bản làng Tây Bắc thơ mộng.",
    },
    hue: {
      name: "Huế",
      price: "2.200.000đ",
      image:
        "https://www.vietnamairlines.com/~/media/Images/Discovery/Vietnam/HUE/canh%20dep/1920x1080/Hue_canhdep_cung_dinh_hue_1920x1080.jpg",
      description:
        "Hành trình về cố đô, thăm Đại Nội, chùa Thiên Mụ và thưởng thức ẩm thực cung đình Huế.",
    },
    "quang-binh": {
      name: "Quảng Bình",
      price: "2.700.000đ",
      image:
        "https://bestbooking.vn/wp-content/uploads/2025/01/BestBooking-travel-tour-quang-binh-khoi-hanh-tu-hue-13-scaled.jpeg",
      description:
        "Khám phá động Phong Nha – Kẻ Bàng, di sản thiên nhiên thế giới nổi tiếng với hang động kỳ vĩ.",
    },
    "da-lat": {
      name: "Đà Lạt",
      price: "2.100.000đ",
      image:
        "https://peacetour.com.vn/Upload/TourInformation/401cc353-f67e-4f26-855c-f34ff0519ffd/du-lich-hoa-binh-tour-da-lat-xu-so-ngan-hoa-4-ngay-3-dem-quang-truong-lam-vien-2203.jpg",
      description:
        "Thành phố ngàn hoa, không khí mát lạnh quanh năm, thích hợp nghỉ dưỡng và check-in lãng mạn.",
    },
    "da-nang": {
      name: "Đà Nẵng",
      price: "2.400.000đ",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
      description:
        "Thành phố đáng sống nhất Việt Nam với Bà Nà Hills, cầu Rồng và biển Mỹ Khê tuyệt đẹp.",
    },
    "hoi-an": {
      name: "Hội An",
      price: "2.000.000đ",
      image:
        "https://viptrip.vn/public/upload/news/pho-co-hoi-an_31-12-2023_613395856.jpg",
      description:
        "Dạo bước trên phố cổ, thả đèn hoa đăng trên sông Hoài, cảm nhận nét yên bình và cổ kính.",
    },
    "mui-ne-ke-ga": {
      name: "Mũi Né - Kê Gà",
      price: "2.300.000đ",
      image: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg",
      description:
        "Khám phá đồi cát bay, biển xanh Bình Thuận và ngọn hải đăng Kê Gà nổi tiếng.",
    },
    "nha-trang": {
      name: "Nha Trang",
      price: "2.600.000đ",
      image: "https://images.pexels.com/photos/248797/pexels-photo-248797.jpeg",
      description:
        "Thiên đường du lịch biển đảo, tắm biển, lặn san hô và tham quan VinWonders Nha Trang.",
    },
    "quy-nhon": {
      name: "Quy Nhơn",
      price: "2.500.000đ",
      image:
        "https://th.bing.com/th/id/R.d514e05919e5f298b61576f6535bb48b?rik=qn9y%2bGFxfRKWwQ&pid=ImgRaw&r=0",
      description:
        "Vẻ đẹp hoang sơ của Eo Gió, Kỳ Co, hải sản tươi ngon và con người thân thiện miền Trung.",
    },
    "phu-quoc": {
      name: "Phú Quốc",
      price: "3.200.000đ",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
      description:
        "Thiên đường nghỉ dưỡng với biển xanh, cát trắng, resort sang trọng và ẩm thực phong phú.",
    },
    "vung-tau-ho-tram": {
      name: "Vũng Tàu - Hồ Tràm",
      price: "2.100.000đ",
      image: "https://image.vietgoing.com/editor/image_zqu1639033152.jpg",
      description:
        "Điểm đến lý tưởng gần Sài Gòn, tắm biển, thưởng thức hải sản tươi ngon và nghỉ dưỡng cuối tuần.",
    },
  };

  const tour = tours[id];
  if (!tour) return <p className="p-6">Tour không tồn tại.</p>;

  const handleBooking = (e) => {
    e.preventDefault();
    alert(
      `Đặt tour ${tour.name} thành công!\nNgày: ${date}\nSố người: ${people}`
    );
    router.push("/tour-tron-goi/trong-nuoc");
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <button
        onClick={() => router.back()}
        className="text-blue-600 underline mb-4"
      >
        ← Quay lại
      </button>

      <div className="bg-white shadow rounded-2xl overflow-hidden">
        <Image
          src={tour.image}
          alt={tour.name}
          width={800}
          height={400}
          className="w-full h-80 object-cover"
          unoptimized
        />
        <div className="p-6">
          <h1 className="text-3xl font-semibold mb-2">{tour.name}</h1>
          <p className="text-gray-700 mb-3">{tour.description}</p>
          <p className="text-green-700 text-xl font-bold mb-4">
            {tour.price}
          </p>

          <h2 className="text-lg font-semibold mb-2">📅 Lịch trình gợi ý:</h2>
          <ul className="list-disc ml-6 text-gray-700 mb-6">
            <li>
              <strong>Ngày 1:</strong> Khởi hành, tham quan các điểm du lịch nổi
              bật.
            </li>
            <li>
              <strong>Ngày 2:</strong> Khám phá địa phương, thưởng thức ẩm thực
              đặc sản.
            </li>
            <li>
              <strong>Ngày 3:</strong> Mua sắm đặc sản, kết thúc hành trình.
            </li>
          </ul>

          <form
            onSubmit={handleBooking}
            className="border-t pt-4 mt-4 flex flex-col gap-3"
          >
            <h3 className="text-lg font-semibold">📝 Đặt tour ngay</h3>
            <label className="flex flex-col">
              Ngày khởi hành:
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="border p-2 rounded mt-1"
              />
            </label>

            <label className="flex flex-col">
              Số người:
              <input
                type="number"
                min="1"
                value={people}
                onChange={(e) => setPeople(e.target.value)}
                className="border p-2 rounded mt-1 w-32"
              />
            </label>

            <button
              type="submit"
              className="bg-purple-600 text-white py-2 px-4 rounded-lg w-fit hover:bg-purple-700 transition"
            >
              Xác nhận đặt tour
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
