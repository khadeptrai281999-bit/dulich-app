"use client";
import { useState } from "react";

export default function NhatBanCaoCap() {
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);
  const price = 65000000;
  const total = price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: Tour Nhật Bản cao cấp\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">Tour Nhật Bản cao cấp</h1>
      <img
        src="https://datviettour.com.vn/uploads/images/tin-tuc/Tin-mo-ta-danh-muc-tour/nhat-ban/nhat-ban-1.jpg"
        alt="Tour Nhật Bản cao cấp"
        className="w-full h-96 object-cover rounded-2xl shadow mb-6"
      />

      <p className="text-lg mb-2"><strong>Giá tour:</strong> {price.toLocaleString()}₫</p>
      <p className="mb-6 text-gray-700">
        Trải nghiệm Tokyo – Kyoto – Osaka, ngắm núi Phú Sĩ và thưởng thức ẩm thực truyền thống.
      </p>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Tham quan núi Phú Sĩ và hồ Ashi</li>
          <li>Thưởng thức sushi truyền thống Nhật Bản</li>
          <li>Khám phá cố đô Kyoto</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">📅 Lịch trình</h2>
        <ul className="list-decimal list-inside space-y-1">
          <li>Ngày 1: Bay đến Tokyo</li>
          <li>Ngày 2: Tham quan núi Phú Sĩ</li>
          <li>Ngày 3: Kyoto cổ kính</li>
          <li>Ngày 4: Osaka – tự do mua sắm</li>
          <li>Ngày 5: Trở về Việt Nam</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Lưu ý</h2>
        <p>Nhiệt độ dao động thấp vào mùa xuân và thu, nên mang áo khoác mỏng.</p>
      </section>

      {/* FORM */}
      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div><label className="block mb-1">Ngày khởi hành:</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></div>
          <div><label className="block mb-1">Số người:</label><input type="number" min="1" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2" /></div>
          <div className="flex flex-col justify-end"><p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p></div>
        </div>
        <button onClick={handleBooking} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">Thanh toán ngay</button>
      </section>
    </div>
  );
}
