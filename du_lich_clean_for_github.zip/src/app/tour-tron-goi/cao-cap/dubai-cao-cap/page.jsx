"use client";
import { useState } from "react";

export default function DubaiCaoCap() {
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);
  const price = 72000000;
  const total = price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: Tour Dubai cao cấp\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">Tour Dubai cao cấp</h1>
      <img
        src="https://www.timeoutdubai.com/cloud/timeoutdubai/2021/09/10/wORipIir-Burj-Khalifa.jpg"
        alt="Tour Dubai cao cấp"
        className="w-full h-96 object-cover rounded-2xl shadow mb-6"
      />
      <p className="text-lg mb-2"><strong>Giá tour:</strong> {price.toLocaleString()}₫</p>
      <p className="mb-6 text-gray-700">
        Hành trình khám phá xứ sở xa hoa Trung Đông với những tòa tháp chọc trời và sa mạc vàng.
      </p>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Tham quan Burj Khalifa – tòa nhà cao nhất thế giới</li>
          <li>Trải nghiệm sa mạc Safari bằng xe Jeep</li>
          <li>Thưởng thức buffet tại khách sạn 7 sao Burj Al Arab</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Lưu ý</h2>
        <p>Không nên mặc đồ hở vai tại nơi công cộng. Giữ gìn văn hóa địa phương nghiêm ngặt.</p>
      </section>

      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div><label className="block mb-1">Ngày khởi hành:</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></div>
          <div><label className="block mb-1">Số người:</label><input type="number" min="1" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2" /></div>
          <div className="flex flex-col justify-end"><p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p></div>
        </div>
        <button onClick={handleBooking} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">Thanh toán ngay</button>
      </section>
    </div>
  );
}
