"use client";
import Image from "next/image";
import { useRouter } from "next/navigation";

export default function ComboMienBac() {
  const router = useRouter();

  const tours = [
    {
      id: "ha-long-yen-tu",
      name: "Hạ Long - Yên Tử",
      description: "Khám phá Vịnh Hạ Long và Yên Tử linh thiêng",
      price: "2.500.000đ",
      image: "https://images.pexels.com/photos/460672/pexels-photo-460672.jpeg",
    },
    {
      id: "sapa-lao-cai",
      name: "Sapa - Lào Cai",
      description: "Trải nghiệm cảnh sắc vùng núi phía Bắc",
      price: "3.000.000đ",
      image: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-green-800 mb-8 text-center">
        Combo du lịch Miền Bắc
      </h1>

      <div className="grid md:grid-cols-2 gap-6">
        {tours.map((tour) => (
          <div
            key={tour.id}
            className="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden"
          >
            <Image
              src={tour.image}
              alt={tour.name}
              width={500}
              height={300}
              className="w-full h-56 object-cover"
              unoptimized
            />
            <div className="p-5">
              <h2 className="text-xl font-semibold text-green-800 mb-2">
                {tour.name}
              </h2>
              <p className="text-gray-600 mb-2">{tour.description}</p>
              <p className="text-green-700 font-bold text-lg mb-4">
                {tour.price}
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() =>
                    router.push(`/tour-tron-goi/trong-nuoc/${tour.id}`)
                  }
                  className="bg-gray-200 px-4 py-2 rounded hover:bg-gray-300"
                >
                  Xem
                </button>
                <button
                  onClick={() =>
                    router.push(`/tour-tron-goi/trong-nuoc/${tour.id}`)
                  }
                  className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
                >
                  Đặt ngay
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
