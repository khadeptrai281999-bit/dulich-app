import Image from "next/image";
import Link from "next/link";

export default function ComboMienTrung() {
  const tours = [
    {
      id: 1,
      title: "Đà Nẵng",
      desc: "Khám phá thành phố biển miền Trung",
      price: "2.400.000đ",
      image:
        "https://images.pexels.com/photos/258136/pexels-photo-258136.jpeg",
      link: "/tour-tron-goi/trong-nuoc/da-nang",
    },
    {
      id: 2,
      title: "Huế",
      desc: "Hành trình cố đô Huế mộng mơ",
      price: "2.200.000đ",
      image:
        "https://images.pexels.com/photos/161853/hue-vietnam-imperial-city-architecture-161853.jpeg",
      link: "/tour-tron-goi/trong-nuoc/hue",
    },
    {
      id: 3,
      title: "Hội An",
      desc: "Thành phố cổ yên bình và thơ mộng",
      price: "2.000.000đ",
      image:
        "https://images.pexels.com/photos/460376/pexels-photo-460376.jpeg",
      link: "/tour-tron-goi/trong-nuoc/hoi-an",
    },
    {
      id: 4,
      title: "Quy Nhơn",
      desc: "Thành phố biển yên bình với cảnh sắc hoang sơ",
      price: "2.500.000đ",
      image:
        "https://images.pexels.com/photos/355866/pexels-photo-355866.jpeg",
      link: "/tour-tron-goi/trong-nuoc/quy-nhon",
    },
    {
      id: 5,
      title: "Quảng Bình",
      desc: "Khám phá động Phong Nha – Kẻ Bàng",
      price: "2.700.000đ",
      image:
        "https://images.pexels.com/photos/1146708/pexels-photo-1146708.jpeg",
      link: "/tour-tron-goi/trong-nuoc/quang-binh",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-emerald-800 mb-6">
        Combo du lịch Miền Trung
      </h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tours.map((tour) => (
          <div
            key={tour.id}
            className="border rounded-xl overflow-hidden shadow hover:shadow-lg transition"
          >
            <Image
              src={tour.image}
              alt={tour.title}
              width={600}
              height={400}
              className="w-full h-64 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold text-emerald-700">
                {tour.title}
              </h2>
              <p className="text-gray-600 mt-2">{tour.desc}</p>
              <p className="text-green-700 font-bold mt-2">{tour.price}</p>
              <div className="flex gap-3 mt-3">
                <Link
                  href={tour.link}
                  className="px-4 py-2 bg-gray-100 rounded hover:bg-gray-200"
                >
                  Xem
                </Link>
                <Link
                  href={tour.link}
                  className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
                >
                  Đặt ngay
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
