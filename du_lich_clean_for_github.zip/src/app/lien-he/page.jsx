"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import ScrollReveal from "@/components/ScrollReveal";
import { MapPin, Phone, Mail } from "lucide-react";

export default function LienHePage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất có thể.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="bg-white text-gray-800 overflow-hidden">
      {/* --- Banner --- */}
      <div className="relative h-[350px] overflow-hidden">
        <img
          src="https://images.pexels.com/photos/346885/pexels-photo-346885.jpeg"
          alt="Liên hệ Dream Trip"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-white text-4xl md:text-5xl font-bold"
          >
            Liên hệ với Dream Trip
          </motion.h1>
          <p className="text-gray-200 mt-4 text-lg">
            Chúng tôi luôn sẵn sàng hỗ trợ bạn 24/7 💬
          </p>
        </div>
      </div>

      {/* --- Nội dung chính --- */}
      <div className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-12">
        {/* --- Thông tin liên hệ --- */}
        <ScrollReveal>
          <div>
            <h2 className="text-3xl font-semibold text-green-700 mb-6">
              Thông tin liên hệ
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              Hãy để lại lời nhắn hoặc liên hệ trực tiếp với chúng tôi qua các kênh dưới đây.
              Dream Trip luôn sẵn sàng đồng hành cùng bạn trên mọi hành trình!
            </p>

            <div className="space-y-4 text-gray-700">
              <div className="flex items-start gap-3">
                <MapPin className="text-green-700 mt-1" />
                <p>123 Nguyễn Trãi, Quận 1, TP. Hồ Chí Minh</p>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="text-green-700 mt-1" />
                <p>Hotline: 0995 154 035 (Hỗ trợ 24/7)</p>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="text-green-700 mt-1" />
                <p>Email: support@dreamtrip.vn</p>
              </div>
            </div>

            {/* --- Bản đồ Google --- */}
            <div className="mt-10 rounded-xl overflow-hidden shadow-md">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.4809500707885!2d106.690078675888!3d10.774966389374174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f3d763fe56b%3A0x8d228c520a1d08a0!2zMTIzIE5ndXnhu4VuIFRy4bqhaSwgUGjGsOG7nW5nIDUsIFF14bqjbSDEkOG7kW5nLCBUUC4gSOG7kyBDaMOtbmggTWluaA!5e0!3m2!1svi!2s!4v1696908723749!5m2!1svi!2s"
                width="100%"
                height="280"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </ScrollReveal>

        {/* --- Form liên hệ --- */}
        <ScrollReveal delay={0.2}>
          <form
            onSubmit={handleSubmit}
            className="bg-green-50 p-8 rounded-2xl shadow-lg"
          >
            <h2 className="text-3xl font-semibold text-green-700 mb-6">
              Gửi tin nhắn cho chúng tôi
            </h2>

            <div className="space-y-5">
              <div>
                <label className="block text-gray-700 font-medium mb-1">
                  Họ và tên
                </label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                  placeholder="Nhập họ tên của bạn"
                  className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-medium mb-1">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  placeholder="Nhập email liên hệ"
                  className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-medium mb-1">
                  Nội dung
                </label>
                <textarea
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  required
                  placeholder="Nhập nội dung bạn muốn gửi..."
                  rows="6"
                  className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                ></textarea>
              </div>

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                type="submit"
                className="w-full bg-green-700 hover:bg-green-800 text-white font-semibold py-3 rounded-lg transition"
              >
                Gửi liên hệ
              </motion.button>
            </div>
          </form>
        </ScrollReveal>
      </div>
    </div>
  );
}
