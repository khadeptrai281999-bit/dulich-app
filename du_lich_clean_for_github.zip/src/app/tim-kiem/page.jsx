"use client";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";

// 📌 Dữ liệu mẫu đầy đủ (khách sạn, tour, combo)
const dataDuLich = [
  // === KHÁCH SẠN ===
  { id: 1, type: "khach-san", diaDiem: "ha-noi", ten: "Khách sạn Hà Nội sang trọng", moTa: "Trung tâm thủ đô, gần Hồ Gươm, phòng tiện nghi hiện đại.", hinhAnh: "https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg" },
  { id: 2, type: "khach-san", diaDiem: "da-nang", ten: "Khách sạn Đà Nẵng ven biển", moTa: "Phòng hướng biển, gần cầu Rồng và trung tâm thành phố.", hinhAnh: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg" },
  { id: 3, type: "khach-san", diaDiem: "nha-trang", ten: "Khách sạn Nha Trang 4 sao", moTa: "View biển tuyệt đẹp, gần chợ đêm và khu phố Tây.", hinhAnh: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg" },
  { id: 4, type: "khach-san", diaDiem: "hue", ten: "Khách sạn Imperial Huế", moTa: "Gần sông Hương, kiến trúc hoàng gia cổ kính và sang trọng.", hinhAnh: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg" },
  { id: 5, type: "khach-san", diaDiem: "hoi-an-quang-nam", ten: "Khách sạn Hội An Resort", moTa: "Resort cao cấp ven sông, phong cách cổ điển.", hinhAnh: "https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg" },
  { id: 6, type: "khach-san", diaDiem: "phu-quoc", ten: "Khách sạn Phú Quốc 5 sao", moTa: "Khu nghỉ dưỡng cao cấp, hồ bơi hướng biển.", hinhAnh: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg" },
  { id: 7, type: "khach-san", diaDiem: "da-lat", ten: "Khách sạn Đà Lạt trung tâm", moTa: "Nằm gần chợ đêm Đà Lạt, phòng view hồ Xuân Hương.", hinhAnh: "https://images.pexels.com/photos/461940/pexels-photo-461940.jpeg" },
  { id: 8, type: "khach-san", diaDiem: "quy-nhon", ten: "Khách sạn Quy Nhơn view biển", moTa: "Phòng cao cấp hướng biển, gần bãi Kỳ Co và Eo Gió.", hinhAnh: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg" },
  { id: 9, type: "khach-san", diaDiem: "sapa-lao-cai", ten: "Khách sạn Sapa view núi", moTa: "Phòng hướng Fansipan, phong cách ấm cúng và sang trọng.", hinhAnh: "https://images.pexels.com/photos/2880507/pexels-photo-2880507.jpeg" },
  { id: 10, type: "khach-san", diaDiem: "ha-long", ten: "Khách sạn Hạ Long view vịnh", moTa: "Tận hưởng vẻ đẹp vịnh Hạ Long ngay từ cửa sổ phòng.", hinhAnh: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg" },

  // === TOUR DU LỊCH ===
  { id: 11, type: "tour", diaDiem: "ha-long", ten: "Tour Hạ Long – Yên Tử 2N1Đ", moTa: "Khám phá vịnh Hạ Long và viếng chùa Đồng – Yên Tử.", hinhAnh: "https://images.pexels.com/photos/132037/pexels-photo-132037.jpeg" },
  { id: 12, type: "tour", diaDiem: "da-nang", ten: "Tour Đà Nẵng – Hội An 3N2Đ", moTa: "Tham quan Bà Nà Hills, phố cổ Hội An và Ngũ Hành Sơn.", hinhAnh: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg" },
  { id: 13, type: "tour", diaDiem: "nha-trang", ten: "Tour Nha Trang – Hòn Mun – Vinpearl", moTa: "Trải nghiệm du lịch biển, tham quan đảo và lặn ngắm san hô.", hinhAnh: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg" },
  { id: 14, type: "tour", diaDiem: "hue", ten: "Tour Huế – Đại Nội – Chùa Thiên Mụ", moTa: "Tham quan quần thể di tích Cố đô Huế, văn hóa hoàng gia.", hinhAnh: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg" },
  { id: 15, type: "tour", diaDiem: "hoi-an-quang-nam", ten: "Tour Hội An – Cù Lao Chàm", moTa: "Tham quan phố cổ, biển An Bàng và đảo Cù Lao Chàm.", hinhAnh: "https://images.pexels.com/photos/2880507/pexels-photo-2880507.jpeg" },
  { id: 16, type: "tour", diaDiem: "phu-quoc", ten: "Tour Phú Quốc 3N2Đ – Nam đảo", moTa: "Tham quan Hòn Thơm, lặn biển và thưởng thức hải sản.", hinhAnh: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg" },
  { id: 17, type: "tour", diaDiem: "da-lat", ten: "Tour Đà Lạt 3N2Đ – Thành phố ngàn hoa", moTa: "Tham quan Thung lũng Tình Yêu, Langbiang và hồ Tuyền Lâm.", hinhAnh: "https://images.pexels.com/photos/462162/pexels-photo-462162.jpeg" },
  { id: 18, type: "tour", diaDiem: "quy-nhon", ten: "Tour Quy Nhơn – Kỳ Co – Eo Gió", moTa: "Khám phá biển đảo, thưởng thức ẩm thực miền Trung.", hinhAnh: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg" },
  { id: 19, type: "tour", diaDiem: "sapa-lao-cai", ten: "Tour Sapa – Lào Cai – Fansipan", moTa: "Chinh phục đỉnh Fansipan, bản Cát Cát và thác Bạc.", hinhAnh: "https://images.pexels.com/photos/2880507/pexels-photo-2880507.jpeg" },

  // === COMBO DU LỊCH ===
  { id: 20, type: "combo", diaDiem: "da-nang", ten: "Combo Đà Nẵng – Hội An 3N2Đ", moTa: "Bao gồm vé máy bay, khách sạn và tour tham quan Hội An.", hinhAnh: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg" },
  { id: 21, type: "combo", diaDiem: "nha-trang", ten: "Combo Nha Trang – Nghỉ dưỡng 5 sao", moTa: "Bao gồm khách sạn view biển, buffet sáng và vé Vinpearl.", hinhAnh: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg" },
  { id: 22, type: "combo", diaDiem: "hue", ten: "Combo Huế – Đại Nội – Chùa Thiên Mụ", moTa: "Trọn gói vé máy bay, khách sạn và tour tham quan di tích.", hinhAnh: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg" },
  { id: 23, type: "combo", diaDiem: "hoi-an-quang-nam", ten: "Combo Hội An – Phố cổ và biển An Bàng", moTa: "Gói nghỉ dưỡng + vé máy bay + city tour cổ kính.", hinhAnh: "https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg" },
  { id: 24, type: "combo", diaDiem: "phu-quoc", ten: "Combo Phú Quốc 4N3Đ cao cấp", moTa: "Vé máy bay khứ hồi, resort 5 sao và xe đưa đón sân bay.", hinhAnh: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg" },
  { id: 25, type: "combo", diaDiem: "da-lat", ten: "Combo Đà Lạt 3N2Đ – Bay và nghỉ dưỡng", moTa: "Bao gồm vé máy bay + khách sạn + city tour.", hinhAnh: "https://images.pexels.com/photos/461940/pexels-photo-461940.jpeg" },
  { id: 26, type: "combo", diaDiem: "quy-nhon", ten: "Combo Quy Nhơn – Biển xanh cát trắng", moTa: "Combo khách sạn 4 sao + vé máy bay + tham quan Eo Gió.", hinhAnh: "https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg" },
  { id: 27, type: "combo", diaDiem: "sapa-lao-cai", ten: "Combo Sapa 3N2Đ – Fansipan Huyền thoại", moTa: "Bao gồm khách sạn + vé tàu + tour tham quan.", hinhAnh: "https://images.pexels.com/photos/2880507/pexels-photo-2880507.jpeg" },
  { id: 28, type: "combo", diaDiem: "ha-long", ten: "Combo Hạ Long – Yên Tử 3N2Đ", moTa: "Bao gồm khách sạn, tour vịnh Hạ Long và vé cáp treo Yên Tử.", hinhAnh: "https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg" },
];


export default function TimKiemPage() {
  const searchParams = useSearchParams();
  const keyword = searchParams.get("keyword") || "";
  const diaDiem = searchParams.get("diaDiem") || "";
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  // Giả lập load dữ liệu
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const filtered = dataDuLich.filter(
        (item) =>
          (!diaDiem || item.diaDiem === diaDiem) &&
          (!keyword || item.ten.toLowerCase().includes(keyword.toLowerCase()))
      );
      setResults(filtered);
      setLoading(false);
    }, 800);
  }, [keyword, diaDiem]);

  // Nhóm kết quả theo loại
  const groupedResults = {
    khachsan: results.filter((r) => r.type === "khach-san"),
    tour: results.filter((r) => r.type === "tour"),
    combo: results.filter((r) => r.type === "combo"),
  };

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <h1 className="text-3xl font-bold text-center text-green-800 mb-8">
        🔍 Kết quả tìm kiếm
      </h1>

      {loading ? (
        // Loading Spinner
        <div className="flex justify-center items-center h-60">
          <div className="w-12 h-12 border-4 border-green-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : results.length === 0 ? (
        // Không có kết quả
        <p className="text-center text-gray-600 text-lg">
          Không tìm thấy kết quả phù hợp. Vui lòng thử từ khóa hoặc địa điểm khác.
        </p>
      ) : (
        <div className="space-y-12">
          {/* Khách sạn */}
          {groupedResults.khachsan.length > 0 && (
            <div>
              <h2 className="text-2xl font-semibold text-lime-700 mb-4">🏨 Khách sạn</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {groupedResults.khachsan.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white shadow-md rounded-xl overflow-hidden hover:shadow-lg transition"
                  >
                    <img src={item.img} alt={item.ten} className="h-48 w-full object-cover" />
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800">{item.ten}</h3>
                      <p className="text-sm text-gray-600 capitalize">{item.diaDiem.replace("-", " ")}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Tour du lịch */}
          {groupedResults.tour.length > 0 && (
            <div>
              <h2 className="text-2xl font-semibold text-blue-700 mb-4">🧳 Tour du lịch</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {groupedResults.tour.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white shadow-md rounded-xl overflow-hidden hover:shadow-lg transition"
                  >
                    <img src={item.img} alt={item.ten} className="h-48 w-full object-cover" />
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800">{item.ten}</h3>
                      <p className="text-sm text-gray-600 capitalize">{item.diaDiem.replace("-", " ")}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Combo du lịch */}
          {groupedResults.combo.length > 0 && (
            <div>
              <h2 className="text-2xl font-semibold text-orange-700 mb-4">🎫 Combo du lịch</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {groupedResults.combo.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white shadow-md rounded-xl overflow-hidden hover:shadow-lg transition"
                  >
                    <img src={item.img} alt={item.ten} className="h-48 w-full object-cover" />
                    <div className="p-4">
                      <h3 className="font-bold text-gray-800">{item.ten}</h3>
                      <p className="text-sm text-gray-600 capitalize">{item.diaDiem.replace("-", " ")}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
