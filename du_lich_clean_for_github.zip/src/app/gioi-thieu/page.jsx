"use client";
import { motion } from "framer-motion";

export default function GioiThieuPage() {
  const fadeIn = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8 } },
  };

  return (
    <div className="bg-white text-gray-800 overflow-hidden">
      {/* Banner với hiệu ứng parallax */}
      <div className="relative h-80 md:h-[400px] overflow-hidden">
        <div
          className="absolute inset-0 bg-fixed bg-center bg-cover"
          style={{
            backgroundImage:
              "url('https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg')",
          }}
        ></div>
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="text-white text-4xl md:text-5xl font-bold text-center"
          >
            Giới Thiệu Về Dream Trip
          </motion.h1>
        </div>
      </div>

      {/* Nội dung chính */}
      <div className="max-w-6xl mx-auto px-6 py-16 space-y-16">
        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Tổng Quan</h2>
          <p className="text-lg leading-relaxed">
            <strong>Dream Trip</strong> là nền tảng đặt tour, khách sạn và combo du lịch trực tuyến hàng đầu Việt Nam.
            Chúng tôi mong muốn mang đến cho du khách những trải nghiệm du lịch trọn vẹn, tiện lợi và đáng nhớ — từ
            khâu lên kế hoạch cho đến khi kết thúc hành trình.
          </p>
          <p className="mt-4 text-lg leading-relaxed">
            Với giao diện thân thiện, hệ thống tìm kiếm thông minh và hàng ngàn lựa chọn chất lượng, Dream Trip cam kết
            trở thành người bạn đồng hành đáng tin cậy trên mọi chuyến đi của bạn.
          </p>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Sứ Mệnh</h2>
          <p className="text-lg leading-relaxed">
            Sứ mệnh của chúng tôi là <strong>“kết nối con người thông qua những hành trình ý nghĩa”</strong>. Dream Trip
            không chỉ giúp khách hàng đặt dịch vụ du lịch dễ dàng, mà còn mang đến giá trị tinh thần – niềm vui, sự thư
            giãn và khám phá văn hóa, con người ở khắp mọi miền đất nước.
          </p>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Tầm Nhìn</h2>
          <p className="text-lg leading-relaxed">
            Trở thành <strong>nền tảng du lịch toàn diện hàng đầu Việt Nam</strong>, giúp du khách khám phá mọi điểm đến
            trong nước và quốc tế với sự thuận tiện tối đa, chất lượng vượt trội và giá cả hợp lý.
          </p>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Giá Trị Cốt Lõi</h2>
          <ul className="list-disc pl-6 space-y-2 text-lg">
            <li><strong>Uy tín:</strong> Luôn đặt niềm tin và sự hài lòng của khách hàng lên hàng đầu.</li>
            <li><strong>Chất lượng:</strong> Đảm bảo dịch vụ đạt chuẩn, từ khách sạn, tour cho đến trải nghiệm.</li>
            <li><strong>Đổi mới:</strong> Ứng dụng công nghệ hiện đại giúp việc đặt dịch vụ dễ dàng và nhanh chóng.</li>
            <li><strong>Trách nhiệm:</strong> Hướng đến phát triển du lịch bền vững và tôn trọng văn hóa địa phương.</li>
          </ul>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Cam Kết Dịch Vụ</h2>
          <ul className="list-disc pl-6 space-y-2 text-lg">
            <li>Giá cả minh bạch, không phát sinh chi phí ẩn.</li>
            <li>Hỗ trợ 24/7 trong suốt hành trình.</li>
            <li>Dịch vụ đặt phòng, tour, vé nhanh chóng chỉ với vài thao tác.</li>
            <li>Đội ngũ tư vấn tận tâm, am hiểu điểm đến.</li>
          </ul>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Đội Ngũ Dream Trip</h2>
          <p className="text-lg leading-relaxed">
            Dream Trip được vận hành bởi một tập thể trẻ trung, năng động, giàu kinh nghiệm trong lĩnh vực du lịch và công nghệ.
            Chúng tôi không ngừng học hỏi và cải tiến để mang lại trải nghiệm tốt nhất cho khách hàng.
          </p>
        </motion.section>

        <motion.section
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-semibold mb-4 text-green-700">Thông Tin Liên Hệ</h2>
          <p className="text-lg leading-relaxed">📍 Địa chỉ: 123 Nguyễn Trãi, Quận 1, TP. Hồ Chí Minh</p>
          <p className="text-lg leading-relaxed">📞 Hotline: 0995154035</p>
          <p className="text-lg leading-relaxed">📧 Email: support@dreamtrip.vn</p>
          <p className="text-lg leading-relaxed">🌐 Website: https://dreamtrip.vn</p>
        </motion.section>
      </div>
    </div>
  );
}
