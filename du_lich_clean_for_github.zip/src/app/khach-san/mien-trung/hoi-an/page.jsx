"use client";
import Link from "next/link";

const hotels = [
  { id: 1, name: "Four Seasons Resort The Nam Hai", stars: 5, price: 12500000, image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80" },
  { id: 2, name: "Palm Garden Beach Resort & Spa", stars: 5, price: 4500000, image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80" },
  { id: 3, name: "La Siesta Resort & Spa Hoi An", stars: 5, price: 4200000, image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80" },
  { id: 4, name: "Victoria Hoi An Beach Resort & Spa", stars: 4, price: 3600000, image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80" },
  { id: 5, name: "Sunrise Premium Resort Hoi An", stars: 5, price: 4800000, image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80" },
  { id: 6, name: "Almanity Hoi An Resort & Spa", stars: 4, price: 3400000, image: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80" },
  { id: 7, name: "Silk Sense Hoi An River Resort", stars: 5, price: 3900000, image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80" },
  { id: 8, name: "Belle Maison Hadana Hoi An", stars: 4, price: 2800000, image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80" },
  { id: 9, name: "Hoi An Beach Resort", stars: 4, price: 3000000, image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80" },
  { id: 10, name: "Lantana Riverside Hoi An Boutique Hotel", stars: 4, price: 2500000, image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80" },
];

export default function HoiAnList() {
  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-green-800 text-center">
        Danh sách khách sạn 4★ & 5★ tại Hội An
      </h1>
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <div key={hotel.id} className="bg-white shadow-lg rounded-2xl overflow-hidden">
            <img src={hotel.image} alt={hotel.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h2 className="font-semibold text-lg mb-1 text-green-800">{hotel.name}</h2>
              <p className="text-yellow-500 text-sm mb-1">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
              <p className="text-gray-700 mb-3">{hotel.price.toLocaleString("vi-VN")} VNĐ / đêm</p>
              <div className="flex gap-2">
                <Link
                  href={`/khach-san/mien-trung/hoi-an/${hotel.id}`}
                  className="flex-1 text-white bg-green-700 hover:bg-green-800 transition px-4 py-2 rounded-lg text-sm text-center"
                >
                  Xem chi tiết
                </Link>
                <button
                  onClick={() => alert(`Đặt phòng nhanh: ${hotel.name}`)}
                  className="bg-transparent border border-green-700 text-green-700 px-4 py-2 rounded-lg hover:bg-green-50 transition text-sm"
                >
                  Đặt nhanh
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
