"use client";
import Link from "next/link";

const hotels = [
  {
    id: 1,
    name: "Vinpearl Luxury Đà Nẵng",
    stars: 5,
    price: "4.200.000",
    image: "https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 2,
    name: "Furama Resort Đà Nẵng",
    stars: 5,
    price: "3.800.000",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 3,
    name: "InterContinental Danang Sun Peninsula Resort",
    stars: 5,
    price: "12.500.000",
    image: "https://images.unsplash.com/photo-1587502536263-3e1a3f6e49d3?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 4,
    name: "Naman Retreat Resort",
    stars: 5,
    price: "3.200.000",
    image: "https://images.unsplash.com/photo-1551888419-7b7a520fe9f9?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 5,
    name: "Hyatt Regency Đà Nẵng",
    stars: 5,
    price: "3.500.000",
    image: "https://images.unsplash.com/photo-1582719478181-d9897fbd2d34?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 6,
    name: "Premier Village Danang Resort",
    stars: 5,
    price: "4.800.000",
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 7,
    name: "Pullman Danang Beach Resort",
    stars: 5,
    price: "3.900.000",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 8,
    name: "Grand Mercure Danang",
    stars: 4,
    price: "2.600.000",
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 9,
    name: "Melia Danang Beach Resort",
    stars: 5,
    price: "3.300.000",
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 10,
    name: "Mandila Beach Hotel",
    stars: 4,
    price: "2.200.000",
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 11,
    name: "Sala Danang Beach Hotel",
    stars: 4,
    price: "2.000.000",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 12,
    name: "TMS Hotel Da Nang Beach",
    stars: 5,
    price: "3.000.000",
    image: "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 13,
    name: "Four Points by Sheraton Danang",
    stars: 5,
    price: "3.400.000",
    image: "https://images.unsplash.com/photo-1582719478173-2d4df6cde8e3?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 14,
    name: "A La Carte Danang Beach",
    stars: 4,
    price: "2.400.000",
    image: "https://images.unsplash.com/photo-1582719478145-3d6b94f36ef6?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 15,
    name: "HAIAN Beach Hotel & Spa",
    stars: 4,
    price: "2.300.000",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1600&q=80",
  },
];

export default function HotelList() {
  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-green-800 text-center">
        Danh sách khách sạn 4★ & 5★ tại Đà Nẵng
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <div
            key={hotel.id}
            className="bg-white shadow-lg rounded-2xl overflow-hidden"
          >
            <img
              src={hotel.image}
              alt={hotel.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="font-semibold text-lg mb-1 text-green-800">
                {hotel.name}
              </h2>
              <p className="text-yellow-500 text-sm mb-1">
                {"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}
              </p>
              <p className="text-gray-700 mb-2">{hotel.price} VNĐ / đêm</p>
              <Link
                href={`/khach-san/mien-trung/da-nang/${hotel.id}`}
                className="text-white bg-green-700 hover:bg-green-800 transition px-4 py-2 rounded-lg text-sm"
              >
                Xem chi tiết
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
