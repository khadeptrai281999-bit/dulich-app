"use client";
import { useParams } from "next/navigation";
import Link from "next/link";

const hotels = [
  {
    id: 1,
    name: "Vinpearl Luxury Đà Nẵng",
    stars: 5,
    price: "4.200.000",
    image:
      "https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1590490360189-56b8b5e0d9b6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Vinpearl Luxury Đà Nẵng là khu nghỉ dưỡng sang trọng bậc nhất bên bãi biển Non Nước, với view hướng biển tuyệt đẹp, spa, hồ bơi vô cực và ẩm thực đẳng cấp quốc tế.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.915365424464!2d108.25403547522038!3d16.067728588887712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142177b44455c99%3A0x4e2e8618a4ed918!2sVinpearl%20Luxury%20Da%20Nang!5e0!3m2!1svi!2s!4v1696523212921!5m2!1svi!2s",
  },
  {
    id: 2,
    name: "Furama Resort Đà Nẵng",
    stars: 5,
    price: "3.800.000",
    image:
      "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1551888419-7b7a520fe9f9?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Furama Resort nổi tiếng với kiến trúc cổ điển hòa cùng cảnh quan biển Mỹ Khê, phục vụ theo tiêu chuẩn quốc tế, phù hợp cả cho nghỉ dưỡng gia đình và sự kiện.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3834.0154515534633!2d108.24223747522031!3d16.063651088891505!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219c7649e39f9%3A0x8b3c5a87a07b50cb!2sFurama%20Resort%20Danang!5e0!3m2!1svi!2s!4v1696523307856!5m2!1svi!2s",
  },
  {
    id: 3,
    name: "InterContinental Danang Sun Peninsula Resort",
    stars: 5,
    price: "12.500.000",
    image:
      "https://images.unsplash.com/photo-1587502536263-3e1a3f6e49d3?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "InterContinental Sun Peninsula — resort siêu sang nằm trên bán đảo Sơn Trà, thiết kế bởi Bill Bensley, nổi tiếng bởi trải nghiệm ẩm thực, spa và tính riêng tư cao.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3835.0573472272445!2d108.29277477521958!3d16.023789788933577!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219f6f363b7a3%3A0x828308b52e6b72e1!2sInterContinental%20Danang%20Sun%20Peninsula%20Resort!5e0!3m2!1svi!2s!4v1696523414526!5m2!1svi!2s",
  },
  {
    id: 4,
    name: "Naman Retreat Resort",
    stars: 5,
    price: "3.200.000",
    image:
      "https://images.unsplash.com/photo-1551888419-7b7a520fe9f9?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1496412705862-e0088f16f791?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Naman Retreat hòa hợp kiến trúc tre với thiên nhiên, là lựa chọn cho kỳ nghỉ thư giãn giữa sân golf và biển, nổi bật bởi không gian yên tĩnh, biệt lập.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.2173426225074!2d108.30347197522088!3d16.094040088862973!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142198d27ce8715%3A0x59e2302a39b6cb8c!2sNaman%20Retreat!5e0!3m2!1svi!2s!4v1696523909876!5m2!1svi!2s",
  },
  {
    id: 5,
    name: "Hyatt Regency Đà Nẵng",
    stars: 5,
    price: "3.500.000",
    image:
      "https://images.unsplash.com/photo-1582719478181-d9897fbd2d34?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Hyatt Regency tọa lạc sát bãi Non Nước, nội thất hiện đại và dịch vụ chuẩn quốc tế; phù hợp khách công tác và gia đình.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.509737264032!2d108.25805917522056!3d16.08317858887304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142197c04a05003%3A0x1c8e7588e3a59dcb!2sHyatt%20Regency%20Danang!5e0!3m2!1svi!2s!4v1696524048852!5m2!1svi!2s",
  },
  {
    id: 6,
    name: "Premier Village Danang Resort",
    stars: 5,
    price: "4.800.000",
    image:
      "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Premier Village là khu biệt thự nghỉ dưỡng ven biển, phù hợp cho những ai muốn có không gian riêng tư, villa view biển và dịch vụ cao cấp.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.721907417055!2d108.24338477522048!3d16.075088188880042!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219d2767c94c5%3A0x190f5e2c49f90c0c!2sPremier%20Village%20Danang%20Resort!5e0!3m2!1svi!2s!4v1696524117448!5m2!1svi!2s",
  },
  {
    id: 7,
    name: "Pullman Danang Beach Resort",
    stars: 5,
    price: "3.900.000",
    image:
      "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Pullman Danang Beach Resort nằm bên bãi Bắc Mỹ An, phong cách trẻ trung và dịch vụ chuyên nghiệp, phù hợp khách du lịch cao cấp và nhóm gia đình.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.792541512944!2d108.24211887522052!3d16.072565688882385!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e52b987adb%3A0xeef7b6e48dbfe7f!2sPullman%20Danang%20Beach%20Resort!5e0!3m2!1svi!2s!4v1696524248912!5m2!1svi!2s",
  },
  {
    id: 8,
    name: "Grand Mercure Danang",
    stars: 4,
    price: "2.600.000",
    image:
      "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Grand Mercure tọa lạc ngay trung tâm, thuận tiện cho việc di chuyển tham quan thành phố, shopping, và tiếp cận các điểm ăn uống địa phương.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3834.2229137926227!2d108.23133637522027!3d16.05595938889824!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314218374a4dca41%3A0x43df2a9adf56a171!2sGrand%20Mercure%20Danang!5e0!3m2!1svi!2s!4v1696524336759!5m2!1svi!2s",
  },
  {
    id: 9,
    name: "Melia Danang Beach Resort",
    stars: 5,
    price: "3.300.000",
    image:
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Melia Danang Beach Resort có bãi biển riêng, phong cách phục vụ pha trộn giữa phong cách châu Âu và địa phương, phù hợp kỳ nghỉ gia đình.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.0397851628843!2d108.2980972752209!3d16.100779488857107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142198a74c37d09%3A0x3cf16da9b8b5f6b1!2sMelia%20Danang%20Beach%20Resort!5e0!3m2!1svi!2s!4v1696524409124!5m2!1svi!2s",
  },
  {
    id: 10,
    name: "Mandila Beach Hotel",
    stars: 4,
    price: "2.200.000",
    image:
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Mandila Beach Hotel có thiết kế hiện đại, hồ bơi vô cực hướng biển và vị trí thuận tiện trên đường Võ Nguyên Giáp — phù hợp khách du lịch và cặp đôi.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3834.07061387194!2d108.24564847522032!3d16.060258188894604!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e1b08a2ea9%3A0xa76a829b40b759f5!2sMandila%20Beach%20Hotel%20Danang!5e0!3m2!1svi!2s!4v1696524458182!5m2!1svi!2s",
  },
  {
    id: 11,
    name: "Sala Danang Beach Hotel",
    stars: 4,
    price: "2.000.000",
    image:
      "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Sala Danang Beach Hotel nổi bật ở khu vực ven biển với thiết kế trẻ trung, phòng ốc tiện nghi và giá hợp lý cho du khách tham quan thành phố.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3834.043387707679!2d108.24735427522028!3d16.061274188893647!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e1777c014d%3A0xf30f8ed89e8b4971!2sSala%20Danang%20Beach%20Hotel!5e0!3m2!1svi!2s!4v1696524513292!5m2!1svi!2s",
  },
  {
    id: 12,
    name: "TMS Hotel Da Nang Beach",
    stars: 5,
    price: "3.000.000",
    image:
      "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "TMS Hotel Da Nang Beach có tầm nhìn hướng biển Mỹ Khê, thiết kế hiện đại, nhiều tiện ích nội khu và phù hợp cho khách công tác lẫn nghỉ dưỡng.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.9788871646314!2d108.25020887522035!3d16.065313688889933!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e6a4491ed9%3A0x48de418ea0aab87!2sTMS%20Hotel%20Da%20Nang!5e0!3m2!1svi!2s!4v1696524566886!5m2!1svi!2s",
  },
  {
    id: 13,
    name: "Four Points by Sheraton Danang",
    stars: 5,
    price: "3.400.000",
    image:
      "https://images.unsplash.com/photo-1582719478173-2d4df6cde8e3?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Four Points by Sheraton Danang gần cầu Thuận Phước, thuận tiện tham quan vịnh và trung tâm, phục vụ tiêu chuẩn thương hiệu quốc tế.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3834.5939809356147!2d108.23240647522008!3d16.04657378890746!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314217f8f97cb82f%3A0x6a6a84b3c9b8a3d1!2sFour%20Points%20by%20Sheraton%20Danang!5e0!3m2!1svi!2s!4v1696524619571!5m2!1svi!2s",
  },
  {
    id: 14,
    name: "A La Carte Danang Beach",
    stars: 4,
    price: "2.400.000",
    image:
      "https://images.unsplash.com/photo-1582719478145-3d6b94f36ef6?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "A La Carte Danang Beach nổi tiếng với hồ bơi vô cực trên tầng thượng, view biển đẹp, phù hợp khách trẻ và cặp đôi thích chụp ảnh check-in.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.969784955858!2d108.2480161752204!3d16.065666688889594!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e56b4ec7a3%3A0xc2d5a6e2cf358a7f!2sA%20La%20Carte%20Da%20Nang%20Beach!5e0!3m2!1svi!2s!4v1696524674232!5m2!1svi!2s",
  },
  {
    id: 15,
    name: "HAIAN Beach Hotel & Spa",
    stars: 4,
    price: "2.300.000",
    image:
      "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "HAIAN Beach Hotel & Spa phục vụ theo phong cách hiện đại, có spa, nhà hàng và vị trí thuận tiện trên tuyến đường ven biển — lựa chọn hợp lý cho du lịch giá tốt.",
    map: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3833.932299377023!2d108.24958417522037!3d16.06706868888843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314219e5ccac1dbf%3A0x93f6f252d3b3c815!2sHAIAN%20Beach%20Hotel%20%26%20Spa!5e0!3m2!1svi!2s!4v1696524718093!5m2!1svi!2s",
  },
];

export default function HotelDetailPage() {
  const { id } = useParams();
  const hotel = hotels.find((h) => h.id === Number(id));

  if (!hotel) {
    return (
      <div className="p-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
        <p className="mb-4">Có thể ID không tồn tại hoặc bạn đang ở đường dẫn sai.</p>
        <Link
          href="/khach-san/mien-trung/da-nang"
          className="text-white bg-green-700 px-4 py-2 rounded-lg"
        >
          ← Quay lại danh sách
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      {/* Ảnh chính */}
      <img
        src={hotel.image}
        alt={hotel.name}
        className="w-full h-80 object-cover rounded-2xl shadow mb-4"
      />

      {/* Gallery */}
      {hotel.gallery && hotel.gallery.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
          {hotel.gallery.map((src, i) => (
            <div key={i} className="overflow-hidden rounded-xl shadow-sm">
              <img
                src={src}
                alt={`${hotel.name} gallery ${i + 1}`}
                className="w-full h-40 object-cover transform hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
        </div>
      )}

      {/* Thông tin chính */}
      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">
        {"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}
      </p>
      <p className="text-xl font-semibold mb-4">
        Giá: <span className="text-green-700">{hotel.price} VNĐ / đêm</span>
      </p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      {/* Dịch vụ & tiện nghi */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          <li>Hồ bơi ngoài trời & phòng gym</li>
          <li>Nhà hàng, quầy bar & spa</li>
          <li>Dịch vụ đưa đón sân bay (có thu phí)</li>
          <li>Wifi miễn phí, phòng hội nghị</li>
          <li>View biển / sông Hàn (tùy phòng)</li>
        </ul>
      </div>

      {/* Form đặt phòng */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form
          className="flex flex-col gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            // bạn có thể thay alert bằng call API hoặc gửi tới trang thanh toán
            alert(
              `Yêu cầu đặt phòng đã gửi cho ${hotel.name} — hệ thống demo sẽ không thực hiện thanh toán.`
            );
          }}
        >
          <label className="text-sm text-gray-600">
            Ngày nhận phòng
            <input type="date" className="border p-2 rounded-md w-full mt-1" required />
          </label>
          <label className="text-sm text-gray-600">
            Ngày trả phòng
            <input type="date" className="border p-2 rounded-md w-full mt-1" required />
          </label>
          <label className="text-sm text-gray-600">
            Số lượng phòng
            <input
              type="number"
              min="1"
              defaultValue={1}
              placeholder="Số lượng phòng"
              className="border p-2 rounded-md w-full mt-1"
            />
          </label>
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 bg-green-700 text-white py-2 rounded-lg hover:bg-green-800 transition"
            >
              Đặt ngay
            </button>
            <Link
              href="/khach-san/mien-trung/da-nang"
              className="flex-1 text-center bg-gray-200 py-2 rounded-lg hover:bg-gray-300 transition"
            >
              Quay lại
            </Link>
          </div>
        </form>
      </div>

      {/* Bản đồ */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe
            src={hotel.map}
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>

      {/* Footer links */}
      <div className="flex justify-between items-center mb-10">
        <Link
          href="/"
          className="text-green-700 underline hover:text-green-900 transition"
        >
          ← Về Trang chủ
        </Link>
        <Link
          href="/khach-san/mien-trung/da-nang"
          className="text-green-700 underline hover:text-green-900 transition"
        >
          ← Quay lại Danh sách khách sạn
        </Link>
      </div>
    </div>
  );
}
