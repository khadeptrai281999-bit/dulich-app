"use client";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "Azerai La Residence Huế",
    stars: 5,
    price: 5200000,
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Azerai La Residence Huế – khách sạn 5★ bên bờ sông Hương, phong cách cổ điển Pháp sang trọng.",
    mapQuery: "Azerai La Residence Hue",
  },
  {
    id: 2,
    name: "Indochine Palace Hotel",
    stars: 5,
    price: 4500000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Indochine Palace – khách sạn 5★ hiện đại với kiến trúc hoàng gia pha Á Đông.",
    mapQuery: "Indochine Palace Hotel Hue",
  },
  {
    id: 3,
    name: "Vinpearl Hotel Huế",
    stars: 5,
    price: 3800000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Vinpearl Hotel Huế – toạ lạc trung tâm thành phố, có hồ bơi vô cực và view toàn cảnh sông Hương.",
    mapQuery: "Vinpearl Hotel Hue",
  },
  {
    id: 4,
    name: "Imperial Hotel Huế",
    stars: 5,
    price: 4100000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Imperial Hotel – khách sạn 5★ đầu tiên của Huế, mang phong cách hoàng gia truyền thống.",
    mapQuery: "Imperial Hotel Hue",
  },
  {
    id: 5,
    name: "Century Riverside Hotel Huế",
    stars: 4,
    price: 2400000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Century Riverside – khách sạn ven sông Hương, gần phố đi bộ Nguyễn Đình Chiểu.",
    mapQuery: "Century Riverside Hotel Hue",
  },
  {
    id: 6,
    name: "Melia Vinpearl Hue",
    stars: 5,
    price: 4600000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Melia Vinpearl Huế – khách sạn 5★ chuẩn quốc tế, view sông Hương và cầu Tràng Tiền.",
    mapQuery: "Melia Vinpearl Hue",
  },
  {
    id: 7,
    name: "Pilgrimage Village Resort & Spa",
    stars: 5,
    price: 3700000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Pilgrimage Village – resort nghỉ dưỡng giữa rừng thông, gần lăng Tự Đức.",
    mapQuery: "Pilgrimage Village Resort & Spa Hue",
  },
  {
    id: 8,
    name: "Eldora Hotel Huế",
    stars: 4,
    price: 2500000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Eldora – khách sạn boutique phong cách cổ điển Pháp ngay trung tâm Huế.",
    mapQuery: "Eldora Hotel Hue",
  },
  {
    id: 9,
    name: "Thanh Lịch Royal Boutique Hotel",
    stars: 4,
    price: 2300000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Thanh Lịch Royal Boutique – không gian sang trọng, đậm chất cung đình Huế.",
    mapQuery: "Thanh Lich Royal Boutique Hotel Hue",
  },
  {
    id: 10,
    name: "Alba Wellness Resort by Fusion",
    stars: 5,
    price: 4900000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description: "Alba Wellness Resort – khu nghỉ dưỡng suối khoáng nóng với liệu pháp spa và yoga.",
    mapQuery: "Alba Wellness Resort Hue",
  },
];

export default function HueHotelDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels.find((h) => h.id === parseInt(id));

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) return <div className="p-10 text-center text-gray-700">Không tìm thấy khách sạn.</div>;

  const totalPrice = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 3600 * 24);
    return days > 0 ? hotel.price * rooms * days : 0;
  };

  const handleBooking = () => {
    if (!checkIn || !checkOut) return alert("Vui lòng chọn ngày nhận và trả phòng!");
    alert(
      `✅ Đặt phòng thành công!\n${hotel.name}\nTừ ${checkIn} đến ${checkOut}\nSố phòng: ${rooms}\nTổng tiền: ${totalPrice().toLocaleString("vi-VN")} VNĐ`
    );
  };

  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <button
        onClick={() => router.back()}
        className="mb-6 bg-gray-300 hover:bg-gray-400 px-4 py-2 rounded-lg text-sm"
      >
        ← Quay lại
      </button>

      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden">
        <img src={hotel.image} alt={hotel.name} className="w-full h-96 object-cover" />
        <div className="p-6">
          <h1 className="text-3xl font-bold text-green-800 mb-2">{hotel.name}</h1>
          <p className="text-yellow-500 mb-3">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
          <p className="text-gray-700 mb-4">{hotel.description}</p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            {hotel.gallery.map((img, i) => (
              <img key={i} src={img} className="w-full h-40 object-cover rounded-lg" />
            ))}
          </div>

          <div className="border-t pt-4 mt-4">
            <h2 className="font-semibold text-lg mb-3">Đặt phòng</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-3">
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="number"
                min="1"
                value={rooms}
                onChange={(e) => setRooms(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
            </div>

            <p className="text-gray-700 mb-3">
              💰 Tổng tiền:{" "}
              <span className="font-bold text-green-700">
                {totalPrice().toLocaleString("vi-VN")} VNĐ
              </span>
            </p>

            <button
              onClick={handleBooking}
              className="bg-green-700 hover:bg-green-800 text-white px-6 py-2 rounded-lg transition"
            >
              Đặt ngay
            </button>
          </div>

          <div className="mt-8">
            <h2 className="font-semibold text-lg mb-3">📍 Bản đồ</h2>
            <iframe
              src={`https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`}
              className="w-full h-80 rounded-xl"
              allowFullScreen
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
}
