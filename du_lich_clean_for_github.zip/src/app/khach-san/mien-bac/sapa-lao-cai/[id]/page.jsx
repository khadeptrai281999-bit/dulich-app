"use client";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const hotels = [
  {
    id:1,
    name:"Sapa Legend Hotel & Spa",
    stars:5,
    price:4200000,
    image:"https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Sapa Legend — khách sạn 5★ gần trung tâm thị trấn Sapa, view núi đẹp.",
    mapQuery:"Sapa Legend Hotel & Spa"
  },
  {
    id:2,
    name:"Topas Ecolodge",
    stars:5,
    price:5200000,
    image:"https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Topas Ecolodge — ecolodge nổi tiếng, nằm ở vùng cao, trải nghiệm thiên nhiên tuyệt vời.",
    mapQuery:"Topas Ecolodge Sapa"
  },
  {
    id:3,
    name:"Hotels in Sapa Center",
    stars:4,
    price:2100000,
    image:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Khách sạn tiện nghi tại trung tâm Sapa, thuận tiện khám phá chợ đêm và nhà thờ đá.",
    mapQuery:"Sapa Center Hotels"
  },
  {
    id:4,
    name:"Victoria Sapa Resort",
    stars:5,
    price:4800000,
    image:"https://images.unsplash.com/photo-1470770903676-69b98201ea1c?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Victoria Sapa — resort 5★ trên cao, không gian yên bình và villa đẹp.",
    mapQuery:"Victoria Sapa Resort"
  },
  {
    id:5,
    name:"Aira Boutique Sapa",
    stars:4,
    price:2600000,
    image:"https://images.unsplash.com/photo-1482192596544-9eb780fc7f66?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Aira Boutique — khách sạn boutique, trang trí hiện đại, gần quảng trường Sapa.",
    mapQuery:"Aira Boutique Sapa"
  },
  {
    id:6,
    name:"Pao's Sapa Leisure Hotel",
    stars:5,
    price:4000000,
    image:"https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Pao's — khách sạn sang trọng, view thung lũng Mường Hoa đẹp.",
    mapQuery:"Pao's Sapa Leisure Hotel"
  },
  {
    id:7,
    name:"Sapa Horizon Hotel",
    stars:4,
    price:2200000,
    image:"https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Khách sạn trung tâm Sapa với tiện nghi đầy đủ, giá hợp lý.",
    mapQuery:"Sapa Horizon Hotel"
  },
  {
    id:8,
    name:"Silk Path Grand Sapa",
    stars:5,
    price:4600000,
    image:"https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1504198453319-5ce911bafcde?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Silk Path — khách sạn 5★ cao cấp, tiện nghi và phục vụ chuyên nghiệp.",
    mapQuery:"Silk Path Grand Sapa"
  },
  {
    id:9,
    name:"Sapa Centre Hotel",
    stars:4,
    price:1900000,
    image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Sapa Centre — vị trí tiện lợi, gần điểm tham quan và chợ đêm.",
    mapQuery:"Sapa Centre Hotel"
  },
  {
    id:10,
    name:"Fivitel Sapa",
    stars:4,
    price:2300000,
    image:"https://images.unsplash.com/photo-1506967726967-4d0d6aae1c2a?auto=format&fit=crop&w=1600&q=80",
    gallery:[
      "https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
    ],
    description:"Fivitel — khách sạn mới, sạch sẽ, phù hợp nghỉ dưỡng ngắn ngày.",
    mapQuery:"Fivitel Sapa"
  }
];

export default function SapaDetail() {
  const { id } = useParams();
  const hotel = hotels.find(h => h.id === Number(id));
  const [mainImage, setMainImage] = useState(hotel?.image);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return (
      <div className="p-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
        <Link href="/khach-san/mien-bac/sapa-lao-cai" className="text-green-700 underline">← Quay lại danh sách</Link>
      </div>
    );
  }

  const calcTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24);
    if (days <= 0) return 0;
    return days * hotel.price * rooms;
  };

  const handleBook = (e) => {
    e.preventDefault();
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng.");
      return;
    }
    alert(`Yêu cầu đặt phòng gửi: ${hotel.name}\nTổng: ${calcTotal().toLocaleString("vi-VN")}đ\n(Trang demo chưa thực hiện thanh toán)`);
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      <Link href="/khach-san/mien-bac/sapa-lao-cai" className="text-green-700 underline">← Quay lại Sapa & Lào Cai</Link>

      <img src={mainImage} alt={hotel.name} className="w-full h-80 object-cover rounded-2xl shadow mb-4 mt-4" />

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {hotel.gallery.map((g,i) => (
          <div key={i} className="overflow-hidden rounded-xl shadow-sm cursor-pointer" onClick={() => setMainImage(g)}>
            <img src={g} alt={`${hotel.name} ${i+1}`} className="w-full h-40 object-cover transform hover:scale-105 transition" />
          </div>
        ))}
      </div>

      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">{"★".repeat(hotel.stars)}{"☆".repeat(5-hotel.stars)}</p>
      <p className="text-xl font-semibold mb-4 text-green-700">{hotel.price.toLocaleString("vi-VN")}đ / đêm</p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          <li>Hồ bơi / Spa</li>
          <li>Nhà hàng & phục vụ 24/7</li>
          <li>Wifi miễn phí</li>
          <li>Hướng dẫn leo núi / tour bản</li>
        </ul>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form className="flex flex-col gap-3" onSubmit={handleBook}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm text-gray-600">Ngày nhận
              <input type="date" value={checkIn} onChange={(e)=>setCheckIn(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/>
            </label>
            <label className="text-sm text-gray-600">Ngày trả
              <input type="date" value={checkOut} onChange={(e)=>setCheckOut(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/>
            </label>
            <label className="text-sm text-gray-600">Số phòng
              <input type="number" min="1" value={rooms} onChange={(e)=>setRooms(Number(e.target.value)||1)} className="border p-2 rounded-md w-full mt-1"/>
            </label>
          </div>

          <div className="flex items-center justify-between mt-3">
            <p className="text-lg font-semibold">Tổng tiền: <span className="text-green-700">{calcTotal().toLocaleString("vi-VN")}đ</span></p>
            <div className="flex gap-3">
              <button type="submit" className="bg-green-700 text-white px-6 py-2 rounded-lg hover:bg-green-800">Đặt ngay</button>
              <Link href="/khach-san/mien-bac/sapa-lao-cai" className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">Quay lại</Link>
            </div>
          </div>
        </form>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe src={mapSrc} width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>

      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900">← Về Trang chủ</Link>
        <Link href="/khach-san/mien-bac/sapa-lao-cai" className="text-green-700 underline hover:text-green-900">← Quay lại Sapa & Lào Cai</Link>
      </div>
    </div>
  );
}
