"use client";
import Link from "next/link";

const hotels = [
  { id:1, slug:"the-reverie-saigon", name:"The Reverie Saigon", stars:5, price:8400000, image:"https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80" },
  { id:2, slug:"caravelle-saigon", name:"Caravelle Saigon", stars:5, price:6200000, image:"https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80" },
  { id:3, slug:"hotel-nikko-saigon", name:"Hotel Nikko Saigon", stars:5, price:5800000, image:"https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80" },
  { id:4, slug:"sofitel-saigon", name:"Sofitel Saigon Plaza", stars:5, price:6400000, image:"https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80" },
  { id:5, slug:"park-hyatt-saigon", name:"Park Hyatt Saigon", stars:5, price:9000000, image:"https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80" },
  { id:6, slug:"sherwood-suites", name:"Sherwood Suites", stars:4, price:2600000, image:"https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80" },
  { id:7, slug:"liberty-central", name:"Liberty Central Saigon Citypoint", stars:4, price:2200000, image:"https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80" },
  { id:8, slug:"pullman-saigon", name:"Pullman Saigon Centre", stars:5, price:5400000, image:"https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80" },
  { id:9, slug:"new-world-saigon", name:"New World Saigon Hotel", stars:5, price:5600000, image:"https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80" },
  { id:10, slug:"lotte-saigon", name:"Lotte Hotel Saigon", stars:5, price:7000000, image:"https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80" },
];

export default function HCMList() {
  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-6 text-green-800 text-center">Danh sách khách sạn 4★ & 5★ tại TP. Hồ Chí Minh</h1>
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map(h => (
          <div key={h.id} className="bg-white shadow-lg rounded-2xl overflow-hidden">
            <img src={h.image} alt={h.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h2 className="font-semibold text-lg mb-1 text-green-800">{h.name}</h2>
              <p className="text-yellow-500 text-sm mb-1">{"★".repeat(h.stars)}{"☆".repeat(5-h.stars)}</p>
              <p className="text-gray-700 mb-3">{h.price.toLocaleString("vi-VN")} VNĐ / đêm</p>
              <div className="flex gap-2">
                <Link href={`/khach-san/mien-nam/ho-chi-minh/${h.id}`} className="flex-1 text-white bg-green-700 hover:bg-green-800 transition px-4 py-2 rounded-lg text-sm text-center">Xem chi tiết</Link>
                <button onClick={()=>alert(`Đặt phòng nhanh: ${h.name}`)} className="bg-transparent border border-green-700 text-green-700 px-4 py-2 rounded-lg hover:bg-green-50 transition text-sm">Đặt nhanh</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
