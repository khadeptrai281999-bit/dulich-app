import "@/app/globals.css";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "Website Du Lịch",
  description: "Trang web du lịch Next.js demo",
};

export default function RootLayout({ children }) {
  return (
    <html lang="vi">
      <body className="antialiased bg-emerald-50 text-gray-900">
        {/* Navbar */}
        <Navbar />

        {/* Nội dung chính */}
        <main className="min-h-screen bg-white">
          <div className="max-w-7xl mx-auto px-4 py-6">{children}</div>
        </main>

        {/* Footer */}
        <Footer />
      </body>
    </html>
  );
}
