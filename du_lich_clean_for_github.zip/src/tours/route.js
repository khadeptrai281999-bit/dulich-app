import { NextResponse } from "next/server";

const tours = [
  {
    id: 1,
    title: "Tour Hà Nội – Hạ Long – Sapa",
    location: "Hà Nội",
    price: 3500000,
    image: "/images/tours/hanoi.jpg",
  },
  {
    id: 2,
    title: "Tour Đà Nẵng – Hội An",
    location: "Đà Nẵng",
    price: 2800000,
    image: "/images/tours/danang.jpg",
  },
  {
    id: 3,
    title: "Tour Nha Trang – Vinpearl",
    location: "Nha Trang",
    price: 3000000,
    image: "/images/tours/nhatrang.jpg",
  },
  {
    id: 4,
    title: "Tour Phú Quốc nghỉ dưỡng",
    location: "Phú Quốc",
    price: 4200000,
    image: "/images/tours/phuquoc.jpg",
  },
  {
    id: 5,
    title: "Tour Đà Lạt – Thung Lũng Tình Yêu",
    location: "Đà Lạt",
    price: 2700000,
    image: "/images/tours/dalat.jpg",
  },
];

export async function GET() {
  return NextResponse.json(tours);
}
