"use client";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import TourCard from "@/components/TourCard";

export default function ToursPage() {
  const params = useSearchParams();
  const keyword = params.get("keyword") || "";
  const location = params.get("location") || "";
  const [tours, setTours] = useState([]);

  useEffect(() => {
    async function fetchData() {
      // Gọi API backend, ở đây mình mock tạm
      const res = await fetch("/api/tours");
      let data = await res.json();

      // lọc theo keyword + location
      if (keyword) {
        data = data.filter((t) =>
          t.title.toLowerCase().includes(keyword.toLowerCase())
        );
      }
      if (location) {
        data = data.filter((t) =>
          t.location.toLowerCase().includes(location.toLowerCase())
        );
      }

      setTours(data);
    }
    fetchData();
  }, [keyword, location]);

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold mb-6">Danh sách tour</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {tours.map((tour) => (
          <TourCard key={tour.id} tour={tour} />
        ))}
      </div>
    </main>
  );
}
