export const hotels = [
  {
    id: 1,
    ten: "Khách sạn Hà Nội Royal",
    diaDiem: "ha-noi",
    loai: "4 sao",
    hinh: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
  },
  {
    id: 2,
    ten: "Resort Đà Nẵng Beach",
    diaDiem: "da-nang",
    loai: "5 sao",
    hinh: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg",
  },
];

export const tours = [
  {
    id: 1,
    ten: "Tour Hà Nội – Hạ Long",
    diaDiem: "ha-noi",
    gia: "2.900.000đ",
    hinh: "https://images.pexels.com/photos/346885/pexels-photo-346885.jpeg",
  },
  {
    id: 2,
    ten: "Tour Đà Nẵng – Hội An",
    diaDiem: "da-nang",
    gia: "3.200.000đ",
    hinh: "https://images.pexels.com/photos/753626/pexels-photo-753626.jpeg",
  },
];

export const combos = [
  {
    id: 1,
    ten: "Combo Hà Nội 3N2Đ",
    diaDiem: "ha-noi",
    gia: "2.500.000đ",
    hinh: "https://images.pexels.com/photos/2101187/pexels-photo-2101187.jpeg",
  },
  {
    id: 2,
    ten: "Combo Đà Nẵng 3N2Đ",
    diaDiem: "da-nang",
    gia: "2.800.000đ",
    hinh: "https://images.pexels.com/photos/2101187/pexels-photo-2101187.jpeg",
  },
];
