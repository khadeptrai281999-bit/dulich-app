"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

export default function TourDetailPage() {
  const { id } = useParams(); // lấy id từ URL
  const [tour, setTour] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", email: "" });
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function fetchTour() {
      const res = await fetch("/api/tours");
      const data = await res.json();
      const found = data.find((t) => t.id === parseInt(id));
      setTour(found);
    }
    fetchTour();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("/api/booking", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, tourId: id }),
    });
    if (res.ok) {
      setMessage("Đặt tour thành công ✅! Chúng tôi sẽ liên hệ với bạn.");
      setForm({ name: "", phone: "", email: "" });
    } else {
      setMessage("❌ Có lỗi xảy ra, vui lòng thử lại.");
    }
  };

  if (!tour) return <p className="p-6">Đang tải dữ liệu...</p>;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">{tour.title}</h1>
      <img
        src={tour.image}
        alt={tour.title}
        className="w-full h-80 object-cover rounded-lg shadow-md"
      />
      <p className="mt-4 text-gray-700">{tour.desc || "Chưa có mô tả chi tiết."}</p>
      <p className="mt-2 text-red-500 font-bold text-lg">
        Giá: {tour.price.toLocaleString()} VNĐ
      </p>

      {/* Form đặt tour */}
      <form onSubmit={handleSubmit} className="mt-8 space-y-4 bg-gray-100 p-6 rounded-lg">
        <h2 className="text-xl font-semibold">Đặt tour ngay</h2>
        <input
          type="text"
          name="name"
          placeholder="Họ và tên"
          value={form.name}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border rounded"
        />
        <input
          type="tel"
          name="phone"
          placeholder="Số điện thoại"
          value={form.phone}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border rounded"
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border rounded"
        />
        <button className="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded">
          Xác nhận đặt tour
        </button>
      </form>

      {message && <p className="mt-4 text-green-600 font-medium">{message}</p>}
    </div>
  );
}
