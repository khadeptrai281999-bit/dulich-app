import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req) {
  try {
    const body = await req.json();
    const { to, subject, message } = body;

    if (!to || !subject || !message) {
      return new Response("Thiếu dữ liệu", { status: 400 });
    }

    await resend.emails.send({
      from: "Hotel Booking <no-reply@yourdomain.com>",
      to,
      subject,
      html: message,
    });

    return new Response("Đã gửi email thành công!", { status: 200 });
  } catch (err) {
    console.error("Lỗi gửi email:", err);
    return new Response("Lỗi gửi email", { status: 500 });
  }
}
