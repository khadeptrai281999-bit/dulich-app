"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Select, { components } from "react-select";

export default function SearchBox() {
  const [keyword, setKeyword] = useState("");
  const [selectedLocation, setSelectedLocation] = useState(null);
  const router = useRouter();

  // 🌍 Danh sách địa điểm du lịch toàn quốc
  const locations = [
    // 🏔️ Miền Bắc
    { label: "Hà Nội", value: "ha-noi", region: "Miền Bắc", img: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg" },
    { label: "Hạ Long – Yên Tử", value: "ha-long-yen-tu", region: "Miền Bắc", img: "https://images.pexels.com/photos/208701/pexels-photo-208701.jpeg" },
    { label: "Sapa – Lào Cai", value: "sapa-lao-cai", region: "Miền Bắc", img: "https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg" },
    { label: "Ninh Bình", value: "ninh-binh", region: "Miền Bắc", img: "https://images.pexels.com/photos/700170/pexels-photo-700170.jpeg" },
    { label: "Hà Giang", value: "ha-giang", region: "Miền Bắc", img: "https://images.pexels.com/photos/364568/pexels-photo-364568.jpeg" },
    { label: "Cát Bà – Hải Phòng", value: "cat-ba", region: "Miền Bắc", img: "https://images.pexels.com/photos/1433052/pexels-photo-1433052.jpeg" },
    { label: "Mai Châu – Hòa Bình", value: "mai-chau", region: "Miền Bắc", img: "https://images.pexels.com/photos/1871983/pexels-photo-1871983.jpeg" },

    // 🏖️ Miền Trung
    { label: "Đà Nẵng", value: "da-nang", region: "Miền Trung", img: "https://images.pexels.com/photos/753626/pexels-photo-753626.jpeg" },
    { label: "Huế", value: "hue", region: "Miền Trung", img: "https://images.pexels.com/photos/1183099/pexels-photo-1183099.jpeg" },
    { label: "Hội An – Quảng Nam", value: "hoi-an-quang-nam", region: "Miền Trung", img: "https://images.pexels.com/photos/255379/pexels-photo-255379.jpeg" },
    { label: "Quảng Bình", value: "quang-binh", region: "Miền Trung", img: "https://images.pexels.com/photos/208739/pexels-photo-208739.jpeg" },
    { label: "Phan Thiết – Mũi Né", value: "phan-thiet", region: "Miền Trung", img: "https://images.pexels.com/photos/88212/pexels-photo-88212.jpeg" },
    { label: "Quy Nhơn – Bình Định", value: "quy-nhon", region: "Miền Trung", img: "https://images.pexels.com/photos/208739/pexels-photo-208739.jpeg" },
    { label: "Nghệ An – Hà Tĩnh", value: "nghe-an", region: "Miền Trung", img: "https://images.pexels.com/photos/1118869/pexels-photo-1118869.jpeg" },

    // 🌴 Miền Nam
    { label: "Nha Trang", value: "nha-trang", region: "Miền Nam", img: "https://images.pexels.com/photos/2101187/pexels-photo-2101187.jpeg" },
    { label: "Đà Lạt", value: "da-lat", region: "Miền Nam", img: "https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg" },
    { label: "Phú Quốc", value: "phu-quoc", region: "Miền Nam", img: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg" },
    { label: "Vũng Tàu", value: "vung-tau", region: "Miền Nam", img: "https://images.pexels.com/photos/236066/pexels-photo-236066.jpeg" },
    { label: "Cần Thơ", value: "can-tho", region: "Miền Nam", img: "https://images.pexels.com/photos/1408387/pexels-photo-1408387.jpeg" },
    { label: "Hồ Chí Minh", value: "ho-chi-minh", region: "Miền Nam", img: "https://images.pexels.com/photos/21014/pexels-photo.jpg" },
    { label: "Cà Mau", value: "ca-mau", region: "Miền Nam", img: "https://images.pexels.com/photos/132037/pexels-photo-132037.jpeg" },
  ];

  // ⚙️ Nhóm vùng miền
  const groupedOptions = [
    { label: "Miền Bắc", options: locations.filter((l) => l.region === "Miền Bắc") },
    { label: "Miền Trung", options: locations.filter((l) => l.region === "Miền Trung") },
    { label: "Miền Nam", options: locations.filter((l) => l.region === "Miền Nam") },
  ];

  // 🖼️ Hiển thị ảnh trong dropdown
  const OptionWithImage = (props) => (
    <components.Option {...props}>
      <div className="flex items-center gap-3">
        <img src={props.data.img} alt={props.label} className="w-10 h-10 object-cover rounded-md" />
        <span>{props.label}</span>
      </div>
    </components.Option>
  );

  // 🔍 Xử lý tìm kiếm
  const handleSearch = () => {
    let query = `/tim-kiem?`;
    if (keyword) query += `keyword=${encodeURIComponent(keyword)}&`;
    if (selectedLocation) query += `diaDiem=${encodeURIComponent(selectedLocation.value)}&`;
    router.push(query);
  };

  return (
    <div className="flex flex-col md:flex-row gap-4 items-center justify-center bg-green-800 p-6 rounded-lg shadow-lg">
      {/* Ô nhập từ khóa */}
      <input
        type="text"
        placeholder="Tìm kiếm khách sạn, tour du lịch..."
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        className="w-full md:w-1/3 px-4 py-3 rounded border focus:outline-none focus:ring-2 focus:ring-green-600"
      />

      {/* Dropdown chọn địa điểm */}
      <div className="w-full md:w-1/4">
        <Select
          options={groupedOptions}
          placeholder="Chọn hoặc gõ để tìm địa điểm..."
          value={selectedLocation}
          onChange={setSelectedLocation}
          isClearable
          components={{ Option: OptionWithImage }}
          className="text-black"
          styles={{
            control: (base) => ({
              ...base,
              borderColor: "#16a34a",
              borderRadius: "0.5rem",
              padding: "4px",
              boxShadow: "none",
              "&:hover": { borderColor: "#15803d" },
            }),
            menu: (base) => ({
              ...base,
              zIndex: 9999,
              maxHeight: 250,
            }),
          }}
        />
      </div>

      {/* Nút tìm kiếm */}
      <button
        onClick={handleSearch}
        className="bg-lime-500 hover:bg-lime-600 text-white font-semibold px-6 py-3 rounded-lg transition"
      >
        Tìm kiếm
      </button>
    </div>
  );
}
