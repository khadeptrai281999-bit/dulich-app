// src/components/Navbar.jsx
"use client";
import { useState } from "react";
import Link from "next/link";

function Chevron({ className = "" }) {
  return (
    <svg
      className={`w-4 h-4 inline-block transition-transform duration-200 ${className}`}
      viewBox="0 0 20 20"
      fill="currentColor"
      aria-hidden="true"
    >
      <path
        fillRule="evenodd"
        d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"
        clipRule="evenodd"
      />
    </svg>
  );
}

export default function Navbar() {
  const [openMenu, setOpenMenu] = useState(null);
  const [openSubMenu, setOpenSubMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
    setOpenSubMenu(null);
  };

  const toggleSubMenu = (sub) => {
    setOpenSubMenu(openSubMenu === sub ? null : sub);
  };

  return (
    <header className="relative z-50">
      <nav className="bg-emerald-800 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <Link href="/">
                <img
                  src="https://dulich19.maugiaodien.com/wp-content/uploads/2023/08/logo.png"
                  alt="Logo"
                  className="h-10"
                />
              </Link>
            </div>

            {/* Menu */}
            <ul className="flex items-center gap-6 font-semibold">
              <li>
                <Link href="/" className="hover:text-yellow-300">
                  Trang chủ
                </Link>
              </li>

              {/* Khách sạn */}
              <li className="relative">
                <button
                  onClick={() => toggleMenu("khachsan")}
                  className="flex items-center gap-1 hover:text-yellow-300 focus:outline-none"
                  aria-expanded={openMenu === "khachsan"}
                >
                  <span>Khách sạn</span>
                  <Chevron
                    className={
                      openMenu === "khachsan"
                        ? "rotate-180 text-yellow-300"
                        : ""
                    }
                  />
                </button>

                {openMenu === "khachsan" && (
                  <div className="absolute top-full left-0 mt-2 bg-emerald-700 rounded shadow-lg flex">
                    <div className="w-48 bg-emerald-600">
                      <button
                        onClick={() => toggleSubMenu("mienbac")}
                        className={`w-full text-left px-5 py-4 hover:bg-emerald-500 ${
                          openSubMenu === "mienbac"
                            ? "bg-emerald-500 text-yellow-300 font-bold"
                            : "text-white"
                        }`}
                      >
                        Miền Bắc
                      </button>
                      <button
                        onClick={() => toggleSubMenu("mientrung")}
                        className={`w-full text-left px-5 py-4 hover:bg-emerald-500 ${
                          openSubMenu === "mientrung"
                            ? "bg-emerald-500 text-yellow-300 font-bold"
                            : "text-white"
                        }`}
                      >
                        Miền Trung
                      </button>
                      <button
                        onClick={() => toggleSubMenu("miennam")}
                        className={`w-full text-left px-5 py-4 hover:bg-emerald-500 ${
                          openSubMenu === "miennam"
                            ? "bg-emerald-500 text-yellow-300 font-bold"
                            : "text-white"
                        }`}
                      >
                        Miền Nam
                      </button>
                    </div>

                    <div className="w-64 bg-emerald-800 p-4">
                      {openSubMenu === "mienbac" && (
                        <ul className="space-y-3">
                          <li>
                            <Link
                              href="/khach-san/mien-bac/ha-long-yen-tu"
                              className="block hover:text-yellow-300"
                            >
                              Hạ Long – Yên Tử
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-bac/sapa-lao-cai"
                              className="block hover:text-yellow-300"
                            >
                              Sapa – Lào Cai
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-bac/ha-noi"
                              className="block hover:text-yellow-300"
                            >
                              Hà Nội
                            </Link>
                          </li>
                        </ul>
                      )}

                      {openSubMenu === "mientrung" && (
                        <ul className="space-y-3">
                          <li>
                            <Link
                              href="/khach-san/mien-trung/hue"
                              className="block hover:text-yellow-300"
                            >
                              Huế
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-trung/hoi-an"
                              className="block hover:text-yellow-300"
                            >
                              Hội An
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-trung/da-nang"
                              className="block hover:text-yellow-300"
                            >
                              Đà Nẵng
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-trung/quy-nhon"
                              className="block hover:text-yellow-300"
                            >
                              Quy Nhơn
                            </Link>
                          </li>
                        </ul>
                      )}

                      {openSubMenu === "miennam" && (
                        <ul className="space-y-3">
                          <li>
                            <Link
                              href="/khach-san/mien-nam/da-lat"
                              className="block hover:text-yellow-300"
                            >
                              Đà Lạt
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-nam/phu-quoc"
                              className="block hover:text-yellow-300"
                            >
                              Phú Quốc
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-nam/nha-trang"
                              className="block hover:text-yellow-300"
                            >
                              Nha Trang
                            </Link>
                          </li>
                          <li>
                            <Link
                              href="/khach-san/mien-nam/ho-chi-minh"
                              className="block hover:text-yellow-300"
                            >
                              Hồ Chí Minh
                            </Link>
                          </li>
                        </ul>
                      )}
                    </div>
                  </div>
                )}
              </li>

              {/* Combo */}
              <li className="relative">
                <button
                  onClick={() => toggleMenu("combo")}
                  className="flex items-center gap-1 hover:text-yellow-300"
                  aria-expanded={openMenu === "combo"}
                >
                  <span>Combo</span>
                  <Chevron
                    className={
                      openMenu === "combo" ? "rotate-180 text-yellow-300" : ""
                    }
                  />
                </button>

                {openMenu === "combo" && (
                  <div className="absolute top-full left-0 mt-2 bg-emerald-700 rounded shadow-lg p-3 w-56">
                    <Link
                      href="/combo/mien-bac"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Combo du lịch Miền Bắc
                    </Link>
                    <Link
                      href="/combo/mien-trung"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Combo du lịch Miền Trung
                    </Link>
                    <Link
                      href="/combo/mien-nam"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Combo du lịch Miền Nam
                    </Link>
                  </div>
                )}
              </li>

              {/* Tour trọn gói */}
              <li className="relative">
                <button
                  onClick={() => toggleMenu("tour")}
                  className="flex items-center gap-1 hover:text-yellow-300"
                  aria-expanded={openMenu === "tour"}
                >
                  <span>Tour trọn gói</span>
                  <Chevron
                    className={
                      openMenu === "tour" ? "rotate-180 text-yellow-300" : ""
                    }
                  />
                </button>

                {openMenu === "tour" && (
                  <div className="absolute top-full left-0 mt-2 bg-emerald-700 rounded shadow-lg p-3 w-60">
                    <Link
                      href="/tour-tron-goi/trong-nuoc"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Tour trong nước
                    </Link>
                    <Link
                      href="/tour-tron-goi/nuoc-ngoai"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Tour nước ngoài
                    </Link>
                    <Link
                      href="/tour-tron-goi/cao-cap"
                      className="block px-4 py-2 hover:bg-emerald-600"
                    >
                      Tour cao cấp
                    </Link>
                    <Link
                      href="/tour-tron-goi"
                      className="block px-4 py-2 hover:bg-emerald-600 text-yellow-300 font-semibold"
                    >
                      Xem tất cả tour
                    </Link>
                  </div>
                )}
              </li>

              {/* Các mục còn lại */}
              <li>
                <Link href="/gioi-thieu" className="hover:text-yellow-300">
                  Giới thiệu
                </Link>
              </li>
              <li>
                <Link href="/lien-he" className="hover:text-yellow-300">
                  Liên hệ
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}
