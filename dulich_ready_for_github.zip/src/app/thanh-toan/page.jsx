"use client";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import Link from "next/link";

export default function ThanhToan() {
  const params = useSearchParams();
  const hotel = params.get("hotel") || "Không xác định";
  const price = params.get("price") || "0";
  const checkin = params.get("checkin") || "";
  const checkout = params.get("checkout") || "";
  const rooms = params.get("rooms") || "1";

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [method, setMethod] = useState("");

  const handlePay = () => {
    if (!name || !phone || !method) {
      alert("⚠️ Vui lòng nhập đầy đủ thông tin!");
      return;
    }

    const orderId = Math.floor(100000 + Math.random() * 900000);

    const query = new URLSearchParams({
      id: orderId,
      hotel,
      price,
      name,
      phone,
      email,
      method,
      checkin,
      checkout,
      rooms,
    }).toString();

    window.location.href = `/xac-nhan?${query}`;
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <Link href="/khach-san/ha-noi" className="text-green-700 hover:underline">
        ← Quay lại danh sách khách sạn
      </Link>

      <h1 className="text-3xl font-bold text-center mb-6 text-green-800">
        💳 Thanh toán đặt phòng
      </h1>

      {/* Thông tin đặt phòng */}
      <div className="bg-white p-6 rounded-2xl shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-3 text-green-800">
          Thông tin đặt phòng
        </h2>
        <p>
          <strong>Khách sạn:</strong> {hotel}
        </p>
        <p>
          <strong>Ngày nhận phòng:</strong> {checkin || "Chưa chọn"}
        </p>
        <p>
          <strong>Ngày trả phòng:</strong> {checkout || "Chưa chọn"}
        </p>
        <p>
          <strong>Số phòng:</strong> {rooms}
        </p>
        <p className="text-lg mt-2">
          <strong>Tổng tiền:</strong>{" "}
          <span className="text-green-700 font-semibold">{price}đ</span>
        </p>
      </div>

      {/* Thông tin khách hàng */}
      <div className="bg-white p-6 rounded-2xl shadow-md">
        <h2 className="text-xl font-semibold mb-3 text-green-800">
          Thông tin khách hàng
        </h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Họ và tên"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border p-2 rounded-lg w-full"
          />
          <input
            type="tel"
            placeholder="Số điện thoại"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="border p-2 rounded-lg w-full"
          />
          <input
            type="email"
            placeholder="Email (tuỳ chọn)"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="border p-2 rounded-lg w-full"
          />

          <div>
            <label className="block font-medium mb-2 text-gray-700">
              Phương thức thanh toán:
            </label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="border p-2 rounded-lg w-full"
            >
              <option value="">-- Chọn phương thức --</option>
              <option value="VNPay">VNPay</option>
              <option value="Momo">Momo</option>
              <option value="QR BIDV">QR BIDV</option>
              <option value="Tại khách sạn">Thanh toán tại khách sạn</option>
            </select>
          </div>

          <button
            onClick={handlePay}
            className="w-full bg-green-700 text-white py-3 rounded-lg mt-4 hover:bg-green-800"
          >
            Xác nhận & Thanh toán
          </button>
        </div>
      </div>
    </div>
  );
}
