"use client";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "Dalat Palace Heritage Hotel",
    stars: 5,
    price: 5200000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Dalat Palace là khách sạn cổ kính, biểu tượng Đà Lạt với nội thất sang trọng, dịch vụ 5 sao và vị trí trung tâm thuận tiện.",
    address: "2 Trieu Viet Vuong, Phường 4, Thành phố Đà Lạt",
    mapQuery: "Dalat Palace Hotel Da Lat",
  },
  {
    id: 2,
    name: "Ana Mandara Villas Dalat Resort & Spa",
    stars: 5,
    price: 4800000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Ana Mandara Villas: chuỗi villas nghỉ dưỡng nằm giữa rừng thông, mang lại cảm giác riêng tư, yên bình và dịch vụ Spa thư giãn.",
    address: "Suoi Vang, Da Lat City",
    mapQuery: "Ana Mandara Villas Dalat",
  },
  {
    id: 3,
    name: "Terracotta Hotel & Resort Dalat",
    stars: 4,
    price: 2200000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Terracotta cung cấp phòng nghỉ tiện nghi, sân vườn rộng và nhiều tiện ích nội khu phù hợp gia đình hoặc đoàn khách.",
    address: "12 Phan Boi Chau, Da Lat",
    mapQuery: "Terracotta Hotel & Resort Dalat",
  },
  {
    id: 4,
    name: "Hôtel Colline Dalat",
    stars: 4,
    price: 2500000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Hôtel Colline: boutique hotel phong cách Pháp, phòng ấm cúng, nằm gần hồ và các điểm tham quan Đà Lạt.",
    address: "8 Thu Khoa Huan, Da Lat",
    mapQuery: "Hotel Colline Dalat",
  },
  {
    id: 5,
    name: "Ladalat Hotel",
    stars: 5,
    price: 3400000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Ladalat: resort & spa cao cấp, phòng rộng, dịch vụ tốt và thuận tiện di chuyển đến các điểm du lịch.",
    address: "2 Hung Vuong, Da Lat",
    mapQuery: "Ladalat Hotel Da Lat",
  },
  {
    id: 6,
    name: "Swiss-Belresort Tuyen Lam Dalat",
    stars: 5,
    price: 3600000,
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Swiss-Belresort nằm gần hồ Tuyền Lâm, cảnh quan đẹp, phù hợp nghỉ dưỡng cao cấp và hội thảo.",
    address: "Tuyen Lam Lake, Da Lat",
    mapQuery: "Swiss-Belresort Tuyen Lam Dalat",
  },
  {
    id: 7,
    name: "Mường Thanh Holiday Da Lat",
    stars: 4,
    price: 1800000,
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Mường Thanh Holiday: chuỗi khách sạn tiện nghi, giá hợp lý, phục vụ nhóm khách du lịch và công tác.",
    address: "18 Le Loi, Da Lat",
    mapQuery: "Muong Thanh Holiday Dalat",
  },
  {
    id: 8,
    name: "Sammy Dalat Hotel",
    stars: 4,
    price: 1600000,
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Sammy Dalat: khách sạn ấm cúng, phòng sạch sẽ, thiết kế hiện đại, phù hợp du khách trẻ và gia đình nhỏ.",
    address: "5 Phan Dinh Phung, Da Lat",
    mapQuery: "Sammy Hotel Dalat",
  },
  {
    id: 9,
    name: "Golf Valley Hotel Dalat",
    stars: 4,
    price: 2000000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Golf Valley: gần sân golf, không gian yên tĩnh, phù hợp cho khách thích nghỉ dưỡng thư giãn.",
    address: "Near Dalat Golf Course, Da Lat",
    mapQuery: "Golf Valley Hotel Dalat",
  },
  {
    id: 10,
    name: "TTC Hotel Premium Ngọc Lan",
    stars: 4,
    price: 2100000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "TTC Ngọc Lan: vị trí gần trung tâm, phòng tiện nghi và dịch vụ chu đáo; lựa chọn giá trị cho du lịch Đà Lạt.",
    address: "22 Nguyen Thi Minh Khai, Da Lat",
    mapQuery: "TTC Hotel Premium Ngoc Lan Dalat",
  },
];

export default function DalatHotelDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels.find((h) => h.id === Number(id));
  const [mainImage, setMainImage] = useState(hotel?.image);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return (
      <div className="p-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
        <Link href="/khach-san/mien-nam/da-lat" className="text-green-700 underline">
          ← Quay lại danh sách Đà Lạt
        </Link>
      </div>
    );
  }

  const calcTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24);
    if (days <= 0) return 0;
    return days * hotel.price * rooms;
  };

  const handleBook = (e) => {
    e.preventDefault();
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng.");
      return;
    }
    const total = calcTotal();
    alert(`Yêu cầu đặt phòng gửi: ${hotel.name}\nTổng: ${total.toLocaleString("vi-VN")}đ\n(Trang demo chưa thực hiện thanh toán)`);
    // nếu muốn chuyển trang thanh toán: router.push(...)
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      <Link href="/khach-san/mien-nam/da-lat" className="text-green-700 underline">
        ← Quay lại danh sách Đà Lạt
      </Link>

      <img src={mainImage} alt={hotel.name} className="w-full h-80 object-cover rounded-2xl shadow mb-4 mt-4" />

      {/* Gallery */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {hotel.gallery.map((g, i) => (
          <div key={i} className="overflow-hidden rounded-xl shadow-sm cursor-pointer" onClick={() => setMainImage(g)}>
            <img src={g} alt={`${hotel.name} ${i+1}`} className="w-full h-40 object-cover transform hover:scale-105 transition" />
          </div>
        ))}
      </div>

      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
      <p className="text-gray-600 mb-1">{hotel.address}</p>
      <p className="text-xl font-semibold mb-4 text-green-700">{hotel.price.toLocaleString("vi-VN")}đ / đêm</p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          <li>Hồ bơi / Spa</li>
          <li>Nhà hàng & phục vụ 24/7</li>
          <li>Wifi miễn phí</li>
          <li>Đưa đón sân bay (tùy khách sạn)</li>
        </ul>
      </div>

      {/* Đặt phòng */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form className="flex flex-col gap-3" onSubmit={handleBook}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm text-gray-600">
              Ngày nhận
              <input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="border p-2 rounded-md w-full mt-1" required />
            </label>
            <label className="text-sm text-gray-600">
              Ngày trả
              <input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="border p-2 rounded-md w-full mt-1" required />
            </label>
            <label className="text-sm text-gray-600">
              Số phòng
              <input type="number" min="1" value={rooms} onChange={(e) => setRooms(Number(e.target.value) || 1)} className="border p-2 rounded-md w-full mt-1" />
            </label>
          </div>

          <div className="flex items-center justify-between mt-3">
            <p className="text-lg font-semibold">Tổng tiền: <span className="text-green-700">{calcTotal().toLocaleString("vi-VN")}đ</span></p>
            <div className="flex gap-3">
              <button type="submit" className="bg-green-700 text-white px-6 py-2 rounded-lg hover:bg-green-800">Đặt ngay</button>
              <Link href="/khach-san/mien-nam/da-lat" className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">Quay lại</Link>
            </div>
          </div>
        </form>
      </div>

      {/* Map */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe src={mapSrc} width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>

      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900">← Về Trang chủ</Link>
        <Link href="/khach-san/mien-nam/da-lat" className="text-green-700 underline hover:text-green-900">← Quay lại Danh sách Đà Lạt</Link>
      </div>
    </div>
  );
}
