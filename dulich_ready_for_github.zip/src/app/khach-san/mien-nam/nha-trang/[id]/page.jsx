"use client";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const hotels = [
  {
    id:1, name:"Vinpearl Resort Nha Trang", stars:5, price:7500000,
    image:"https://images.unsplash.com/photo-1551906993-2e1a3f1b6b4c?auto=format&fit=crop&w=1600&q=80",
    gallery:["https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"],
    description:"Vinpearl Nha Trang — resort 5 sao lớn với bãi biển riêng, villa và tiện nghi quốc tế.", address:"Vinpearl Island, Nha Trang", mapQuery:"Vinpearl Resort Nha Trang"
  },
  {
    id:2, name:"InterContinental Nha Trang", stars:5, price:6800000,
    image:"https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery:["https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80"],
    description:"InterContinental Nha Trang — resort cao cấp ven biển với nhiều tiện ích.", address:"Tran Phu, Nha Trang", mapQuery:"InterContinental Nha Trang"
  },
  {
    id:3, name:"Sheraton Nha Trang Hotel & Spa", stars:5, price:6400000,
    image:"https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery:["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"],
    description:"Sheraton Nha Trang — khách sạn & spa tiêu chuẩn quốc tế.", address:"Phuoc Dong, Nha Trang", mapQuery:"Sheraton Nha Trang"
  },
  { id:4, name:"Havana Nha Trang Hotel", stars:4, price:2400000, image:"https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80"], description:"Havana Nha Trang — boutique hotel gần biển.", address:"Tran Phu, Nha Trang", mapQuery:"Havana Nha Trang" },
  { id:5, name:"The Costa Nha Trang Residences", stars:4, price:3000000, image:"https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"], description:"Residences cao cấp gần bãi biển.", address:"Nha Trang Bay", mapQuery:"The Costa Nha Trang" },
  { id:6, name:"Mường Thanh Luxury Nha Trang", stars:5, price:2800000, image:"https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"], description:"Mường Thanh Luxury Nha Trang — tiện nghi và vị trí trung tâm.", address:"4 Tran Phu, Nha Trang", mapQuery:"Muong Thanh Luxury Nha Trang" },
  { id:7, name:"Amiana Resort Nha Trang", stars:5, price:7200000, image:"https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"], description:"Amiana Resort — resort 5 sao ven biển/đồi.", address:"Bai Dai, Nha Trang", mapQuery:"Amiana Resort Nha Trang" },
  { id:8, name:"Premier Havana Nha Trang", stars:4, price:2300000, image:"https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80"], description:"Premier Havana — khách sạn phong cách Cuba tại Nha Trang.", address:"Tran Phu, Nha Trang", mapQuery:"Premier Havana Nha Trang" },
  { id:9, name:"Citadines Bayfront Nha Trang", stars:4, price:2100000, image:"https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"], description:"Citadines — căn hộ dịch vụ ven biển.", address:"Nha Trang Bay", mapQuery:"Citadines Bayfront Nha Trang" },
  { id:10, name:"Alma Resort Cam Ranh", stars:5, price:8000000, image:"https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80", gallery:["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"], description:"Alma Resort Cam Ranh — resort sang trọng gần Nha Trang.", address:"Cam Ranh", mapQuery:"Alma Resort Cam Ranh" }
];

export default function NhaTrangDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels.find(h => h.id === Number(id));
  const [mainImage, setMainImage] = useState(hotel?.image);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) return (
    <div className="p-10 text-center">
      <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
      <Link href="/khach-san/mien-nam/nha-trang" className="text-green-700 underline">← Quay lại</Link>
    </div>
  );

  const calcTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut)-new Date(checkIn))/(1000*60*60*24);
    if (days <= 0) return 0;
    return days * hotel.price * rooms;
  };

  const handleBook = (e) => {
    e.preventDefault();
    if (!checkIn || !checkOut) { alert("Vui lòng chọn ngày nhận và trả phòng."); return; }
    alert(`Yêu cầu đặt phòng: ${hotel.name}\nTổng: ${calcTotal().toLocaleString("vi-VN")}đ\n(Demo)`);
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      <Link href="/khach-san/mien-nam/nha-trang" className="text-green-700 underline">← Quay lại danh sách Nha Trang</Link>
      <img src={mainImage} alt={hotel.name} className="w-full h-80 object-cover rounded-2xl shadow mb-4 mt-4" />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {hotel.gallery.map((g,i)=>(
          <div key={i} className="overflow-hidden rounded-xl shadow-sm cursor-pointer" onClick={()=>setMainImage(g)}>
            <img src={g} alt={`${hotel.name} ${i+1}`} className="w-full h-40 object-cover transform hover:scale-105 transition" />
          </div>
        ))}
      </div>
      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">{"★".repeat(hotel.stars)}{"☆".repeat(5-hotel.stars)}</p>
      <p className="text-gray-600 mb-1">{hotel.address}</p>
      <p className="text-xl font-semibold mb-4 text-green-700">{hotel.price.toLocaleString("vi-VN")}đ / đêm</p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1"><li>Hồ bơi / Spa</li><li>Nhà hàng & phục vụ 24/7</li><li>Wifi miễn phí</li><li>Đưa đón sân bay</li></ul>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form className="flex flex-col gap-3" onSubmit={handleBook}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm text-gray-600">Ngày nhận<input type="date" value={checkIn} onChange={(e)=>setCheckIn(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/></label>
            <label className="text-sm text-gray-600">Ngày trả<input type="date" value={checkOut} onChange={(e)=>setCheckOut(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/></label>
            <label className="text-sm text-gray-600">Số phòng<input type="number" min="1" value={rooms} onChange={(e)=>setRooms(Number(e.target.value)||1)} className="border p-2 rounded-md w-full mt-1"/></label>
          </div>
          <div className="flex items-center justify-between mt-3">
            <p className="text-lg font-semibold">Tổng tiền: <span className="text-green-700">{calcTotal().toLocaleString("vi-VN")}đ</span></p>
            <div className="flex gap-3">
              <button type="submit" className="bg-green-700 text-white px-6 py-2 rounded-lg hover:bg-green-800">Đặt ngay</button>
              <Link href="/khach-san/mien-nam/nha-trang" className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">Quay lại</Link>
            </div>
          </div>
        </form>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe src={mapSrc} width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>

      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900">← Về Trang chủ</Link>
        <Link href="/khach-san/mien-nam/nha-trang" className="text-green-700 underline hover:text-green-900">← Quay lại Nha Trang</Link>
      </div>
    </div>
  );
}
