"use client";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "Vinpearl Resort & Spa Phú Quốc",
    stars: 5,
    price: 6500000,
    image: "https://images.unsplash.com/photo-1551906993-2e1a3f1b6b4c?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Vinpearl Resort & Spa Phú Quốc — khu nghỉ dưỡng 5 sao lớn, sở hữu bãi biển riêng, villa và tiện ích tiêu chuẩn quốc tế.",
    mapQuery: "Vinpearl Phu Quoc Resort",
  },
  {
    id: 2,
    name: "InterContinental Phu Quoc Long Beach Resort",
    stars: 5,
    price: 7200000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "InterContinental Long Beach — resort cao cấp tọa lạc trên bờ biển dài, nhiều nhà hàng, spa và hoạt động giải trí quy mô.",
    mapQuery: "InterContinental Phu Quoc Long Beach Resort",
  },
  {
    id: 3,
    name: "JW Marriott Phu Quoc Emerald Bay",
    stars: 5,
    price: 7800000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "JW Marriott Emerald Bay — thiết kế độc đáo, kiến trúc ấn tượng, dịch vụ 5 sao và không gian nghỉ dưỡng đẳng cấp.",
    mapQuery: "JW Marriott Phu Quoc Emerald Bay",
  },
  {
    id: 4,
    name: "Premier Village Phu Quoc Resort",
    stars: 5,
    price: 8600000,
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Premier Village — khu biệt thự biển riêng tư, dịch vụ villa cao cấp, phù hợp nhóm hoặc gia đình muốn riêng tư.",
    mapQuery: "Premier Village Phu Quoc Resort",
  },
  {
    id: 5,
    name: "Fusion Resort Phu Quoc",
    stars: 5,
    price: 5400000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Fusion Resort — phong cách thư giãn, spa & all-spa menu, phù hợp cho những ai cần nghỉ dưỡng thực sự.",
    mapQuery: "Fusion Resort Phu Quoc",
  },
  {
    id: 6,
    name: "New World Phu Quoc Resort",
    stars: 5,
    price: 6000000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "New World — resort cao cấp, tiện nghi hiện đại, phù hợp du lịch hạng sang và hội nghị sự kiện.",
    mapQuery: "New World Phu Quoc Resort",
  },
  {
    id: 7,
    name: "Dusit Princess Moonrise Beach Resort",
    stars: 4,
    price: 3200000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Dusit Princess Moonrise — resort 4 sao, tiêu chuẩn quốc tế, vị trí sát bãi biển, phù hợp du lịch gia đình.",
    mapQuery: "Dusit Princess Moonrise Beach Resort Phu Quoc",
  },
  {
    id: 8,
    name: "Pullman Phu Quoc Beach Resort",
    stars: 5,
    price: 6800000,
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Pullman Phu Quoc — resort hiện đại, phù hợp khách công tác và nghỉ dưỡng, tiện ích toàn diện.",
    mapQuery: "Pullman Phu Quoc Beach Resort",
  },
  {
    id: 9,
    name: "Sea Star Resort Phu Quoc",
    stars: 4,
    price: 2100000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Sea Star Resort — lựa chọn hợp lý cho kỳ nghỉ tại Phú Quốc, gần biển, giá tốt và dịch vụ ổn định.",
    mapQuery: "Sea Star Resort Phu Quoc",
  },
  {
    id: 10,
    name: "Salinda Resort Phu Quoc Island",
    stars: 5,
    price: 7000000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
    ],
    description:
      "Salinda Resort — resort boutique cao cấp, nhà hàng, spa, bể bơi và dịch vụ tận tâm.",
    mapQuery: "Salinda Resort Phu Quoc Island",
  },
];

export default function PhuQuocDetail() {
  const { id } = useParams();
  const hotel = hotels.find((h) => h.id === Number(id));
  const [mainImage, setMainImage] = useState(hotel?.image);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return (
      <div className="p-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
        <Link href="/khach-san/mien-nam/phu-quoc" className="text-green-700 underline">
          ← Quay lại danh sách Phú Quốc
        </Link>
      </div>
    );
  }

  const calcTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24);
    if (days <= 0) return 0;
    return days * hotel.price * rooms;
  };

  const handleBook = (e) => {
    e.preventDefault();
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng.");
      return;
    }
    const total = calcTotal();
    alert(`Yêu cầu đặt phòng gửi: ${hotel.name}\nTổng: ${total.toLocaleString("vi-VN")}đ\n(Trang demo chưa thực hiện thanh toán)`);
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      <Link href="/khach-san/mien-nam/phu-quoc" className="text-green-700 underline">
        ← Quay lại danh sách Phú Quốc
      </Link>

      <img src={mainImage} alt={hotel.name} className="w-full h-80 object-cover rounded-2xl shadow mb-4 mt-4" />

      {/* Gallery */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {hotel.gallery.map((g, i) => (
          <div key={i} className="overflow-hidden rounded-xl shadow-sm cursor-pointer" onClick={() => setMainImage(g)}>
            <img src={g} alt={`${hotel.name} ${i+1}`} className="w-full h-40 object-cover transform hover:scale-105 transition" />
          </div>
        ))}
      </div>

      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
      <p className="text-xl font-semibold mb-4 text-green-700">{hotel.price.toLocaleString("vi-VN")}đ / đêm</p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          <li>Hồ bơi / Spa</li>
          <li>Nhà hàng & phục vụ 24/7</li>
          <li>Wifi miễn phí</li>
          <li>Đưa đón sân bay (tùy khách sạn)</li>
        </ul>
      </div>

      {/* Đặt phòng */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form className="flex flex-col gap-3" onSubmit={handleBook}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm text-gray-600">
              Ngày nhận
              <input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="border p-2 rounded-md w-full mt-1" required />
            </label>
            <label className="text-sm text-gray-600">
              Ngày trả
              <input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="border p-2 rounded-md w-full mt-1" required />
            </label>
            <label className="text-sm text-gray-600">
              Số phòng
              <input type="number" min="1" value={rooms} onChange={(e) => setRooms(Number(e.target.value) || 1)} className="border p-2 rounded-md w-full mt-1" />
            </label>
          </div>

          <div className="flex items-center justify-between mt-3">
            <p className="text-lg font-semibold">Tổng tiền: <span className="text-green-700">{calcTotal().toLocaleString("vi-VN")}đ</span></p>
            <div className="flex gap-3">
              <button type="submit" className="bg-green-700 text-white px-6 py-2 rounded-lg hover:bg-green-800">Đặt ngay</button>
              <Link href="/khach-san/mien-nam/phu-quoc" className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">Quay lại</Link>
            </div>
          </div>
        </form>
      </div>

      {/* Map */}
      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe src={mapSrc} width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>

      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900">← Về Trang chủ</Link>
        <Link href="/khach-san/mien-nam/phu-quoc" className="text-green-700 underline hover:text-green-900">← Quay lại Danh sách Phú Quốc</Link>
      </div>
    </div>
  );
}
