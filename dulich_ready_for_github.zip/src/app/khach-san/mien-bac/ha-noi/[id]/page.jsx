"use client";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import { useState } from "react";
import Link from "next/link";

const hotels = {
  melia: {
    name: "Khách sạn Melia Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/melia-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/melia-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/melia-hanoi-3.jpg",
    ],
    price: 3000000,
    stars: 5,
    address: "44B Lý Thường Kiệt, Hoàn Kiếm, Hà Nội",
    description:
      "Khách sạn 5 sao cao cấp nằm giữa trung tâm Hà Nội, sở hữu tầm nhìn tuyệt đẹp, dịch vụ chuyên nghiệp và nhà hàng đẳng cấp quốc tế.",
    services: [
      "Hồ bơi ngoài trời",
      "Ăn sáng miễn phí",
      "Spa & Massage",
      "Phòng gym hiện đại",
      "Wifi tốc độ cao",
    ],
  },

  apricot: {
    name: "Khách sạn Apricot Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/apricot-hotel-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/apricot-hotel-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/apricot-hotel-hanoi-3.jpg",
    ],
    price: 2800000,
    stars: 5,
    address: "136 Hàng Trống, Hoàn Kiếm, Hà Nội",
    description:
      "Khách sạn Apricot mang phong cách châu Âu cổ điển, view hồ Hoàn Kiếm, phù hợp cho du khách yêu sự sang trọng và nghệ thuật.",
    services: [
      "Hồ bơi trên tầng thượng",
      "Nhà hàng sang trọng",
      "Phòng tập thể dục",
      "Dịch vụ spa cao cấp",
    ],
  },

  silkpath: {
    name: "Khách sạn Silk Path Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/silk-path-hotel-1.jpg",
      "https://cdn3.ivivu.com/2022/10/silk-path-hotel-2.jpg",
      "https://cdn3.ivivu.com/2022/10/silk-path-hotel-3.jpg",
    ],
    price: 1900000,
    stars: 4,
    address: "195-199 Hàng Bông, Hoàn Kiếm, Hà Nội",
    description:
      "Silk Path Hotel mang đến sự tiện nghi, tinh tế, nằm ngay trung tâm phố cổ, gần Hồ Gươm và Nhà Thờ Lớn.",
    services: [
      "Ăn sáng miễn phí",
      "Bar & Lounge",
      "Trung tâm thể dục",
      "Wifi miễn phí",
    ],
  },

  lheritage: {
    name: "Khách sạn L’Heritage Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/lheritage-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/lheritage-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/lheritage-hanoi-3.jpg",
    ],
    price: 1700000,
    stars: 4,
    address: "94 Hàng Gà, Hoàn Kiếm, Hà Nội",
    description:
      "Khách sạn L’Heritage tọa lạc tại khu phố cổ, thiết kế sang trọng, thân thiện với du khách trong và ngoài nước.",
    services: [
      "Ăn sáng miễn phí",
      "Dịch vụ giặt ủi",
      "Phòng tập gym",
      "Dịch vụ lễ tân 24h",
    ],
  },

  intercontinental: {
    name: "InterContinental Hanoi Westlake",
    images: [
      "https://cdn3.ivivu.com/2022/10/intercontinental-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/intercontinental-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/intercontinental-hanoi-3.jpg",
    ],
    price: 5500000,
    stars: 5,
    address: "5 Từ Hoa, Tây Hồ, Hà Nội",
    description:
      "Khách sạn 5 sao sang trọng nằm bên hồ Tây, có hồ bơi nước ngoài trời, nhà hàng view hồ lãng mạn và phòng nghỉ cao cấp.",
    services: [
      "Hồ bơi ngoài trời",
      "Spa thư giãn",
      "Nhà hàng cao cấp",
      "Bar view hồ",
      "Xe đưa đón sân bay",
    ],
  },

  grandvista: {
    name: "Grand Vista Hanoi Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/grand-vista-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/grand-vista-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/grand-vista-hanoi-3.jpg",
    ],
    price: 2500000,
    stars: 4,
    address: "146 Giảng Võ, Ba Đình, Hà Nội",
    description:
      "Grand Vista là khách sạn 4 sao hiện đại, nằm gần khu trung tâm và các khu hành chính, phù hợp cho công tác và nghỉ dưỡng.",
    services: [
      "Hồ bơi trong nhà",
      "Phòng họp hội nghị",
      "Nhà hàng Á - Âu",
      "Bãi đỗ xe miễn phí",
    ],
  },

  dolce: {
    name: "Dolce by Wyndham Hanoi Golden Lake",
    images: [
      "https://cdn3.ivivu.com/2022/10/dolce-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/dolce-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/dolce-hanoi-3.jpg",
    ],
    price: 6900000,
    stars: 5,
    address: "B7 Giảng Võ, Ba Đình, Hà Nội",
    description:
      "Khách sạn 5 sao dát vàng độc đáo, nổi tiếng với hồ bơi và nội thất mạ vàng, dịch vụ đạt chuẩn quốc tế.",
    services: [
      "Hồ bơi dát vàng",
      "Nhà hàng sang trọng",
      "Spa & Sauna",
      "Phòng gym cao cấp",
      "Xe đưa đón sân bay",
    ],
  },

  peridot: {
    name: "Peridot Grand Luxury Boutique Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/peridot-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/peridot-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/peridot-hanoi-3.jpg",
    ],
    price: 3300000,
    stars: 5,
    address: "33 Hàng Bún, Hoàn Kiếm, Hà Nội",
    description:
      "Peridot Grand là khách sạn 5 sao boutique độc đáo, mang đậm phong cách Á – Âu, nổi bật với hồ bơi rooftop và bar tầng thượng.",
    services: [
      "Hồ bơi tầng thượng",
      "Sky bar view toàn cảnh",
      "Dịch vụ spa cao cấp",
      "Ăn sáng buffet",
    ],
  },

  tirant: {
    name: "Khách sạn Tirant Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/tirant-hotel-1.jpg",
      "https://cdn3.ivivu.com/2022/10/tirant-hotel-2.jpg",
      "https://cdn3.ivivu.com/2022/10/tirant-hotel-3.jpg",
    ],
    price: 2200000,
    stars: 4,
    address: "38 Gia Ngư, Hoàn Kiếm, Hà Nội",
    description:
      "Tirant Hotel nằm ngay trung tâm phố cổ, thuận tiện đi bộ ra hồ Hoàn Kiếm, phù hợp cho cả du lịch và công tác.",
    services: [
      "Ăn sáng miễn phí",
      "Hồ bơi tầng thượng",
      "Dịch vụ tour du lịch",
      "Phòng gym & spa",
    ],
  },

  capella: {
    name: "Capella Hanoi Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/capella-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/capella-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/capella-hanoi-3.jpg",
    ],
    price: 6500000,
    stars: 5,
    address: "11 Lê Phụng Hiểu, Hoàn Kiếm, Hà Nội",
    description:
      "Khách sạn Capella Hà Nội là biểu tượng của sự xa hoa, với phong cách thiết kế châu Âu cổ điển và dịch vụ 5 sao hoàn hảo.",
    services: [
      "Hồ bơi trong nhà",
      "Spa & Massage",
      "Phòng hội nghị",
      "Nhà hàng Âu sang trọng",
    ],
  },

  pullman: {
    name: "Pullman Hanoi Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/pullman-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/pullman-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/pullman-hanoi-3.jpg",
    ],
    price: 3100000,
    stars: 5,
    address: "40 Cát Linh, Đống Đa, Hà Nội",
    description:
      "Khách sạn Pullman là lựa chọn tuyệt vời cho doanh nhân và du khách, với phong cách hiện đại và tiện nghi hàng đầu.",
    services: [
      "Ăn sáng buffet",
      "Hồ bơi ngoài trời",
      "Spa & Sauna",
      "Phòng gym chuyên nghiệp",
    ],
  },

  mercure: {
    name: "Mercure Hanoi La Gare Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/mercure-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/mercure-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/mercure-hanoi-3.jpg",
    ],
    price: 2000000,
    stars: 4,
    address: "94 Lý Thường Kiệt, Hoàn Kiếm, Hà Nội",
    description:
      "Mercure La Gare nằm ngay trung tâm, chỉ vài bước đến ga Hà Nội, mang đến trải nghiệm nghỉ dưỡng tiện nghi và hiện đại.",
    services: [
      "Ăn sáng miễn phí",
      "Bar & Lounge",
      "Phòng hội nghị nhỏ",
      "Wifi miễn phí",
    ],
  },

  crowneplaza: {
    name: "Crowne Plaza West Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/crowne-plaza-1.jpg",
      "https://cdn3.ivivu.com/2022/10/crowne-plaza-2.jpg",
      "https://cdn3.ivivu.com/2022/10/crowne-plaza-3.jpg",
    ],
    price: 2700000,
    stars: 5,
    address: "36 Lê Đức Thọ, Nam Từ Liêm, Hà Nội",
    description:
      "Crowne Plaza là khách sạn quốc tế 5 sao nổi tiếng với phong cách hiện đại, tiện nghi và dịch vụ chuyên nghiệp.",
    services: [
      "Hồ bơi trong nhà",
      "Spa & Gym",
      "Phòng hội nghị",
      "Nhà hàng Âu - Á",
    ],
  },

  sunway: {
    name: "Sunway Hotel Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/sunway-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/sunway-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/sunway-hanoi-3.jpg",
    ],
    price: 1600000,
    stars: 3,
    address: "19 Phạm Đình Hổ, Hai Bà Trưng, Hà Nội",
    description:
      "Sunway Hotel là khách sạn 3 sao thân thiện, phù hợp cho du khách tìm kiếm sự tiện nghi với chi phí hợp lý.",
    services: [
      "Ăn sáng miễn phí",
      "Dịch vụ giặt ủi",
      "Phòng tập gym nhỏ",
      "Wifi miễn phí",
    ],
  },

  rose: {
    name: "Khách sạn Hanoi Rose Boutique",
    images: [
      "https://cdn3.ivivu.com/2022/10/hanoi-rose-1.jpg",
      "https://cdn3.ivivu.com/2022/10/hanoi-rose-2.jpg",
      "https://cdn3.ivivu.com/2022/10/hanoi-rose-3.jpg",
    ],
    price: 1500000,
    stars: 3,
    address: "59 Hàng Bông, Hoàn Kiếm, Hà Nội",
    description:
      "Rose Boutique là khách sạn 3 sao nhỏ xinh tại trung tâm phố cổ, mang phong cách hiện đại, tiện nghi.",
    services: [
      "Ăn sáng miễn phí",
      "Dịch vụ tour du lịch",
      "Wifi tốc độ cao",
      "Giặt ủi & dọn phòng",
    ],
  },

  gondola: {
    name: "Khách sạn Gondola Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/gondola-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/gondola-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/gondola-hanoi-3.jpg",
    ],
    price: 1800000,
    stars: 4,
    address: "31 Hàng Hành, Hoàn Kiếm, Hà Nội",
    description:
      "Khách sạn Gondola tọa lạc gần hồ Hoàn Kiếm, mang phong cách cổ điển châu Âu pha lẫn nét Việt Nam tinh tế.",
    services: [
      "Ăn sáng buffet",
      "Dịch vụ spa",
      "Bar & Lounge",
      "Xe đưa đón sân bay",
    ],
  },

  angel: {
    name: "Khách sạn Angel Palace Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/angel-palace-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/angel-palace-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/angel-palace-hanoi-3.jpg",
    ],
    price: 1700000,
    stars: 3,
    address: "173 Hàng Bông, Hoàn Kiếm, Hà Nội",
    description:
      "Angel Palace mang phong cách cổ điển pha lẫn hiện đại, nằm trong khu phố mua sắm sầm uất nhất Hà Nội.",
    services: [
      "Ăn sáng miễn phí",
      "Wifi miễn phí",
      "Dịch vụ thuê xe",
      "Phòng gia đình",
    ],
  },

  bosslegend: {
    name: "Khách sạn Boss Legend Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/boss-legend-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/boss-legend-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/boss-legend-hanoi-3.jpg",
    ],
    price: 2100000,
    stars: 4,
    address: "21 Hàng Thùng, Hoàn Kiếm, Hà Nội",
    description:
      "Boss Legend là khách sạn 4 sao nằm gần hồ Hoàn Kiếm, có hồ bơi trong nhà và nhà hàng view thành phố.",
    services: [
      "Hồ bơi trong nhà",
      "Nhà hàng tầng thượng",
      "Phòng gym & spa",
      "Dịch vụ giặt ủi",
    ],
  },

  calidas: {
    name: "Calidas Landmark 72 Hanoi Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/calidas-landmark-72-1.jpg",
      "https://cdn3.ivivu.com/2022/10/calidas-landmark-72-2.jpg",
      "https://cdn3.ivivu.com/2022/10/calidas-landmark-72-3.jpg",
    ],
    price: 4200000,
    stars: 5,
    address: "Keangnam Tower, Phạm Hùng, Nam Từ Liêm, Hà Nội",
    description:
      "Calidas Landmark 72 nằm trong toà nhà cao nhất Việt Nam, cung cấp căn hộ khách sạn sang trọng với tầm nhìn tuyệt đẹp.",
    services: [
      "Hồ bơi ngoài trời",
      "Phòng tập gym hiện đại",
      "Nhà hàng quốc tế",
      "Bãi đỗ xe riêng",
    ],
  },

  eden: {
    name: "Eden Hanoi Hotel",
    images: [
      "https://cdn3.ivivu.com/2022/10/eden-hanoi-1.jpg",
      "https://cdn3.ivivu.com/2022/10/eden-hanoi-2.jpg",
      "https://cdn3.ivivu.com/2022/10/eden-hanoi-3.jpg",
    ],
    price: 1900000,
    stars: 4,
    address: "22 Đoàn Trần Nghiệp, Hai Bà Trưng, Hà Nội",
    description:
      "Eden Hotel Hà Nội là khách sạn 4 sao có phong cách thanh lịch, gần trung tâm mua sắm và khu ẩm thực nổi tiếng.",
    services: [
      "Ăn sáng buffet",
      "Spa & Sauna",
      "Phòng họp nhỏ",
      "Dịch vụ thuê xe",
    ],
  },

  maydeville: {
    name: "May De Ville Premier Hotel Hanoi",
    images: [
      "https://cdn3.ivivu.com/2022/10/may-de-ville-1.jpg",
      "https://cdn3.ivivu.com/2022/10/may-de-ville-2.jpg",
      "https://cdn3.ivivu.com/2022/10/may-de-ville-3.jpg",
    ],
    price: 2600000,
    stars: 4,
    address: "43 Gia Ngư, Hoàn Kiếm, Hà Nội",
    description:
      "May De Ville là khách sạn 4 sao trung tâm phố cổ, gần hồ Hoàn Kiếm, tiện nghi hiện đại và dịch vụ chuyên nghiệp.",
    services: [
      "Hồ bơi tầng thượng",
      "Nhà hàng Việt - Âu",
      "Phòng gym",
      "Dịch vụ lễ tân 24h",
    ],
  },
};

// -------------------------------------------------------------
// Trang chi tiết khách sạn Hà Nội — có gallery, đặt phòng, map
// -------------------------------------------------------------
export default function HotelDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels[id];
  const [mainImage, setMainImage] = useState(hotel?.images?.[0]);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return (
      <div className="text-center py-20">
        <h1 className="text-2xl font-bold text-red-600">Không tìm thấy khách sạn!</h1>
        <Link href="/khach-san/ha-noi" className="text-green-700 underline">
          Quay lại danh sách
        </Link>
      </div>
    );
  }

  const calculateTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days =
      (new Date(checkOut).getTime() - new Date(checkIn).getTime()) /
      (1000 * 60 * 60 * 24);
    return days > 0 ? days * hotel.price * rooms : 0;
  };

  const handlePayment = () => {
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng!");
      return;
    }
    const total = calculateTotal().toLocaleString("vi-VN");
    // Nếu bạn muốn bỏ luồng thanh toán, đổi router.push thành alert hoặc xử lý khác
    router.push(
      `/thanh-toan?hotel=${encodeURIComponent(
        hotel.name
      )}&price=${total}&checkin=${checkIn}&checkout=${checkOut}&rooms=${rooms}`
    );
  };

  // Tạo src iframe bản đồ từ address (an toàn, không cần map field cứng)
  const mapSrc = hotel.address
    ? `https://www.google.com/maps?q=${encodeURIComponent(hotel.address)}&output=embed`
    : "";

  return (
    <div className="max-w-6xl mx-auto py-10 px-4">
      <Link href="/khach-san/ha-noi" className="text-green-700 hover:underline">
        ← Quay lại danh sách khách sạn
      </Link>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Ảnh chính & gallery */}
        <div>
          <Image
            src={mainImage}
            alt={hotel.name}
            width={800}
            height={600}
            className="w-full h-[400px] rounded-2xl object-cover shadow-lg"
          />
          <div className="flex gap-3 mt-3">
            {hotel.images.map((img, i) => (
              <Image
                key={i}
                src={img}
                alt={`phụ ${i + 1}`}
                width={150}
                height={100}
                onClick={() => setMainImage(img)}
                className={`cursor-pointer rounded-lg border ${mainImage === img ? "border-green-700" : "border-transparent"}`}
              />
            ))}
          </div>
        </div>

        {/* Thông tin & đặt phòng */}
        <div>
          <h1 className="text-3xl font-bold text-green-800">{hotel.name}</h1>
          <p className="text-yellow-500 text-lg mt-1">
            {"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}
          </p>
          <p className="text-gray-600 mt-1">{hotel.address}</p>
          <p className="text-green-700 font-semibold text-xl mt-2">
            {hotel.price.toLocaleString("vi-VN")}đ / đêm
          </p>
          <p className="mt-4 text-gray-700 leading-relaxed">{hotel.description}</p>

          <h3 className="text-lg font-semibold mt-4 mb-2">Dịch vụ bao gồm:</h3>
          <ul className="list-disc list-inside text-gray-700">
            {hotel.services.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>

          <div className="mt-6 bg-white p-4 rounded-xl shadow-md">
            <h3 className="text-lg font-semibold mb-2">Đặt phòng</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="border p-2 rounded-lg"
              />
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="border p-2 rounded-lg"
              />
              <input
                type="number"
                min="1"
                value={rooms}
                onChange={(e) => setRooms(parseInt(e.target.value || "1"))}
                className="border p-2 rounded-lg"
              />
            </div>
            <div className="mt-4 flex justify-between items-center">
              <p className="text-lg font-semibold">
                Tổng tiền:{" "}
                <span className="text-green-700">
                  {calculateTotal().toLocaleString("vi-VN")}đ
                </span>
              </p>
              <button
                onClick={handlePayment}
                className="bg-green-700 text-white px-6 py-3 rounded-lg hover:bg-green-800"
              >
                Thanh toán
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Map giống Đà Nẵng - dùng địa chỉ để tạo embed */}
      <div className="bg-white p-5 rounded-xl shadow-md mt-8 mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          {mapSrc ? (
            <iframe
              src={mapSrc}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          ) : (
            <p className="text-gray-500 p-4">Không có dữ liệu bản đồ cho khách sạn này.</p>
          )}
        </div>
      </div>

      {/* Footer links */}
      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900 transition">
          ← Về Trang chủ
        </Link>
        <Link
          href="/khach-san/ha-noi"
          className="text-green-700 underline hover:text-green-900 transition"
        >
          ← Quay lại Danh sách khách sạn
        </Link>
      </div>
    </div>
  );
}
