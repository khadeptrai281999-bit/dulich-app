"use client";
import Image from "next/image";
import Link from "next/link";

const hotels = [
  {
    id: "melia",
    name: "Khách sạn Melia Hanoi",
    stars: 5,
    address: "44B Lý Thường Kiệt, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-12.jpg",
    price: "3.000.000đ/đêm",
  },
  {
    id: "apricot",
    name: "Khách sạn Apricot",
    stars: 5,
    address: "136 Hàng Trống, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-13.jpg",
    price: "2.800.000đ/đêm",
  },
  {
    id: "silkpath",
    name: "Khách sạn Silk Path",
    stars: 4,
    address: "195-199 Hàng Bông, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-14.jpg",
    price: "1.800.000đ/đêm",
  },
  {
    id: "lheritage",
    name: "Khách sạn L’Heritage Hanoi",
    stars: 4,
    address: "39 Hàng Bè, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-15.jpg",
    price: "1.500.000đ/đêm",
  },
  {
    id: "intercontinental",
    name: "InterContinental Hanoi Westlake",
    stars: 5,
    address: "5 Từ Hoa, Tây Hồ, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-16.jpg",
    price: "4.200.000đ/đêm",
  },
  {
    id: "grandvista",
    name: "Grand Vista Hanoi",
    stars: 5,
    address: "146 Giảng Võ, Đống Đa, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-17.jpg",
    price: "2.900.000đ/đêm",
  },
  {
    id: "dolce",
    name: "Dolce by Wyndham Hanoi Golden Lake",
    stars: 5,
    address: "B7 Giảng Võ, Ba Đình, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-18.jpg",
    price: "5.500.000đ/đêm",
  },
  {
    id: "peridot",
    name: "Peridot Grand Luxury Boutique Hotel",
    stars: 5,
    address: "33 Hàng Cót, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-19.jpg",
    price: "3.800.000đ/đêm",
  },
  {
    id: "tirant",
    name: "Khách sạn Tirant",
    stars: 4,
    address: "38 Gia Ngư, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-20.jpg",
    price: "2.000.000đ/đêm",
  },
  {
    id: "capella",
    name: "Capella Hanoi",
    stars: 5,
    address: "11 Lê Phụng Hiểu, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-21.jpg",
    price: "6.800.000đ/đêm",
  },
  {
    id: "pullman",
    name: "Pullman Hanoi Hotel",
    stars: 5,
    address: "40 Cát Linh, Đống Đa, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-22.jpg",
    price: "3.200.000đ/đêm",
  },
  {
    id: "mercure",
    name: "Mercure Hanoi La Gare Hotel",
    stars: 4,
    address: "94 Lý Thường Kiệt, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-23.jpg",
    price: "2.100.000đ/đêm",
  },
  {
    id: "crowneplaza",
    name: "Crowne Plaza West Hanoi",
    stars: 5,
    address: "36 Lê Đức Thọ, Mỹ Đình, Nam Từ Liêm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-24.jpg",
    price: "3.700.000đ/đêm",
  },
  {
    id: "sunway",
    name: "Sunway Hotel Hanoi",
    stars: 4,
    address: "19 Phạm Đình Hổ, Hai Bà Trưng, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-25.jpg",
    price: "1.900.000đ/đêm",
  },
  {
    id: "rose",
    name: "Rising Dragon Palace Hotel",
    stars: 3,
    address: "12 Nguyễn Quang Bích, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-26.jpg",
    price: "1.000.000đ/đêm",
  },
  {
    id: "gondola",
    name: "Hanoi Gondola Hotel & Spa",
    stars: 4,
    address: "31 Hàng Hành, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-27.jpg",
    price: "1.600.000đ/đêm",
  },
  {
    id: "angel",
    name: "Angel Palace Hotel",
    stars: 3,
    address: "173 Hàng Bông, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-28.jpg",
    price: "1.200.000đ/đêm",
  },
  {
    id: "bosslegend",
    name: "Boss Legend Hotel",
    stars: 4,
    address: "21 Hàng Thùng, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-29.jpg",
    price: "1.700.000đ/đêm",
  },
  {
    id: "calidas",
    name: "Calidas Landmark72 Royal Residence",
    stars: 5,
    address: "48 Tầng Keangnam, Phạm Hùng, Cầu Giấy, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-30.jpg",
    price: "4.000.000đ/đêm",
  },
  {
    id: "eden",
    name: "Hanoi Eden Plaza Hotel",
    stars: 3,
    address: "22 Doãn Kế Thiện, Cầu Giấy, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-31.jpg",
    price: "900.000đ/đêm",
  },
  {
    id: "maydeville",
    name: "May De Ville Premier Hotel & Spa",
    stars: 5,
    address: "57 Lý Thường Kiệt, Hoàn Kiếm, Hà Nội",
    image: "https://cdn3.ivivu.com/2022/10/khach-san-ha-noi-ivivu-32.jpg",
    price: "3.900.000đ/đêm",
  },
];

export default function HaNoiHotels() {
  return (
    <div className="max-w-6xl mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8 text-emerald-800">
        Khách sạn tại Hà Nội
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <div
            key={hotel.id}
            className="rounded-2xl shadow-lg overflow-hidden hover:scale-105 transition-transform duration-300"
          >
            <Image
              src={hotel.image}
              alt={hotel.name}
              width={600}
              height={400}
              className="w-full h-56 object-cover"
            />
            <div className="p-4 bg-white">
              <h2 className="text-lg font-semibold text-gray-800">{hotel.name}</h2>
              <p className="text-yellow-500">
                {"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}
              </p>
              <p className="text-gray-600 text-sm mb-2">{hotel.address}</p>
              <p className="text-green-600 font-semibold">{hotel.price}</p>
              <Link href={`/khach-san/mien-bac/ha-noi/${hotel.id}`}>
                <button className="mt-3 w-full bg-green-700 text-white py-2 rounded-lg hover:bg-green-800 transition">
                  Xem chi tiết
                </button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
