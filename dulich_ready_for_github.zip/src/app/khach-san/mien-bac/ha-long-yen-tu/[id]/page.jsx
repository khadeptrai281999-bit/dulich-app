"use client";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "Vinpearl Hạ Long",
    stars: 5,
    price: 7600000,
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Vinpearl Hạ Long — resort & khách sạn 5★ cao cấp, view vịnh Hạ Long, tiện nghi quốc tế.",
    mapQuery: "Vinpearl Ha Long"
  },
  {
    id: 2,
    name: "FLC Hạ Long",
    stars: 5,
    price: 6200000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "FLC Ha Long — khu nghỉ dưỡng 5★ với bể bơi và tiện ích hiện đại.",
    mapQuery: "FLC Ha Long"
  },
  {
    id: 3,
    name: "Royal Lotus Hạ Long",
    stars: 4,
    price: 3200000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn 4★ cạnh vịnh, phù hợp du lịch gia đình và đoàn.",
    mapQuery: "Royal Lotus Ha Long"
  },
  {
    id: 4,
    name: "Paradise Suites Hạ Long",
    stars: 5,
    price: 8400000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Paradise Suites — biệt thự & suite cao cấp, dịch vụ 5 sao.",
    mapQuery: "Paradise Suites Ha Long"
  },
  {
    id: 5,
    name: "Novotel Ha Long Bay",
    stars: 4,
    price: 2800000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Novotel — khách sạn quốc tế, tiện nghi hiện đại, phù hợp khách công tác và du lịch.",
    mapQuery: "Novotel Ha Long Bay"
  },
  {
    id: 6,
    name: "Hạ Long Bay Hotel",
    stars: 4,
    price: 2300000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn tiện nghi, giá hợp lý, gần bến tàu Hạ Long.",
    mapQuery: "Halong Bay Hotel"
  },
  {
    id: 7,
    name: "Royal Hạ Long Hotel",
    stars: 5,
    price: 5000000,
    image: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Royal Halong — dịch vụ cao cấp, vị trí trung tâm, phù hợp nghỉ dưỡng sang trọng.",
    mapQuery: "Royal Halong Hotel"
  },
  {
    id: 8,
    name: "Mường Thanh Hạ Long",
    stars: 4,
    price: 2600000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Mường Thanh — chuỗi khách sạn uy tín, tiện nghi đầy đủ.",
    mapQuery: "Muong Thanh Halong"
  },
  {
    id: 9,
    name: "Halong Plaza",
    stars: 4,
    price: 2100000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Halong Plaza — vị trí thuận tiện, gần khu thương mại và bến tàu.",
    mapQuery: "Halong Plaza Hotel"
  },
  {
    id: 10,
    name: "Halong Bay View Resort",
    stars: 5,
    price: 7200000,
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort cao cấp hướng vịnh, phục vụ nghỉ dưỡng hạng sang.",
    mapQuery: "Halong Bay View Resort"
  }
];

export default function HalongDetail() {
  const { id } = useParams();
  const hotel = hotels.find(h => h.id === Number(id));
  const [mainImage, setMainImage] = useState(hotel?.image);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return (
      <div className="p-10 text-center">
        <h2 className="text-2xl font-semibold mb-4">Không tìm thấy khách sạn</h2>
        <Link href="/khach-san/mien-bac/ha-long-yen-tu" className="text-green-700 underline">← Quay lại danh sách</Link>
      </div>
    );
  }

  const calcTotal = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24);
    if (days <= 0) return 0;
    return days * hotel.price * rooms;
  };

  const handleBook = (e) => {
    e.preventDefault();
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng.");
      return;
    }
    alert(`Yêu cầu đặt phòng gửi: ${hotel.name}\nTổng: ${calcTotal().toLocaleString("vi-VN")}đ\n(Trang demo chưa thực hiện thanh toán)`);
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 max-w-5xl mx-auto">
      <Link href="/khach-san/mien-bac/ha-long-yen-tu" className="text-green-700 underline">← Quay lại Hạ Long & Yên Tử</Link>

      <img src={mainImage} alt={hotel.name} className="w-full h-80 object-cover rounded-2xl shadow mb-4 mt-4" />

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {hotel.gallery.map((g,i)=>(
          <div key={i} className="overflow-hidden rounded-xl shadow-sm cursor-pointer" onClick={()=>setMainImage(g)}>
            <img src={g} alt={`${hotel.name} ${i+1}`} className="w-full h-40 object-cover transform hover:scale-105 transition" />
          </div>
        ))}
      </div>

      <h1 className="text-3xl font-bold mb-2 text-green-800">{hotel.name}</h1>
      <p className="text-yellow-500 mb-2">{"★".repeat(hotel.stars)}{"☆".repeat(5-hotel.stars)}</p>
      <p className="text-xl font-semibold mb-4 text-green-700">{hotel.price.toLocaleString("vi-VN")}đ / đêm</p>
      <p className="text-gray-700 mb-6">{hotel.description}</p>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Dịch vụ & Tiện nghi</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          <li>Hồ bơi / Spa</li>
          <li>Nhà hàng & phục vụ 24/7</li>
          <li>Wifi miễn phí</li>
          <li>Đưa đón sân bay (tùy khách sạn)</li>
        </ul>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-6">
        <h2 className="text-lg font-semibold mb-3">Đặt phòng</h2>
        <form className="flex flex-col gap-3" onSubmit={handleBook}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm text-gray-600">Ngày nhận
              <input type="date" value={checkIn} onChange={(e)=>setCheckIn(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/>
            </label>
            <label className="text-sm text-gray-600">Ngày trả
              <input type="date" value={checkOut} onChange={(e)=>setCheckOut(e.target.value)} className="border p-2 rounded-md w-full mt-1" required/>
            </label>
            <label className="text-sm text-gray-600">Số phòng
              <input type="number" min="1" value={rooms} onChange={(e)=>setRooms(Number(e.target.value)||1)} className="border p-2 rounded-md w-full mt-1"/>
            </label>
          </div>

          <div className="flex items-center justify-between mt-3">
            <p className="text-lg font-semibold">Tổng tiền: <span className="text-green-700">{calcTotal().toLocaleString("vi-VN")}đ</span></p>
            <div className="flex gap-3">
              <button type="submit" className="bg-green-700 text-white px-6 py-2 rounded-lg hover:bg-green-800">Đặt ngay</button>
              <Link href="/khach-san/mien-bac/ha-long-yen-tu" className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">Quay lại</Link>
            </div>
          </div>
        </form>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-md mb-10">
        <h2 className="text-lg font-semibold mb-3">Vị trí trên bản đồ</h2>
        <div className="w-full h-72 rounded-xl overflow-hidden border">
          <iframe src={mapSrc} width="100%" height="100%" style={{border:0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>

      <div className="flex justify-between items-center mb-10">
        <Link href="/" className="text-green-700 underline hover:text-green-900">← Về Trang chủ</Link>
        <Link href="/khach-san/mien-bac/ha-long-yen-tu" className="text-green-700 underline hover:text-green-900">← Quay lại Hạ Long & Yên Tử</Link>
      </div>
    </div>
  );
}
