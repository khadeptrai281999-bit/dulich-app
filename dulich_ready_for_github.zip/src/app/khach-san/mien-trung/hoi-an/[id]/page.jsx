"use client";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "Four Seasons Resort The Nam Hai",
    stars: 5,
    price: 12500000,
    image: "https://images.unsplash.com/photo-1551776235-dde6d4829808?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Four Seasons Nam Hai – khu nghỉ dưỡng sang trọng bên bờ biển Hà My, chuẩn 5★ quốc tế.",
    mapQuery: "Four Seasons Resort The Nam Hai Hoi An"
  },
  {
    id: 2,
    name: "Palm Garden Beach Resort & Spa",
    stars: 5,
    price: 4500000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Palm Garden Resort – resort biển Cửa Đại, có hồ bơi lớn và khu spa thư giãn.",
    mapQuery: "Palm Garden Beach Resort Hoi An"
  },
  {
    id: 3,
    name: "La Siesta Resort & Spa Hoi An",
    stars: 5,
    price: 4200000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "La Siesta Resort – khách sạn boutique nổi tiếng tại Hội An, không gian yên tĩnh và sang trọng.",
    mapQuery: "La Siesta Resort and Spa Hoi An"
  },
  {
    id: 4,
    name: "Victoria Hoi An Beach Resort & Spa",
    stars: 4,
    price: 3600000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Victoria Hoi An – resort phong cách làng chài ven biển, có hồ bơi hướng biển tuyệt đẹp.",
    mapQuery: "Victoria Hoi An Beach Resort & Spa"
  },
  {
    id: 5,
    name: "Sunrise Premium Resort Hoi An",
    stars: 5,
    price: 4800000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Sunrise Premium – view biển Cửa Đại, dịch vụ cao cấp, nhà hàng ẩm thực quốc tế.",
    mapQuery: "Sunrise Premium Resort Hoi An"
  },
  {
    id: 6,
    name: "Almanity Hoi An Resort & Spa",
    stars: 4,
    price: 3400000,
    image: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Almanity – resort spa nghỉ dưỡng giữa lòng phố cổ, có hồ bơi trung tâm lớn.",
    mapQuery: "Almanity Hoi An Resort & Spa"
  },
  {
    id: 7,
    name: "Silk Sense Hoi An River Resort",
    stars: 5,
    price: 3900000,
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Silk Sense – resort bên sông Cổ Cò, nổi bật với khu spa thiên nhiên và nhà hàng organic.",
    mapQuery: "Silk Sense Hoi An River Resort"
  },
  {
    id: 8,
    name: "Belle Maison Hadana Hoi An Resort & Spa",
    stars: 4,
    price: 2800000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Belle Maison – khách sạn 4★ trung tâm, kiến trúc hiện đại và dịch vụ thân thiện.",
    mapQuery: "Belle Maison Hadana Hoi An Resort & Spa"
  },
  {
    id: 9,
    name: "Hoi An Beach Resort",
    stars: 4,
    price: 3000000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort giữa sông Đế Võng và biển Cửa Đại, view đẹp, phù hợp nghỉ dưỡng gia đình.",
    mapQuery: "Hoi An Beach Resort"
  },
  {
    id: 10,
    name: "Lantana Riverside Hoi An Boutique Hotel",
    stars: 4,
    price: 2500000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn boutique bên sông Thu Bồn, không gian thanh bình và gần phố cổ.",
    mapQuery: "Lantana Riverside Hoi An Boutique Hotel"
  }
];

export default function HoiAnHotelDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels.find((h) => h.id === parseInt(id));

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return <div className="p-10 text-center text-gray-700">Không tìm thấy khách sạn.</div>;
  }

  const totalPrice = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 3600 * 24);
    return days > 0 ? hotel.price * rooms * days : 0;
  };

  const handleBooking = () => {
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng!");
      return;
    }
    alert(
      `✅ Đặt phòng thành công!\n${hotel.name}\nTừ ${checkIn} đến ${checkOut}\nSố phòng: ${rooms}\nTổng tiền: ${totalPrice().toLocaleString("vi-VN")} VNĐ`
    );
  };

  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <button
        onClick={() => router.back()}
        className="mb-6 bg-gray-300 hover:bg-gray-400 px-4 py-2 rounded-lg text-sm"
      >
        ← Quay lại
      </button>

      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden">
        <img src={hotel.image} alt={hotel.name} className="w-full h-96 object-cover" />
        <div className="p-6">
          <h1 className="text-3xl font-bold text-green-800 mb-2">{hotel.name}</h1>
          <p className="text-yellow-500 mb-3">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
          <p className="text-gray-700 mb-4">{hotel.description}</p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            {hotel.gallery.map((img, i) => (
              <img key={i} src={img} className="w-full h-40 object-cover rounded-lg" />
            ))}
          </div>

          <div className="border-t pt-4 mt-4">
            <h2 className="font-semibold text-lg mb-3">Đặt phòng</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-3">
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="number"
                min="1"
                value={rooms}
                onChange={(e) => setRooms(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
            </div>
            <p className="text-gray-700 mb-3">
              💰 Tổng tiền:{" "}
              <span className="font-bold text-green-700">
                {totalPrice().toLocaleString("vi-VN")} VNĐ
              </span>
            </p>
            <button
              onClick={handleBooking}
              className="bg-green-700 hover:bg-green-800 text-white px-6 py-2 rounded-lg transition"
            >
              Đặt ngay
            </button>
          </div>

          <div className="mt-8">
            <h2 className="font-semibold text-lg mb-3">📍 Bản đồ</h2>
            <iframe
              src={`https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`}
              className="w-full h-80 rounded-xl"
              allowFullScreen
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
}
