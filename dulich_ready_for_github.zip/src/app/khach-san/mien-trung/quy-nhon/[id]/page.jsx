"use client";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";

const hotels = [
  {
    id: 1,
    name: "FLC Luxury Resort Quy Nhơn",
    stars: 5,
    price: 6200000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort 5★ ven biển Nhơn Lý, có sân golf và tiện ích đẳng cấp quốc tế.",
    mapQuery: "FLC Luxury Resort Quy Nhon"
  },
  {
    id: 2,
    name: "Anya Premier Hotel Quy Nhơn",
    stars: 5,
    price: 4300000,
    image: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn 5★ trung tâm thành phố Quy Nhơn, hướng biển, hiện đại và sang trọng.",
    mapQuery: "Anya Premier Hotel Quy Nhon"
  },
  {
    id: 3,
    name: "Seaside Boutique Resort Quy Nhơn",
    stars: 4,
    price: 2800000,
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort nhỏ bên bãi biển Nhơn Hải, phong cách tinh tế và yên bình.",
    mapQuery: "Seaside Boutique Resort Quy Nhon"
  },
  {
    id: 4,
    name: "Maia Resort Quy Nhơn",
    stars: 5,
    price: 5600000,
    image: "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Maia Resort thuộc Fusion Group, nổi tiếng với ẩm thực và spa thư giãn cao cấp.",
    mapQuery: "Maia Resort Quy Nhon"
  },
  {
    id: 5,
    name: "Mường Thanh Luxury Quy Nhơn",
    stars: 4,
    price: 2500000,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn 4★ trung tâm, view biển, nổi bật với hồ bơi ngoài trời lớn.",
    mapQuery: "Muong Thanh Luxury Quy Nhon"
  },
  {
    id: 6,
    name: "Casa Marina Resort",
    stars: 4,
    price: 3100000,
    image: "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort yên tĩnh gần biển Ghềnh Ráng, phù hợp nghỉ dưỡng gia đình.",
    mapQuery: "Casa Marina Resort Quy Nhon"
  },
  {
    id: 7,
    name: "Fleur de Lys Quy Nhơn",
    stars: 5,
    price: 4000000,
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1505691723518-34f6b0f6f2d1?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn 5★ phong cách Pháp hiện đại, nằm ngay trung tâm Quy Nhơn.",
    mapQuery: "Fleur de Lys Quy Nhon"
  },
  {
    id: 8,
    name: "Avani Quy Nhơn Resort",
    stars: 5,
    price: 5200000,
    image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort 5★ của Minor Group, nổi bật với bãi tắm riêng và spa ven biển.",
    mapQuery: "Avani Quy Nhon Resort"
  },
  {
    id: 9,
    name: "Crown Retreat Quy Nhơn",
    stars: 4,
    price: 3000000,
    image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Resort hướng biển, kiến trúc thanh lịch, dịch vụ chuẩn quốc tế.",
    mapQuery: "Crown Retreat Quy Nhon"
  },
  {
    id: 10,
    name: "Royal Hotel & Healthcare Resort",
    stars: 4,
    price: 2700000,
    image: "https://images.unsplash.com/photo-1544074780-3b5b2f1d3b19?auto=format&fit=crop&w=1600&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1501117716987-c8e1ecb2101f?auto=format&fit=crop&w=1200&q=80"
    ],
    description: "Khách sạn ven biển với khu spa chăm sóc sức khỏe chuyên biệt.",
    mapQuery: "Royal Hotel and Healthcare Resort Quy Nhon"
  }
];

export default function QuyNhonHotelDetail() {
  const { id } = useParams();
  const router = useRouter();
  const hotel = hotels.find((h) => h.id === parseInt(id));

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [rooms, setRooms] = useState(1);

  if (!hotel) {
    return <div className="p-10 text-center text-gray-700">Không tìm thấy khách sạn.</div>;
  }

  const totalPrice = () => {
    if (!checkIn || !checkOut) return 0;
    const days = (new Date(checkOut) - new Date(checkIn)) / (1000 * 3600 * 24);
    return days > 0 ? hotel.price * rooms * days : 0;
  };

  const handleBooking = () => {
    if (!checkIn || !checkOut) {
      alert("Vui lòng chọn ngày nhận và trả phòng!");
      return;
    }
    alert(
      `✅ Đặt phòng thành công!\n${hotel.name}\nTừ ${checkIn} đến ${checkOut}\nSố phòng: ${rooms}\nTổng tiền: ${totalPrice().toLocaleString("vi-VN")} VNĐ`
    );
  };

  return (
    <div className="p-10 bg-gray-100 min-h-screen">
      <button
        onClick={() => router.back()}
        className="mb-6 bg-gray-300 hover:bg-gray-400 px-4 py-2 rounded-lg text-sm"
      >
        ← Quay lại
      </button>

      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden">
        <img src={hotel.image} alt={hotel.name} className="w-full h-96 object-cover" />
        <div className="p-6">
          <h1 className="text-3xl font-bold text-green-800 mb-2">{hotel.name}</h1>
          <p className="text-yellow-500 mb-3">{"★".repeat(hotel.stars)}{"☆".repeat(5 - hotel.stars)}</p>
          <p className="text-gray-700 mb-4">{hotel.description}</p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            {hotel.gallery.map((img, i) => (
              <img key={i} src={img} className="w-full h-40 object-cover rounded-lg" />
            ))}
          </div>

          <div className="border-t pt-4 mt-4">
            <h2 className="font-semibold text-lg mb-3">Đặt phòng</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-3">
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
              <input
                type="number"
                min="1"
                value={rooms}
                onChange={(e) => setRooms(e.target.value)}
                className="border p-2 rounded-lg w-full"
              />
            </div>
            <p className="text-gray-700 mb-3">
              💰 Tổng tiền:{" "}
              <span className="font-bold text-green-700">
                {totalPrice().toLocaleString("vi-VN")} VNĐ
              </span>
            </p>
            <button
              onClick={handleBooking}
              className="bg-green-700 hover:bg-green-800 text-white px-6 py-2 rounded-lg transition"
            >
              Đặt ngay
            </button>
          </div>

          <div className="mt-8">
            <h2 className="font-semibold text-lg mb-3">📍 Bản đồ</h2>
            <iframe
              src={`https://www.google.com/maps?q=${encodeURIComponent(hotel.mapQuery)}&output=embed`}
              className="w-full h-80 rounded-xl"
              allowFullScreen
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
}
