"use client";
import { useState } from "react";

export default function YCaoCap() {
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);
  const price = 84000000;
  const total = price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: Tour Ý cao cấp\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">Tour Ý cao cấp</h1>
      <img
        src="https://bazantravel.com/cdn/medias/uploads/29/29817-du-lich-y-italia.jpg"
        alt="Tour Ý cao cấp"
        className="w-full h-96 object-cover rounded-2xl shadow mb-6"
      />
      <p><strong>Giá tour:</strong> {price.toLocaleString()}₫</p>
      <p className="text-gray-700 mb-6">
        Hành trình qua Venice, Rome, Milan – đất nước của nghệ thuật, thời trang và ẩm thực tinh tế.
      </p>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Tham quan Đấu trường La Mã – Colosseum</li>
          <li>Dạo thuyền trên kênh đào Venice</li>
          <li>Thưởng thức pizza và pasta chính gốc Ý</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Lưu ý</h2>
        <p>Chuẩn bị giày thể thao, nhiều điểm tham quan phải đi bộ.</p>
      </section>

      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div><label className="block mb-1">Ngày khởi hành:</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></div>
          <div><label className="block mb-1">Số người:</label><input type="number" min="1" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2" /></div>
          <div className="flex flex-col justify-end"><p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p></div>
        </div>
        <button onClick={handleBooking} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">Thanh toán ngay</button>
      </section>
    </div>
  );
}
