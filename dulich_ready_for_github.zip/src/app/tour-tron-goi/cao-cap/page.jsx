"use client";
import Link from "next/link";

export default function TourCaoCap() {
  const tours = [
    {
      id: "my-cao-cap", // thêm id
      title: "Tour Mỹ cao cấp",
      image: "https://dulichviet.com.vn/images/bandidau/du-lich-my-1.jpg",
      description: "Khám phá nước Mỹ hiện đại và tráng lệ.",
      price: "89.000.000₫",
    },
    {
      id: "han-quoc-cao-cap",
      title: "Tour Hàn Quốc cao cấp",
      image: "https://ik.imagekit.io/tvlk/blog/2022/11/dia-diem-du-lich-han-quoc-1.jpg?tr=dpr-2,w-675",
      description: "Hành trình Seoul - Nami - Busan đầy màu sắc.",
      price: "45.000.000₫",
    },
    {
      id: "nhat-ban-cao-cap",
      title: "Tour Nhật Bản cao cấp",
      image: "https://datviettour.com.vn/uploads/images/tin-tuc/Tin-mo-ta-danh-muc-tour/nhat-ban/nhat-ban-1.jpg",
      description: "Trải nghiệm Tokyo, Osaka và núi Phú Sĩ tuyệt đẹp.",
      price: "65.000.000₫",
    },
    {
      id: "dubai-cao-cap",
      title: "Tour Dubai cao cấp",
      image: "https://www.timeoutdubai.com/cloud/timeoutdubai/2021/09/10/wORipIir-Burj-Khalifa.jpg",
      description: "Khám phá thiên đường xa hoa Trung Đông.",
      price: "72.000.000₫",
    },
    {
      id: "phap-cao-cap",
      title: "Tour Pháp cao cấp",
      image: "https://s1.1zoom.me/big3/487/Sky_Evening_France_Eiffel_Tower_Paris_From_above_520603_5416x3611.jpg",
      description: "Lãng mạn Paris, Lyon, Nice, và tháp Eiffel.",
      price: "79.000.000₫",
    },
    {
      id: "y-cao-cap",
      title: "Tour Ý cao cấp",
      image: "https://bazantravel.com/cdn/medias/uploads/29/29817-du-lich-y-italia.jpg",
      description: "Khám phá Venice, Rome và Milan cổ kính.",
      price: "84.000.000₫",
    },
  ];

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-emerald-800 mb-6">
        Tour cao cấp quốc tế
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tours.map((tour, index) => (
          <div
            key={index}
            className="border rounded-lg shadow hover:shadow-lg overflow-hidden bg-white transition"
          >
            <img
              src={tour.image}
              alt={tour.title}
              className="w-full h-52 object-cover"
            />
            <div className="p-4">
              <h2 className="text-lg font-semibold text-emerald-700">
                {tour.title}
              </h2>
              <p className="text-gray-600 text-sm my-2">{tour.description}</p>
              <p className="text-red-600 font-bold">{tour.price}</p>

              {/* Thay button bằng Link */}
              <Link href={`/tour-tron-goi/cao-cap/${tour.id}`}>
                <button className="mt-3 bg-emerald-600 text-white px-4 py-2 rounded hover:bg-emerald-700">
                  Xem chi tiết
                </button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
