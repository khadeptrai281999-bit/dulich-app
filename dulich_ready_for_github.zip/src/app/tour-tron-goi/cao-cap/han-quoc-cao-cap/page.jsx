"use client";
import { useState } from "react";

export default function HanQuocCaoCap() {
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);
  const price = 45000000;
  const total = price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: Tour Hàn Quốc cao cấp\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">Tour Hàn Quốc cao cấp</h1>
      <img
        src="https://ik.imagekit.io/tvlk/blog/2022/11/dia-diem-du-lich-han-quoc-1.jpg?tr=dpr-2,w-675"
        alt="Tour Hàn Quốc cao cấp"
        className="w-full h-96 object-cover rounded-2xl shadow mb-6"
      />

      <p className="text-lg mb-2"><strong>Giá tour:</strong> {price.toLocaleString()}₫</p>
      <p className="mb-6 text-gray-700">
        Hành trình Seoul – Nami – Busan với phong cảnh tuyệt đẹp và ẩm thực đặc trưng.
      </p>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">🧭 Thông tin thêm</h2>
        <p>Tour bao gồm vé máy bay khứ hồi, khách sạn 4 sao, hướng dẫn viên nói tiếng Việt, vé tham quan, ăn uống đầy đủ.</p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Check-in đảo Nami nổi tiếng</li>
          <li>Trải nghiệm mặc Hanbok tại Gyeongbokgung</li>
          <li>Thưởng thức ẩm thực Busan ven biển</li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">📅 Lịch trình</h2>
        <ul className="list-decimal list-inside space-y-1">
          <li>Ngày 1: Đến Seoul - tự do tham quan</li>
          <li>Ngày 2: Tham quan đảo Nami</li>
          <li>Ngày 3: Di chuyển Busan - tham quan chợ Jagalchi</li>
          <li>Ngày 4: Mua sắm tại Myeongdong</li>
          <li>Ngày 5: Trở về Việt Nam</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Lưu ý</h2>
        <p>Mang theo áo ấm nếu đi mùa đông. Hộ chiếu còn hạn ít nhất 6 tháng.</p>
      </section>

      {/* FORM ĐẶT TOUR */}
      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block font-medium mb-1">Ngày khởi hành:</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block font-medium mb-1">Số người:</label>
            <input type="number" min="1" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div className="flex flex-col justify-end">
            <p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p>
          </div>
        </div>
        <button onClick={handleBooking} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">
          Thanh toán ngay
        </button>
      </section>
    </div>
  );
}
