"use client";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

const tours = [
  {
    id: "my-cao-cap",
    title: "Tour Mỹ cao cấp",
    price: 89000000,
    image: "https://statue-of-liberty.jpg",
    description: "Khám phá nước Mỹ hiện đại và tráng lệ.",
    highlights: [
      "Tham quan Tượng Nữ thần Tự do, Nhà Trắng, Times Square",
      "Trải nghiệm Las Vegas rực rỡ ánh đèn",
      "Mua sắm tại Beverly Hills và outlet cao cấp"
    ],
    itinerary: [
      { day: 1, detail: "Khởi hành từ Hà Nội - Đến New York" },
      { day: 2, detail: "Tham quan New York" },
      { day: 3, detail: "Bay đến Washington D.C." },
      { day: 4, detail: "Khám phá Las Vegas" },
      { day: 5, detail: "Trở về Việt Nam" }
    ],
    note: "Giá tour có thể thay đổi tùy theo thời điểm và tình trạng vé máy bay."
  },
  {
    id: "han-quoc-cao-cap",
    title: "Tour Hàn Quốc cao cấp",
    price: 45000000,
    image: "https://korea-tour.jpg",
    description: "Hành trình Seoul - Nami - Busan đầy màu sắc.",
    highlights: [
      "Check-in đảo Nami nổi tiếng",
      "Trải nghiệm Hanbok tại Gyeongbokgung",
      "Thưởng thức ẩm thực Busan ven biển"
    ],
    itinerary: [
      { day: 1, detail: "Đến Seoul - Tự do tham quan" },
      { day: 2, detail: "Tham quan đảo Nami" },
      { day: 3, detail: "Di chuyển Busan - Tự do khám phá" },
      { day: 4, detail: "Mua sắm tại Myeongdong" },
      { day: 5, detail: "Về nước" }
    ],
    note: "Mang theo áo ấm nếu đi vào mùa đông."
  }
];

export default function TourDetail() {
  const { id } = useParams();
  const [tour, setTour] = useState(null);
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);

  useEffect(() => {
    const found = tours.find(t => t.id === id);
    setTour(found);
  }, [id]);

  if (!tour) return <div className="p-10 text-center text-lg">Đang tải thông tin tour...</div>;

  const total = tour.price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: ${tour.title}\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">{tour.title}</h1>
      <img src={tour.image} alt={tour.title} className="w-full h-96 object-cover rounded-2xl shadow mb-6" />

      <p className="text-lg mb-2"><strong>Giá tour:</strong> {tour.price.toLocaleString()}₫</p>
      <p className="mb-6 text-gray-700">{tour.description}</p>

      {/* Thông tin thêm */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">🧭 Thông tin thêm về chuyến đi</h2>
        <p>Tour bao gồm vé máy bay khứ hồi, khách sạn 4-5 sao, hướng dẫn viên suốt tuyến, bảo hiểm du lịch, ăn uống theo chương trình.</p>
      </section>

      {/* Điểm nhấn */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn của chương trình</h2>
        <ul className="list-disc list-inside space-y-1">
          {tour.highlights.map((h, i) => <li key={i}>{h}</li>)}
        </ul>
      </section>

      {/* Lịch trình */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">📅 Lịch trình chi tiết</h2>
        <ul className="list-decimal list-inside space-y-1">
          {tour.itinerary.map((d, i) => (
            <li key={i}>Ngày {d.day}: {d.detail}</li>
          ))}
        </ul>
      </section>

      {/* Thông tin cần lưu ý */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Những thông tin cần lưu ý</h2>
        <p>{tour.note}</p>
      </section>

      {/* FORM ĐẶT TOUR */}
      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>

        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block font-medium mb-1">Ngày khởi hành:</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="block font-medium mb-1">Số người:</label>
            <input
              type="number"
              min="1"
              value={people}
              onChange={(e) => setPeople(Number(e.target.value))}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          <div className="flex flex-col justify-end">
            <p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p>
          </div>
        </div>

        <button
          onClick={handleBooking}
          className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition"
        >
          Thanh toán ngay
        </button>
      </section>
    </div>
  );
}
