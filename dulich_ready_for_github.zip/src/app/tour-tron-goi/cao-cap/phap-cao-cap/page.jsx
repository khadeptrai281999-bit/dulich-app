"use client";
import { useState } from "react";

export default function PhapCaoCap() {
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(1);
  const price = 79000000;
  const total = price * people;

  const handleBooking = () => {
    alert(`Đặt tour thành công!\nTour: Tour Pháp cao cấp\nNgày đi: ${date}\nSố người: ${people}\nTổng tiền: ${total.toLocaleString()}₫`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-green-700 mb-4">Tour Pháp cao cấp</h1>
      <img
        src="https://s1.1zoom.me/big3/487/Sky_Evening_France_Eiffel_Tower_Paris_From_above_520603_5416x3611.jpg"
        alt="Tour Pháp cao cấp"
        className="w-full h-96 object-cover rounded-2xl shadow mb-6"
      />
      <p><strong>Giá tour:</strong> {price.toLocaleString()}₫</p>
      <p className="text-gray-700 mb-6">
        Khám phá Paris, Lyon, Nice – thành phố ánh sáng và văn hóa lãng mạn bậc nhất châu Âu.
      </p>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⭐ Điểm nhấn</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Tham quan Tháp Eiffel và Bảo tàng Louvre</li>
          <li>Trải nghiệm ẩm thực Pháp tinh tế</li>
          <li>Khám phá vùng rượu vang Bordeaux</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-green-700 mb-3">⚠️ Lưu ý</h2>
        <p>Nhiệt độ lạnh hơn so với Việt Nam, nên chuẩn bị áo khoác dày.</p>
      </section>

      <section className="border-t pt-6 mt-6">
        <h2 className="text-2xl font-semibold text-green-700 mb-4">📝 Đặt tour ngay</h2>
        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div><label className="block mb-1">Ngày khởi hành:</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full border rounded-lg px-3 py-2" /></div>
          <div><label className="block mb-1">Số người:</label><input type="number" min="1" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full border rounded-lg px-3 py-2" /></div>
          <div className="flex flex-col justify-end"><p className="font-semibold text-lg text-green-700">Tổng tiền: {total.toLocaleString()}₫</p></div>
        </div>
        <button onClick={handleBooking} className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">Thanh toán ngay</button>
      </section>
    </div>
  );
}
