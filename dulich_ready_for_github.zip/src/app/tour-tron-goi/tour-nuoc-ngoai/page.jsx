"use client";
import TourCard from "@/components/TourCard";

export default function HomePage() {
  const tours = [
    {
      id: "ha-long-yen-tu",
      title: "Hạ Long - Yên Tử",
      desc: "Khám phá Vịnh Hạ Long và Yên Tử linh thiêng",
      price: 2500000,
      image: "https://statics.vinpearl.com/ha-long-1_1683629173.jpg",
    },
    {
      id: "sapa-lao-cai",
      title: "Sapa - Lào Cai",
      desc: "Trải nghiệm cảnh sắc vùng núi phía Bắc",
      price: 3000000,
      image: "https://statics.vinpearl.com/sapa-1_1683629181.jpg",
    },
    {
      id: "hue",
      title: "Huế",
      desc: "Hành trình cố đô Huế mộng mơ",
      price: 2200000,
      image: "https://statics.vinpearl.com/hue-1_1683629202.jpg",
    },
    {
      id: "quang-binh",
      title: "Quảng Bình",
      desc: "Khám phá động Phong Nha – Kẻ Bàng",
      price: 2700000,
      image: "https://statics.vinpearl.com/quang-binh-1_1683629193.jpg",
    },
    {
      id: "da-lat",
      title: "Đà Lạt",
      desc: "Thành phố ngàn hoa lãng mạn",
      price: 2100000,
      image: "https://statics.vinpearl.com/da-lat-1_1683629212.jpg",
    },
    {
      id: "da-nang",
      title: "Đà Nẵng",
      desc: "Khám phá thành phố biển miền Trung",
      price: 2400000,
      image: "https://statics.vinpearl.com/da-nang-1_1683629223.jpg",
    },
    {
      id: "hoi-an",
      title: "Hội An",
      desc: "Thành phố cổ yên bình và thơ mộng",
      price: 2000000,
      image: "https://statics.vinpearl.com/hoi-an-1_1683629244.jpg",
    },
    {
      id: "mui-ne-ke-ga",
      title: "Mũi Né - Kê Gà",
      desc: "Khám phá đồi cát vàng và biển xanh Bình Thuận",
      price: 2300000,
      image: "https://statics.vinpearl.com/mui-ne-1_1683629253.jpg",
    },
    {
      id: "nha-trang",
      title: "Nha Trang",
      desc: "Khám phá thiên đường biển đảo miền Trung",
      price: 2600000,
      image: "https://statics.vinpearl.com/nha-trang-1_1683629261.jpg",
    },
    {
      id: "quy-nhon",
      title: "Quy Nhơn",
      desc: "Thành phố biển yên bình với cảnh sắc hoang sơ",
      price: 2500000,
      image: "https://statics.vinpearl.com/quy-nhon-1_1683629271.jpg",
    },
    {
      id: "phu-quoc",
      title: "Phú Quốc",
      desc: "Đảo ngọc xinh đẹp giữa biển khơi",
      price: 3200000,
      image: "https://statics.vinpearl.com/phu-quoc-1_1683629280.jpg",
    },
    {
      id: "vung-tau-ho-tram",
      title: "Vũng Tàu - Hồ Tràm",
      desc: "Tận hưởng không gian biển gần Sài Gòn",
      price: 2100000,
      image: "https://statics.vinpearl.com/vung-tau-1_1683629291.jpg",
    },
  ];

  return (
    <main className="p-8">
      {/* Banner */}
      <div className="mb-6">
        <img
          src="https://dulichviet.com.vn/images/bandidau/banner-du-lich-viet.jpg"
          alt="Banner"
          className="w-full h-64 object-cover rounded-lg"
        />
      </div>

      {/* Tìm kiếm */}
      <div className="flex items-center gap-2 mb-10">
        <input
          type="text"
          placeholder="Tìm kiếm khách sạn, tour du lịch..."
          className="flex-1 border p-3 rounded-lg"
        />
        <select className="border p-3 rounded-lg">
          <option>Chọn địa điểm</option>
          <option>Miền Bắc</option>
          <option>Miền Trung</option>
          <option>Miền Nam</option>
        </select>
        <button className="bg-green-700 text-white px-6 py-3 rounded-lg hover:bg-green-800 transition">
          Tìm kiếm
        </button>
      </div>

      {/* Danh sách tour */}
      <h2 className="text-2xl font-bold text-green-700 mb-6">
        Điểm đến nổi bật
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {tours.map((tour) => (
          <TourCard key={tour.id} tour={tour} />
        ))}
      </div>
    </main>
  );
}
