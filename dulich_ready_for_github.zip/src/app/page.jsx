"use client";
import { motion, AnimatePresence, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { usePathname } from "next/navigation";
import Image from "next/image";
import SearchBox from "@/components/SearchBox";
import TourCard from "@/components/TourCard";

export default function HomePage() {
  const pathname = usePathname();
  const ref = useRef(null);
  const { scrollY } = useScroll();

  // 🎬 Hiệu ứng fade-out + parallax cho banner
  const y = useTransform(scrollY, [0, 300], ["0%", "20%"]);
  const opacity = useTransform(scrollY, [0, 200], [1, 0]);

  const tours = [
    {
      id: "ha-long-yen-tu",
      title: "Hạ Long - Yên Tử",
      desc: "Khám phá Vịnh Hạ Long và Yên Tử linh thiêng, nơi giao hòa giữa biển trời và núi non hùng vĩ.",
      image:
        "https://images2.thanhnien.vn/528068263637045248/2023/6/24/img4099-16875776586881216884140.jpg",
      price: 2500000,
    },
    {
      id: "sapa-lao-cai",
      title: "Sapa - Lào Cai",
      desc: "Trải nghiệm không khí se lạnh vùng cao, săn mây và khám phá bản làng Tây Bắc.",
      image:
        "https://images2.thanhnien.vn/528068263637045248/2023/3/16/fansipan-nguyen-minh-tu-16789627882291461203793.jpg",
      price: 3000000,
    },
    {
      id: "hue",
      title: "Huế",
      desc: "Hành trình về cố đô, thăm Đại Nội, chùa Thiên Mụ và thưởng thức ẩm thực cung đình.",
      image:
        "https://duyendangvietnam.net.vn/public/uploads/file1s/Tu-Cam-Thanh-8609-1650366421.jpg",
      price: 2200000,
    },
    {
      id: "da-nang",
      title: "Đà Nẵng",
      desc: "Thành phố đáng sống nhất Việt Nam với Bà Nà Hills, cầu Rồng và biển Mỹ Khê tuyệt đẹp.",
      image:
        "https://res.klook.com/image/upload/activities/w4ptixl2qvdfkmotth7j.jpg",
      price: 2400000,
    },
    {
      id: "hoi-an",
      title: "Hội An",
      desc: "Thành phố cổ yên bình và thơ mộng bên dòng sông Hoài.",
      image:
        "https://toquoc.mediacdn.vn/280518851207290880/2021/4/27/ngo-ngang-voi-ve-dep-pho-co-hoi-an-nhin-tu-tren-cao-24-16195044602511646130988.jpg",
      price: 2000000,
    },
    {
      id: "phu-quoc",
      title: "Phú Quốc",
      desc: "Đảo ngọc xinh đẹp giữa biển khơi, thiên đường nghỉ dưỡng hàng đầu Việt Nam.",
      image:
        "https://vietuctourist.vn/wp-content/uploads/2021/06/phu-quoc-dao-ngoc.jpg",
      price: 3200000,
    },
  ];

  return (
    <AnimatePresence mode="wait">
      <motion.main
        key={pathname}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.7 }}
        className="flex flex-col"
      >
        {/* 🏞 Banner parallax + fade-out */}
        <section ref={ref} className="relative w-full h-[500px] overflow-hidden">
          <motion.div
            className="absolute w-full h-full"
            style={{ y, opacity }}
            transition={{ duration: 1.2 }}
          >
            <Image
              src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
              alt="Banner du lịch Việt Nam"
              fill
              className="object-cover"
              priority
              unoptimized
            />
          </motion.div>

          {/* Overlay + text */}
          <motion.div
            className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white text-center"
            style={{ opacity }}
          >
            <motion.h1
              className="text-4xl font-bold mb-3 drop-shadow-lg"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
            >
              Khám phá Việt Nam - Vẻ đẹp bất tận
            </motion.h1>
            <motion.p
              className="text-lg max-w-2xl mx-auto"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.6 }}
            >
              Cùng VietTravel tận hưởng những hành trình tuyệt đẹp khắp mọi miền đất nước.
            </motion.p>
          </motion.div>
        </section>

        {/* 🔍 Thanh tìm kiếm */}
        <section className="max-w-5xl mx-auto mt-[-40px] z-10 relative px-6">
          <div className="bg-white rounded-xl shadow-lg p-4">
            <SearchBox />
          </div>
        </section>

        {/* 🌿 Giới thiệu */}
        <section className="py-16 bg-gray-50 text-center px-6">
          <motion.h2
            className="text-3xl font-bold text-green-700 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            Du lịch trong nước - Trải nghiệm tuyệt vời
          </motion.h2>
          <motion.p
            className="text-gray-600 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Cùng chúng tôi khám phá những địa điểm nổi tiếng, thưởng thức ẩm thực đặc trưng
            và hòa mình vào vẻ đẹp thiên nhiên của đất nước Việt Nam. Mỗi hành trình là một
            trải nghiệm đáng nhớ dành cho bạn và gia đình.
          </motion.p>
        </section>

        {/* 🧭 Tour nổi bật (hiệu ứng fade-in + scale-up) */}
        <section className="max-w-6xl mx-auto px-6 py-12">
          <h2 className="text-2xl font-bold text-green-700 mb-6">Điểm đến nổi bật</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {tours.map((tour, i) => (
              <motion.div
                key={tour.id}
                initial={{ opacity: 0, scale: 0.9, y: 30 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                transition={{
                  duration: 0.6,
                  delay: i * 0.1,
                  ease: "easeOut",
                }}
                viewport={{ once: true }}
              >
                <TourCard tour={tour} />
              </motion.div>
            ))}
          </div>
        </section>

        {/* 💚 Lý do chọn */}
        <section className="py-16 bg-green-50 text-center">
          <h2 className="text-3xl font-bold text-green-700 mb-4">Vì sao chọn chúng tôi?</h2>
          <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-8 px-6">
            {[
              {
                img: "https://cdn-icons-png.flaticon.com/512/5971/5971832.png",
                title: "Uy tín hàng đầu",
                text: "Được hàng ngàn khách hàng tin tưởng và lựa chọn mỗi năm.",
              },
              {
                img: "https://cdn-icons-png.flaticon.com/512/3212/3212561.png",
                title: "Giá tốt nhất",
                text: "Cam kết giá cạnh tranh, dịch vụ chất lượng cao.",
              },
              {
                img: "https://cdn-icons-png.flaticon.com/512/2112/2112052.png",
                title: "Hỗ trợ 24/7",
                text: "Luôn sẵn sàng hỗ trợ khách hàng trong suốt hành trình.",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                className="p-4 bg-white rounded-xl shadow hover:shadow-lg transition"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
              >
                <Image
                  src={item.img}
                  alt={item.title}
                  width={64}
                  height={64}
                  className="mx-auto mb-4"
                  unoptimized
                />
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 🦶 Footer */}
        <footer className="bg-green-700 text-white py-8 text-center mt-8">
          <p>© 2025 VietTravel. All rights reserved.</p>
        </footer>
      </motion.main>
    </AnimatePresence>
  );
}
