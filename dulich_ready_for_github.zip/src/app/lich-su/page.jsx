"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminLichSu() {
  const [orders, setOrders] = useState([]);
  const [search, setSearch] = useState("");
  const [isAuth, setIsAuth] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const auth = localStorage.getItem("adminAuth");
    if (auth === "true") {
      setIsAuth(true);
      const data = JSON.parse(localStorage.getItem("orders") || "[]");
      setOrders(data.reverse());
    } else {
      router.push("/admin/login");
    }
  }, []);

  if (!isAuth) return null;

  const handleDelete = (id) => {
    if (confirm(`Xoá đơn hàng #${id}?`)) {
      const updated = orders.filter((o) => o.id !== id);
      setOrders(updated);
      localStorage.setItem("orders", JSON.stringify(updated));
    }
  };

  const handleClearAll = () => {
    if (confirm("Bạn có chắc muốn xoá toàn bộ đơn hàng?")) {
      setOrders([]);
      localStorage.removeItem("orders");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    router.push("/admin/login");
  };

  const filtered = orders.filter(
    (o) =>
      o.name.toLowerCase().includes(search.toLowerCase()) ||
      o.id.toString().includes(search)
  );

  return (
    <div className="max-w-6xl mx-auto py-10 px-4">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-green-800">
          👨‍💼 Quản trị - Lịch sử đặt phòng
        </h1>
        <div className="flex flex-wrap gap-3 mt-4 md:mt-0">
          <button
            onClick={handleLogout}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-800"
          >
            Đăng xuất
          </button>
          <Link
            href="/khach-san/ha-noi"
            className="bg-green-700 text-white px-4 py-2 rounded-lg hover:bg-green-800"
          >
            ← Quay lại khách sạn
          </Link>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl shadow mb-6 flex flex-col md:flex-row justify-between gap-4">
        <input
          type="text"
          placeholder="Tìm theo mã hoặc tên khách hàng..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border p-2 rounded-lg flex-1"
        />
        <button
          onClick={handleClearAll}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          Xoá toàn bộ
        </button>
      </div>

      {filtered.length === 0 ? (
        <p className="text-center text-gray-600 mt-10">
          Không có đơn hàng nào phù hợp.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-green-700 text-white">
                <th className="border px-4 py-2">Mã</th>
                <th className="border px-4 py-2">Khách hàng</th>
                <th className="border px-4 py-2">Khách sạn</th>
                <th className="border px-4 py-2">Tổng tiền</th>
                <th className="border px-4 py-2">Thanh toán</th>
                <th className="border px-4 py-2">Ngày</th>
                <th className="border px-4 py-2">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o.id} className="hover:bg-gray-50">
                  <td className="border px-4 py-2 text-center text-green-700 font-semibold">
                    #{o.id}
                  </td>
                  <td className="border px-4 py-2">
                    {o.name} <br />
                    <span className="text-sm text-gray-500">{o.phone}</span>
                  </td>
                  <td className="border px-4 py-2">{o.hotel}</td>
                  <td className="border px-4 py-2 text-green-700 font-semibold">
                    {o.price}đ
                  </td>
                  <td className="border px-4 py-2">{o.method}</td>
                  <td className="border px-4 py-2 text-sm text-gray-500">
                    {o.date}
                  </td>
                  <td className="border px-4 py-2 text-center">
                    <button
                      onClick={() => handleDelete(o.id)}
                      className="bg-red-600 text-white px-3 py-1 rounded-lg hover:bg-red-700"
                    >
                      Xoá
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
