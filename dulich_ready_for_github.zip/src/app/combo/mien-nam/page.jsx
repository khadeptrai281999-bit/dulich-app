"use client";
import Image from "next/image";
import Link from "next/link";

export default function MienNamCombo() {
  const tours = [
    {
      name: "Phú Quốc",
      description: "Thiên đường nghỉ dưỡng biển đảo Nam Bộ",
      price: "3.200.000đ",
      image:
        "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
      link: "/tour-tron-goi/trong-nuoc/phu-quoc",
    },
    {
      name: "Cần Thơ",
      description: "Trải nghiệm chợ nổi và nét văn hóa miền sông nước",
      price: "2.100.000đ",
      image:
        "https://images.pexels.com/photos/1578113/pexels-photo-1578113.jpeg",
      link: "/tour-tron-goi/trong-nuoc/can-tho",
    },
    {
      name: "Mũi Né - Kê Gà",
      description: "Khám phá đồi cát vàng và biển xanh Bình Thuận",
      price: "2.300.000đ",
      image:
        "https://images.pexels.com/photos/416676/pexels-photo-416676.jpeg",
      link: "/tour-tron-goi/trong-nuoc/mui-ne",
    },
    {
      name: "Nha Trang",
      description: "Khám phá thiên đường biển đảo miền Trung",
      price: "2.600.000đ",
      image:
        "https://images.pexels.com/photos/3601425/pexels-photo-3601425.jpeg",
      link: "/tour-tron-goi/trong-nuoc/nha-trang",
    },
    {
      name: "Vũng Tàu - Hồ Tràm",
      description: "Tận hưởng không gian biển gần Sài Gòn",
      price: "2.100.000đ",
      image:
        "https://images.pexels.com/photos/753626/pexels-photo-753626.jpeg",
      link: "/tour-tron-goi/trong-nuoc/vung-tau",
    },
    {
      name: "TP. Hồ Chí Minh",
      description: "Khám phá thành phố trẻ trung, sôi động bậc nhất Việt Nam",
      price: "2.300.000đ",
      image:
        "https://images.pexels.com/photos/2387863/pexels-photo-2387863.jpeg",
      link: "/tour-tron-goi/trong-nuoc/ho-chi-minh",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-green-900 mb-8 text-center">
        Combo du lịch Miền Nam
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {tours.map((tour, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition"
          >
            <div className="relative w-full h-64">
              <Image
                src={tour.image}
                alt={tour.name}
                fill
                className="object-cover"
              />
            </div>
            <div className="p-5">
              <h2 className="text-xl font-bold text-green-800 mb-2">
                {tour.name}
              </h2>
              <p className="text-gray-600 mb-3">{tour.description}</p>
              <p className="text-green-700 font-semibold mb-4">{tour.price}</p>
              <div className="flex justify-between">
                <Link href={tour.link}>
                  <button className="bg-gray-200 text-black px-4 py-2 rounded-lg hover:bg-gray-300">
                    Xem
                  </button>
                </Link>
                <Link href={tour.link}>
                  <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                    Đặt ngay
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
