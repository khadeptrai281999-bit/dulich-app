/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    unoptimized: true, // 🧩 thêm dòng này để Netlify không tối ưu ảnh tự động
    remotePatterns: [
      { protocol: "https", hostname: "dulich19.maugiaodien.com" },
      { protocol: "https", hostname: "media.yeah1.com" },
      { protocol: "https", hostname: "ik.imagekit.io" },
      { protocol: "https", hostname: "cdn1.ivivu.com" },
      { protocol: "https", hostname: "cdn3.ivivu.com" },
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "res.cloudinary.com" },
      { protocol: "https", hostname: "statics.vinpearl.com" },
      { protocol: "https", hostname: "statics.vinpearl.vn" },
      { protocol: "https", hostname: "dulichviet.com.vn" },
      { protocol: "https", hostname: "cdn.vntrip.vn" },
      { protocol: "https", hostname: "static.vietnamtourism.gov.vn" },
      { protocol: "https", hostname: "cf.bstatic.com" },
      { protocol: "https", hostname: "ak-d.tripcdn.com" },
      { protocol: "https", hostname: "q-xx.bstatic.com" },
      { protocol: "https", hostname: "images.trvl-media.com" },
      { protocol: "https", hostname: "pix8.agoda.net" },
      { protocol: "https", hostname: "cdn.tgdd.vn" },
      { protocol: "https", hostname: "cdn1.tuoitre.vn" },
      { protocol: "https", hostname: "file.hstatic.net" },
      { protocol: "https", hostname: "images2.thanhnien.vn" },
      { protocol: "https", hostname: "duyendangvietnam.net.vn" },
      { protocol: "https", hostname: "res.klook.com" },
      { protocol: "https", hostname: "toquoc.mediacdn.vn" },
      { protocol: "https", hostname: "vietuctourist.vn" },
      { protocol: "https", hostname: "images.pexels.com" },
      { protocol: "https", hostname: "cdn-icons-png.flaticon.com" },
    ],
  },
};

module.exports = nextConfig;
